import { create } from 'zustand'
import { subscribeWithSelector } from 'zustand/middleware'

export type AgentStatus = 'idle'|'thinking'|'running'|'done'|'error'
export type AppTab = 'radar'|'xray'|'planner'|'mentor'|'sidekick'|'video'|'impact'|'markets'|'tools'|'agent'|'guardian'|'bharat'|'data'

export interface Signal {
  id: string; type: 'insider_trade'|'bulk_deal'|'pattern'|'fundamental'|'alert'
  ticker: string; company: string; headline: string; detail: string
  sentiment: 'bullish'|'bearish'|'neutral'; strength: number
  timestamp: number; source: string; actionable: boolean
  indicators?: {
    rsi?: number; macd?: number; macdSignal?: number; macdHistogram?: number
    sma20?: number; sma50?: number; atr?: number; volumeSpike?: number
    momentum5d?: number; momentum20d?: number
  }
  setup?: string
  trend?: 'bullish'|'bearish'|'neutral'
  support?: number
  resistance?: number
  bullishScore?: number
  bearishScore?: number
  riskFlags?: string[]
  verdict?: string
  confidence?: number
}

export interface Holding {
  ticker: string; name: string; qty: number; avgCost: number
  ltp: number; currentValue: number; pnl: number; pnlPct: number
  sector: string; weight: number
}

export interface Fund {
  name: string; amc: string; category: string; nav: number
  xirr: number; invested: number; currentValue: number; units: number
  overlapPct?: number; expenseRatio: number; benchmarkReturn: number
}

export interface PortfolioData {
  holdings: Holding[]; funds: Fund[]
  totalValue: number; totalInvested: number
  overallPnl: number; overallPnlPct: number
  overallXirr: number; healthScore: number; loaded: boolean
}

export interface Notification {
  id: string; title: string; body: string
  type: 'signal'|'overlap'|'price'|'agent'|'browser'
  read: boolean; timestamp: number
}

export interface ChatMessage {
  id: string; role: 'user'|'assistant'|'agent'
  content: string; agentName?: string
  timestamp: number; isStreaming?: boolean
}

export interface AgentState {
  name: string; status: AgentStatus; lastAction: string; stepsCompleted: number
}

export interface AuditEntry {
  id: string; agentName: string; step: string
  input: string; output: string; status: 'running'|'done'|'error'
  timestamp: number; durationMs?: number
}

export interface PriceAlert {
  id: string; ticker: string; targetPrice: number
  direction: 'above'|'below'; triggered: boolean; createdAt: number
}

export interface BrowserContext {
  platform: string|null; detectedHoldings: string[]
  lastScanned: number|null; isReading: boolean; currentUrl: string|null
}

export interface AppStore {
  activeTab: AppTab
  setActiveTab: (t: AppTab) => void
  sidebarOpen: boolean
  setSidebarOpen: (v: boolean) => void
  language: 'en'|'hi'|'mr'
  setLanguage: (l: 'en'|'hi'|'mr') => void

  signals: Signal[]
  signalsLoading: boolean
  addSignal: (s: Signal) => void
  setSignals: (s: Signal[]) => void

  portfolio: PortfolioData
  setPortfolio: (p: Partial<PortfolioData>) => void
  portfolioLoading: boolean
  setPortfolioLoading: (v: boolean) => void

  notifications: Notification[]
  addNotification: (n: Omit<Notification,'id'|'read'|'timestamp'>) => void
  markAllRead: () => void
  unreadCount: () => number

  messages: ChatMessage[]
  addMessage: (m: ChatMessage) => void
  updateLastMessage: (content: string) => void
  clearMessages: () => void
  chatLoading: boolean
  setChatLoading: (v: boolean) => void

  agents: Record<string, AgentState>
  setAgentStatus: (name: string, status: AgentStatus, action?: string) => void

  auditLog: AuditEntry[]
  addAuditEntry: (e: Omit<AuditEntry,'id'|'timestamp'>) => void
  updateAuditEntry: (id: string, update: Partial<AuditEntry>) => void
  clearAudit: () => void

  priceAlerts: PriceAlert[]
  addPriceAlert: (a: Omit<PriceAlert,'id'|'triggered'|'createdAt'>) => void
  triggerAlert: (id: string) => void
  removePriceAlert: (id: string) => void

  browserCtx: BrowserContext
  setBrowserCtx: (ctx: Partial<BrowserContext>) => void

  overlapAlertDismissed: boolean
  dismissOverlapAlert: () => void
  weeklyDigestReady: boolean
  setWeeklyDigestReady: (v: boolean) => void
  firePlan: any
  setFirePlan: (p: any) => void

  sidekickUrl: string
  setSidekickUrl: (u: string) => void
}

const defaultPortfolio: PortfolioData = {
  holdings:[], funds:[], totalValue:0, totalInvested:0,
  overallPnl:0, overallPnlPct:0, overallXirr:0, healthScore:0, loaded:false
}

export const useStore = create<AppStore>()(
  subscribeWithSelector((set, get) => ({
    activeTab: 'radar',
    setActiveTab: t => set({ activeTab: t }),
    sidebarOpen: true,
    setSidebarOpen: v => set({ sidebarOpen: v }),
    language: 'en',
    setLanguage: l => set({ language: l }),

    signals: [], signalsLoading: false,
    addSignal: s => set(st => ({ signals: [s,...st.signals].slice(0,200) })),
    setSignals: signals => set({ signals }),

    portfolio: defaultPortfolio,
    setPortfolio: p => set(st => ({ portfolio: {...st.portfolio,...p} })),
    portfolioLoading: false,
    setPortfolioLoading: v => set({ portfolioLoading: v }),

    notifications: [],
    addNotification: n => set(st => ({ notifications: [{...n, id:`n-${Date.now()}`, read:false, timestamp:Date.now()}, ...st.notifications].slice(0,50) })),
    markAllRead: () => set(st => ({ notifications: st.notifications.map(n=>({...n,read:true})) })),
    unreadCount: () => get().notifications.filter(n=>!n.read).length,

    messages: [],
    addMessage: m => set(st => ({ messages:[...st.messages,m] })),
    updateLastMessage: content => set(st => {
      const msgs=[...st.messages]; if(!msgs.length) return {}
      msgs[msgs.length-1]={...msgs[msgs.length-1],content,isStreaming:false}
      return { messages:msgs }
    }),
    clearMessages: () => set({ messages:[] }),
    chatLoading: false,
    setChatLoading: v => set({ chatLoading:v }),

    agents: {
      radar:     {name:'Radar Agent',    status:'idle',lastAction:'Standby',stepsCompleted:0},
      portfolio: {name:'Portfolio Agent',status:'idle',lastAction:'Standby',stepsCompleted:0},
      planner:   {name:'Planner Agent',  status:'idle',lastAction:'Standby',stepsCompleted:0},
      overlap:   {name:'Overlap Agent',  status:'idle',lastAction:'Standby',stepsCompleted:0},
      browser:   {name:'Browser Agent',  status:'idle',lastAction:'Standby',stepsCompleted:0},
      video:     {name:'Video Agent',    status:'idle',lastAction:'Standby',stepsCompleted:0},
    },
    setAgentStatus: (name,status,action) => set(st => ({
      agents:{...st.agents,[name]:{...st.agents[name],status,lastAction:action??st.agents[name]?.lastAction??'',
        stepsCompleted:status==='done'?(st.agents[name]?.stepsCompleted??0)+1:(st.agents[name]?.stepsCompleted??0)}}
    })),

    auditLog: [],
    addAuditEntry: e => set(st => ({ auditLog:[{...e,id:`audit-${Date.now()}-${Math.random().toString(36).slice(2)}`,timestamp:Date.now()},...st.auditLog].slice(0,100) })),
    updateAuditEntry: (id,update) => set(st => ({ auditLog:st.auditLog.map(e=>e.id===id?{...e,...update}:e) })),
    clearAudit: () => set({ auditLog:[] }),

    priceAlerts: [],
    addPriceAlert: a => set(st => ({ priceAlerts:[{...a,id:`alert-${Date.now()}`,triggered:false,createdAt:Date.now()},...st.priceAlerts] })),
    triggerAlert: id => set(st => ({ priceAlerts:st.priceAlerts.map(a=>a.id===id?{...a,triggered:true}:a) })),
    removePriceAlert: id => set(st => ({ priceAlerts:st.priceAlerts.filter(a=>a.id!==id) })),

    browserCtx: {platform:null,detectedHoldings:[],lastScanned:null,isReading:false,currentUrl:null},
    setBrowserCtx: ctx => set(st => ({ browserCtx:{...st.browserCtx,...ctx} })),

    overlapAlertDismissed: false,
    dismissOverlapAlert: () => set({ overlapAlertDismissed:true }),
    weeklyDigestReady: false,
    setWeeklyDigestReady: v => set({ weeklyDigestReady:v }),
    firePlan: null,
    setFirePlan: p => set({ firePlan:p }),

    sidekickUrl: 'https://www.sharekhan.com',
    setSidekickUrl: u => set({ sidekickUrl:u }),
  }))
)
