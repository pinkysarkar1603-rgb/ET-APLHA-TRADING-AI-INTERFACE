import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Bot, Send, Loader2, Zap, Globe, BarChart2, TrendingUp, Paperclip, Sparkles, X } from 'lucide-react'
import { useStore } from '@/store'
import { VoiceInput } from '@/components/shared/MegaFeatures'
import { streamGroqResponse, formatINR, cn, groqSearchChat, NSE_TICKERS } from '@/lib/api'
import { fetchLiveQuote } from '@/lib/marketData'
import type { ChatMessage } from '@/store'

const QUICK_PROMPTS = [
  { label: 'Analyse my portfolio',    prompt: 'Analyse my current portfolio and give me the top 3 specific actions to improve it this week. Use exact numbers from my holdings.' },
  { label: 'Best signal right now',   prompt: 'Which signal from the radar is most actionable right now? Give me a specific trade thesis with entry point, target, and risk.' },
  { label: 'Am I on FIRE track?',     prompt: 'Based on my portfolio, am I on track to achieve FIRE at age 45? What exact changes to my SIP do I need?' },
  { label: 'Tax saves before Mar 31', prompt: 'What are the specific tax saving investments I should make before March 31? Show me exact amounts and sections.' },
  { label: 'Fix my fund overlap',     prompt: 'My Mirae Large Cap and Axis Bluechip have 70% overlap. Give me a specific consolidation plan with exact fund names and amounts.' },
  { label: 'Market summary today',    prompt: 'What are the most important market movements today from my radar signals and how do they affect my specific holdings?' },
]

function buildSystemPrompt(portfolio: any, signals: any[], browserCtx: any, language: string = 'en'): string {
  const holdingsSummary = portfolio.holdings
    .map((h: any) => `${h.ticker}: ${h.qty} shares @ ₹${h.ltp} (avg ₹${h.avgCost}, P&L ${h.pnlPct > 0 ? '+' : ''}${h.pnlPct}%, value ${formatINR(h.currentValue, true)})`)
    .join('\n')

  const topSignals = signals.slice(0, 5)
    .map((s: any) => `[${s.type?.toUpperCase()}] ${s.ticker}: "${s.headline}" → ${s.sentiment}, strength ${s.strength}/100`)
    .join('\n')

  const browserNote = browserCtx.platform
    ? `\nUser has ${browserCtx.platform} open. Auto-imported holdings: ${browserCtx.detectedHoldings.join(', ')}.`
    : ''

  const langInstr = language === 'hi' ? 'IMPORTANT: Respond ONLY in Hindi (Devanagari script). All numbers, analysis, and advice must be in Hindi.' : language === 'mr' ? 'IMPORTANT: Respond ONLY in Marathi (Devanagari script).' : ''
  return `${langInstr}\nYou are ET Alpha, an elite AI investment co-pilot for Indian retail investors built on Groq's LLaMA-3.3-70B.

PERSONALITY: Sharp, direct, data-driven. Give specific numbers. Never say "I don't have real-time data" — you have it below. Talk like a seasoned fund manager, not a chatbot.

USER'S LIVE PORTFOLIO (real NSE prices):
${holdingsSummary || 'Loading live prices...'}

Total portfolio value: ${formatINR(portfolio.totalValue, true)}
Overall P&L: ${formatINR(portfolio.overallPnl, true)} (${portfolio.overallPnlPct > 0 ? '+' : ''}${portfolio.overallPnlPct}%)
XIRR: ${portfolio.overallXirr}% | Health Score: ${portfolio.healthScore}/100
Mutual funds: ${portfolio.funds?.length || 0} funds, 2 with >60% overlap detected

LIVE MARKET SIGNALS (Groq-analysed from real NSE data):
${topSignals || 'Signals loading...'}
${browserNote}

RULES:
- Always use numbers from the portfolio above
- Specific actionable advice with exact INR amounts
- Flag risks with quantified downside
- Format key numbers in **bold**
- End with "Next step: [one clear action]"
- If asked about any NSE stock, give real analysis based on the signal data`
}

function shouldUseSearch(text: string) {
  const lower = text.toLowerCase()
  return [
    'price', 'today', 'latest', 'report', 'results', 'earnings', 'annual report', 'quarterly',
    'news', 'headline', 'why is', 'why did', 'what happened', 'announcement', 'filing', 'guidance',
  ].some(term => lower.includes(term))
}

function extractRelevantTickers(text: string, portfolio: any) {
  const uppercase = text.toUpperCase()
  const known = new Set<string>()
  portfolio.holdings?.forEach((holding: any) => known.add(holding.ticker))
  NSE_TICKERS.forEach(item => known.add(item.sym))
  return Array.from(known).filter(ticker => uppercase.includes(ticker.replace(/\s+/g, '')))
}

async function buildLiveQuoteContext(tickers: string[]) {
  const unique = Array.from(new Set(tickers)).slice(0, 4)
  const quoteLines = await Promise.all(unique.map(async ticker => {
    const mapped = NSE_TICKERS.find(item => item.sym === ticker)
    const yf = mapped?.yf ?? (ticker.startsWith('^') ? ticker : `${ticker}.NS`)
    const quote = await fetchLiveQuote(yf)
    if (!quote) return null
    return `${ticker}: Rs ${quote.price} (${quote.chgPct >= 0 ? '+' : ''}${quote.chgPct}%), open ${quote.open}, high ${quote.high}, low ${quote.low}, volume ${quote.volume}`
  }))
  return quoteLines.filter(Boolean).join('\n')
}

function MessageBubble({ msg }: { msg: ChatMessage }) {
  const isUser = msg.role === 'user'
  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn('flex gap-2', isUser ? 'justify-end' : 'justify-start')}
    >
      {!isUser && (
        <div className="w-6 h-6 rounded-md bg-brand-500/15 border border-brand-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
          <Bot size={12} className="text-brand-400" />
        </div>
      )}
      <div className={cn(
        'max-w-[88%] rounded-xl px-3 py-2.5 text-[12px] leading-relaxed',
        isUser
          ? 'bg-brand-500/10 border border-brand-500/20 text-gray-200 rounded-tr-sm'
          : 'bg-surface-600 border border-surface-500/40 text-gray-200 rounded-tl-sm'
      )}>
        {msg.isStreaming ? (
          <span>
            {msg.content}
            <span className="inline-block w-1.5 h-3 bg-brand-400 ml-0.5 animate-pulse rounded-sm align-middle" />
          </span>
        ) : (
          <span dangerouslySetInnerHTML={{
            __html: msg.content
              .replace(/\*\*(.*?)\*\*/g, '<strong class="text-white font-semibold">$1</strong>')
              .replace(/`(.*?)`/g, '<code class="bg-surface-700 px-1 py-0.5 rounded text-brand-300 font-mono text-[10px]">$1</code>')
              .replace(/\n/g, '<br/>')
          }} />
        )}
        <p className="text-[9px] text-gray-600 mt-1.5">
          {new Date(msg.timestamp).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
          {msg.agentName && <span className="text-brand-500/60"> · {msg.agentName}</span>}
        </p>
      </div>
    </motion.div>
  )
}

export default function CopilotPanel() {
  const {
    messages, addMessage, updateLastMessage, chatLoading, setChatLoading,
    clearMessages, portfolio, signals, browserCtx, setAgentStatus, language
  } = useStore()

  const [input, setInput] = useState('')
  const [error, setError]  = useState<string | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const sendMessage = async (text?: string) => {
    const content = (text ?? input).trim()
    if (!content || chatLoading) return
    setInput('')
    setError(null)

    addMessage({ id: `u-${Date.now()}`, role: 'user', content, timestamp: Date.now() })
    setChatLoading(true)
    setAgentStatus('radar', 'thinking', 'Groq LLaMA-3.3 reasoning...')

    const assistantId = `a-${Date.now()}`
    addMessage({ id: assistantId, role: 'assistant', content: '', agentName: 'ET Alpha (Groq)', timestamp: Date.now(), isStreaming: true })

    const history = messages
      .filter(m => m.role === 'user' || m.role === 'assistant')
      .slice(-8)
      .map(m => ({ role: m.role as 'user' | 'assistant', content: m.content }))
    history.push({ role: 'user', content })

    try {
      if (shouldUseSearch(content)) {
        setAgentStatus('radar', 'thinking', 'Collecting live prices and web context...')
        const mentioned = extractRelevantTickers(content, portfolio)
        const liveQuotes = await buildLiveQuoteContext(mentioned)
        const searchResponse = await groqSearchChat(
          `${buildSystemPrompt(portfolio, signals, browserCtx, language)}

ADDITIONAL RULES FOR LIVE SEARCH:
- Use live web search for current reports, latest filings, earnings, and news.
- If current prices are provided below, prioritize those exact prices over any web-text mentions.
- If current evidence conflicts, say so clearly.
- End with "Next step: [one clear action]"`,
          `${content}

Live quote context:
${liveQuotes || 'No directly matched live quote context.'}`,
          {
            country: 'india',
            include_domains: ['nseindia.com', 'moneycontrol.com', 'economictimes.indiatimes.com', 'reuters.com', 'bseindia.com', 'screener.in'],
          },
        )

        const sourceBlock = searchResponse.citations.length > 0
          ? `\n\nSources:\n${searchResponse.citations.slice(0, 4).map((item, index) => `${index + 1}. ${item.title} - ${item.url}`).join('\n')}`
          : ''
        updateLastMessage(`${searchResponse.content}${sourceBlock}`)
        setChatLoading(false)
        setAgentStatus('radar', 'idle', 'Ready')
      } else {
        let fullText = ''
        await streamGroqResponse(
          buildSystemPrompt(portfolio, signals, browserCtx, language),
          history,
          (chunk) => { fullText += chunk; updateLastMessage(fullText) },
          ()      => { setChatLoading(false); setAgentStatus('radar', 'idle', 'Ready') }
        )
      }
    } catch (err: any) {
      const msg = err?.message?.includes('401')
        ? 'Invalid API key — check VITE_GROQ_API_KEY in .env.local'
        : err?.message?.includes('429')
        ? 'Rate limited — wait a moment and try again'
        : `Error: ${err?.message ?? 'Unknown'}`
      setError(msg)
      updateLastMessage(`⚠️ ${msg}`)
      setChatLoading(false)
      setAgentStatus('radar', 'error', 'API error')
    }
  }

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage() }
  }

  return (
    <div className="h-full bg-surface-800 border-l border-surface-500/50 flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-2 px-4 py-2.5 border-b border-surface-500/30 flex-shrink-0">
        <div className="w-6 h-6 bg-brand-500/10 rounded-md flex items-center justify-center border border-brand-500/20">
          <Bot size={12} className="text-brand-400" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-xs font-semibold text-white">ET Alpha Co-Pilot</p>
          <p className="text-[9px] text-gray-500">Groq LLaMA-3.3-70B · Real NSE data · Streaming</p>
        </div>
        <div className="flex items-center gap-1 text-[9px] text-neon-green flex-shrink-0">
          <div className="w-1.5 h-1.5 bg-neon-green rounded-full animate-pulse" />
          Live
        </div>
        {browserCtx.platform && (
          <div className="flex items-center gap-1 text-[9px] text-blue-400 bg-blue-500/10 border border-blue-500/20 px-1.5 py-0.5 rounded flex-shrink-0">
            <Globe size={8} /> {browserCtx.platform}
          </div>
        )}
        {messages.length > 0 && (
          <button onClick={clearMessages} className="p-1 text-gray-600 hover:text-gray-400">
            <X size={12} />
          </button>
        )}
      </div>

      {/* Context strip */}
      {portfolio.loaded && (
        <div className="px-3 py-2 border-b border-surface-500/20 flex-shrink-0">
          <div className="flex items-center gap-2 overflow-x-auto pb-0.5 scrollbar-none">
            {[
              { icon: BarChart2,  val: formatINR(portfolio.totalValue, true),                color: 'text-white'       },
              { icon: TrendingUp, val: `${portfolio.overallPnlPct > 0 ? '+' : ''}${portfolio.overallPnlPct}%`, color: portfolio.overallPnlPct >= 0 ? 'text-neon-green' : 'text-neon-red' },
              { icon: Zap,        val: `${signals.filter((s: any) => s.actionable).length} signals`, color: 'text-brand-400' },
            ].map((c, i) => {
              const Icon = c.icon
              return (
                <div key={i} className="flex items-center gap-1 bg-surface-700/60 rounded px-2 py-1 flex-shrink-0 border border-surface-500/30">
                  <Icon size={9} className={c.color} />
                  <span className={cn('text-[10px] font-mono font-medium', c.color)}>{c.val}</span>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {messages.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center h-full text-center py-6"
          >
            <div className="w-10 h-10 bg-brand-500/10 rounded-xl flex items-center justify-center mb-2 border border-brand-500/20">
              <Sparkles size={18} className="text-brand-400" />
            </div>
            <p className="text-sm font-semibold text-white mb-1">Ask anything</p>
            <p className="text-[11px] text-gray-500 max-w-44 leading-relaxed">
              I have your live portfolio, real NSE signals, and full market context.
            </p>
          </motion.div>
        )}
        {messages.map(msg => <MessageBubble key={msg.id} msg={msg} />)}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick prompts */}
      {messages.length === 0 && (
        <div className="px-3 pb-2 flex-shrink-0">
          <div className="flex flex-wrap gap-1.5">
            {QUICK_PROMPTS.map(qp => (
              <button
                key={qp.label}
                onClick={() => sendMessage(qp.prompt)}
                disabled={chatLoading}
                className="text-[10px] bg-surface-700 border border-surface-500/50 text-gray-400 hover:text-white hover:border-brand-500/30 px-2 py-1 rounded-lg transition-all disabled:opacity-40"
              >
                {qp.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Error banner */}
      {error && (
        <div className="mx-3 mb-2 bg-neon-red/10 border border-neon-red/20 rounded-lg px-3 py-2 text-[10px] text-neon-red flex items-center justify-between">
          <span>{error}</span>
          <button onClick={() => setError(null)}><X size={10} /></button>
        </div>
      )}

      {/* Input */}
      <div className="p-3 border-t border-surface-500/30 flex-shrink-0">
        <div className="flex items-end gap-2 bg-surface-700 border border-surface-500/50 rounded-xl px-3 py-2 focus-within:border-brand-500/40 transition-colors">
          <textarea
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKey}
            placeholder="Ask about your portfolio, signals, FIRE plan…"
            rows={1}
            className="flex-1 bg-transparent text-[12px] text-gray-200 placeholder-gray-600 resize-none outline-none leading-relaxed"
            style={{ minHeight: '20px', maxHeight: '80px' }}
          />
          <div className="flex items-center gap-1.5 flex-shrink-0">
            <VoiceInput onTranscript={(t) => { setInput(t); setTimeout(() => sendMessage(t), 100) }} />
            <button className="p-1 text-gray-600 hover:text-gray-400 transition-colors">
              <Paperclip size={12} />
            </button>
            <button
              onClick={() => sendMessage()}
              disabled={!input.trim() || chatLoading}
              className={cn(
                'w-7 h-7 rounded-lg flex items-center justify-center transition-all',
                input.trim() && !chatLoading
                  ? 'bg-brand-500 text-surface-900 hover:bg-brand-400'
                  : 'bg-surface-600 text-gray-600 cursor-not-allowed'
              )}
            >
              {chatLoading ? <Loader2 size={12} className="animate-spin" /> : <Send size={11} />}
            </button>
          </div>
        </div>
        <p className="text-[9px] text-gray-700 text-center mt-1">Enter to send · Powered by Groq LLaMA-3.3-70B</p>
      </div>
    </div>
  )
}
// Language patch - applied via store subscription in CopilotPanel
