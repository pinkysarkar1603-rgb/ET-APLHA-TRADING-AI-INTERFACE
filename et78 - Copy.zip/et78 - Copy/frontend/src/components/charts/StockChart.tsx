import { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  Activity,
  BarChart2,
  BrainCircuit,
  ExternalLink,
  Loader2,
  Search,
  TrendingDown,
  TrendingUp,
} from 'lucide-react'
import { cn, groqChat } from '@/lib/api'
import { fetchLiveQuote, type LiveQuote } from '@/lib/marketData'

interface CandlePoint {
  time: string
  open: number
  high: number
  low: number
  close: number
  volume: number
}

interface BlueprintFactor {
  title: string
  impact: string
}

interface MoveBlueprint {
  summary: string
  moveType: string
  confidence: number
  domestic: BlueprintFactor[]
  global: BlueprintFactor[]
  sector: BlueprintFactor[]
  company: BlueprintFactor[]
  verify: string[]
  headlines: string[]
}

interface TradeMap {
  entry: number
  stopLoss: number
  target1: number
  target2: number
  confirmation: string
  riskReward: string
}

interface OverlayLine {
  label: string
  color: string
  values: number[]
}

interface IndicatorOverlay {
  title: string
  lines: OverlayLine[]
  note: string
}

async function fetchCandleData(yfSym: string, range = '3mo', interval = '1d'): Promise<CandlePoint[]> {
  try {
    const res = await fetch(`/yf/v8/finance/chart/${yfSym}?interval=${interval}&range=${range}`)
    const data = await res.json()
    const result = data?.chart?.result?.[0]
    if (!result) return []
    const { timestamp, indicators } = result
    const q = indicators?.quote?.[0]
    if (!timestamp || !q) return []
    return timestamp.map((t: number, i: number) => ({
      time: new Date(t * 1000).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' }),
      open: +(q.open?.[i] ?? 0).toFixed(2),
      high: +(q.high?.[i] ?? 0).toFixed(2),
      low: +(q.low?.[i] ?? 0).toFixed(2),
      close: +(q.close?.[i] ?? 0).toFixed(2),
      volume: q.volume?.[i] || 0,
    })).filter((c: CandlePoint) => c.open && c.high && c.low && c.close)
  } catch {
    return []
  }
}

async function fetchTickerNews(symbol: string) {
  const query = symbol.replace('.NS', '').replace('^', '')
  try {
    const res = await fetch(`/yf/v1/finance/search?q=${encodeURIComponent(query)}&quotesCount=1&newsCount=6`)
    const data = await res.json()
    return (data?.news ?? []).slice(0, 5).map((item: any) => ({
      title: item.title as string,
      publisher: item.publisher as string,
      link: item.link as string,
    }))
  } catch {
    return []
  }
}

function sanitizeJsonPayload(text: string) {
  const match = text.match(/\{[\s\S]*\}/)
  return match ? match[0] : ''
}

async function buildMoveBlueprint(params: {
  ticker: string
  candle: CandlePoint
  quote: LiveQuote
  candles: CandlePoint[]
}): Promise<MoveBlueprint> {
  const news = await fetchTickerNews(params.ticker)
  const recentCandles = params.candles
    .slice(-8)
    .map(c => `${c.time}: O${c.open} H${c.high} L${c.low} C${c.close} V${c.volume}`)
    .join('; ')
  const pctMove = (((params.candle.close - params.candle.open) / params.candle.open) * 100).toFixed(2)
  const newsText = news.length
    ? news.map((item: { title: string; publisher: string }, index: number) => `${index + 1}. ${item.title} | ${item.publisher}`).join('\n')
    : 'No related Yahoo headlines returned.'

  try {
    const response = await groqChat(
      'You are a financial market causality analyst. Use only the supplied candles, quote context, and headlines. If evidence is weak, explicitly label a factor as a hypothesis instead of a fact. Return only valid JSON.',
      `Ticker: ${params.ticker}
Selected candle: ${params.candle.time}, open ${params.candle.open}, close ${params.candle.close}, high ${params.candle.high}, low ${params.candle.low}, volume ${params.candle.volume}, move ${pctMove}%.
Current quote: price ${params.quote.price}, daily change ${params.quote.chgPct}%, high ${params.quote.high}, low ${params.quote.low}, volume ${params.quote.volume}.
Recent candles: ${recentCandles}
Related headlines:
${newsText}

Return only this JSON object:
{
  "summary": "1-2 sentence explanation of the move",
  "moveType": "breakout|breakdown|reversal|range reaction|trend continuation|mixed",
  "confidence": 0-100,
  "domestic": [{"title":"factor","impact":"why it mattered"}],
  "global": [{"title":"factor","impact":"why it mattered"}],
  "sector": [{"title":"factor","impact":"why it mattered"}],
  "company": [{"title":"factor","impact":"why it mattered"}],
  "verify": ["what to verify next", "another check"],
  "headlines": ["headline 1", "headline 2"]
}

Rules:
- Use max 2 items per category.
- If no concrete headline supports a category, keep one item but say "technical-flow hypothesis".
- Do not invent wars, policies, or announcements unless supported by the supplied headlines.
- Keep it concise and specific.`
    )

    const parsed = JSON.parse(sanitizeJsonPayload(response))
    return {
      summary: parsed.summary ?? 'Blueprint unavailable.',
      moveType: parsed.moveType ?? 'mixed',
      confidence: Number(parsed.confidence ?? 45),
      domestic: Array.isArray(parsed.domestic) ? parsed.domestic : [],
      global: Array.isArray(parsed.global) ? parsed.global : [],
      sector: Array.isArray(parsed.sector) ? parsed.sector : [],
      company: Array.isArray(parsed.company) ? parsed.company : [],
      verify: Array.isArray(parsed.verify) ? parsed.verify : [],
      headlines: Array.isArray(parsed.headlines) ? parsed.headlines : news.map((item: { title: string }) => item.title),
    }
  } catch {
    return {
      summary: 'Price action was detected, but the blueprint agent could not structure the cause map right now.',
      moveType: 'mixed',
      confidence: 32,
      domestic: [{ title: 'Technical-flow hypothesis', impact: 'This move may be coming from domestic positioning or intraday order-flow rather than a confirmed headline.' }],
      global: [{ title: 'Global risk tone watch', impact: 'Watch US yields, commodities, and risk-on/risk-off moves to confirm whether this was a broader market reaction.' }],
      sector: [{ title: 'Sector rotation check', impact: 'Compare this stock against peers to see whether the move was company-specific or sector-wide.' }],
      company: [{ title: 'Company catalyst pending verification', impact: 'Verify exchange filings, management commentary, or earnings updates before treating any narrative as confirmed.' }],
      verify: ['Check latest exchange/company filings', 'Compare with sector peers and index move'],
      headlines: news.map((item: { title: string }) => item.title),
    }
  }
}

function BlueprintVisual({
  ticker,
  moveType,
  domestic,
  global,
  sector,
  company,
}: {
  ticker: string
  moveType: string
  domestic: BlueprintFactor[]
  global: BlueprintFactor[]
  sector: BlueprintFactor[]
  company: BlueprintFactor[]
}) {
  const groups = [
    { label: 'Domestic', x: 90, y: 55, tone: '#38bdf8', items: domestic },
    { label: 'Global', x: 420, y: 55, tone: '#a78bfa', items: global },
    { label: 'Sector', x: 90, y: 210, tone: '#34d399', items: sector },
    { label: 'Company', x: 420, y: 210, tone: '#f59e0b', items: company },
  ]

  return (
    <svg width="100%" viewBox="0 0 520 280" className="rounded-2xl border border-surface-500/40 bg-[radial-gradient(circle_at_top,rgba(59,130,246,0.12),transparent_35%),linear-gradient(180deg,#08101d_0%,#10192a_100%)]">
      {groups.map(group => (
        <g key={group.label}>
          <line x1="260" y1="140" x2={group.x + 58} y2={group.y + 30} stroke={group.tone} strokeWidth="1.4" strokeDasharray="5 4" opacity="0.75" />
          <rect x={group.x} y={group.y} width="116" height="62" rx="14" fill={`${group.tone}18`} stroke={group.tone} />
          <text x={group.x + 58} y={group.y + 21} textAnchor="middle" fill={group.tone} fontSize="12" fontWeight="700">
            {group.label}
          </text>
          <text x={group.x + 58} y={group.y + 40} textAnchor="middle" fill="#e2e8f0" fontSize="9">
            {(group.items[0]?.title ?? 'No factor').slice(0, 22)}
          </text>
          <text x={group.x + 58} y={group.y + 52} textAnchor="middle" fill="#64748b" fontSize="8">
            {(group.items[1]?.title ?? 'Watch next').slice(0, 20)}
          </text>
        </g>
      ))}

      <circle cx="260" cy="140" r="44" fill="#14213a" stroke="#ffc61a" strokeWidth="2" />
      <text x="260" y="132" textAnchor="middle" fill="#ffc61a" fontSize="13" fontWeight="800">
        {ticker}
      </text>
      <text x="260" y="149" textAnchor="middle" fill="#ffffff" fontSize="11" fontWeight="700">
        {moveType}
      </text>
      <text x="260" y="164" textAnchor="middle" fill="#94a3b8" fontSize="8">
        move blueprint
      </text>
    </svg>
  )
}

function buildTradeMap(candle: CandlePoint, blueprint: MoveBlueprint | null): TradeMap {
  const bullish = candle.close >= candle.open
  const range = Math.max(candle.high - candle.low, 1)
  const entry = candle.close
  const stopLoss = bullish ? candle.low - range * 0.18 : candle.high + range * 0.18
  const target1 = bullish ? candle.close + range * 0.9 : candle.close - range * 0.9
  const target2 = bullish ? candle.close + range * 1.8 : candle.close - range * 1.8
  const confirmation = bullish
    ? `Watch for price to hold above Rs ${candle.close.toFixed(2)} and reclaim volume on the next green candle.`
    : `Watch for price to stay below Rs ${candle.close.toFixed(2)} and confirm with another weak close or volume expansion.`
  const reward = Math.abs(target1 - entry)
  const risk = Math.abs(entry - stopLoss) || 1
  const riskReward = `${(reward / risk).toFixed(2)}R`

  if (blueprint?.moveType === 'reversal') {
    return {
      entry,
      stopLoss,
      target1,
      target2,
      confirmation: `${confirmation} Because this looks like a reversal attempt, confirmation matters more than speed.`,
      riskReward,
    }
  }

  return { entry, stopLoss, target1, target2, confirmation, riskReward }
}

function sma(values: number[], period: number) {
  if (values.length === 0) return []
  return values.map((_, index) => {
    const start = Math.max(0, index - period + 1)
    const slice = values.slice(start, index + 1)
    return slice.reduce((sum, value) => sum + value, 0) / slice.length
  })
}

function ema(values: number[], period: number) {
  if (values.length === 0) return []
  const multiplier = 2 / (period + 1)
  let previous = values[0]
  return values.map((value, index) => {
    if (index === 0) return value
    previous = ((value - previous) * multiplier) + previous
    return previous
  })
}

function stddev(values: number[], period: number) {
  return values.map((_, index) => {
    const start = Math.max(0, index - period + 1)
    const slice = values.slice(start, index + 1)
    const avg = slice.reduce((sum, value) => sum + value, 0) / slice.length
    const variance = slice.reduce((sum, value) => sum + (value - avg) ** 2, 0) / slice.length
    return Math.sqrt(variance)
  })
}

function highest(values: number[], period: number) {
  return values.map((_, index) => Math.max(...values.slice(Math.max(0, index - period + 1), index + 1)))
}

function lowest(values: number[], period: number) {
  return values.map((_, index) => Math.min(...values.slice(Math.max(0, index - period + 1), index + 1)))
}

function buildIndicatorOverlay(candles: CandlePoint[], selectedIndicatorName?: string): IndicatorOverlay | null {
  if (!selectedIndicatorName || candles.length === 0) return null
  const closes = candles.map(item => item.close)
  const highs = candles.map(item => item.high)
  const lows = candles.map(item => item.low)
  const typical = closes.map((close, index) => (highs[index] + lows[index] + close) / 3)
  const lowerName = selectedIndicatorName.toLowerCase()

  const sma20 = sma(closes, 20)
  const sma50 = sma(closes, 50)
  const ema12 = ema(closes, 12)
  const ema26 = ema(closes, 26)
  const deviation = stddev(closes, 20)
  const upperBand = sma20.map((value, index) => value + deviation[index] * 2)
  const lowerBand = sma20.map((value, index) => value - deviation[index] * 2)
  const upperChannel = highest(highs, 20)
  const lowerChannel = lowest(lows, 20)
  const vwapLine = closes.map((_, index) => {
    let cumulativePV = 0
    let cumulativeVol = 0
    for (let i = 0; i <= index; i += 1) {
      cumulativePV += typical[i] * candles[i].volume
      cumulativeVol += candles[i].volume
    }
    return cumulativeVol ? cumulativePV / cumulativeVol : closes[index]
  })

  if (lowerName.includes('bollinger')) {
    return { title: selectedIndicatorName, lines: [{ label: 'Upper', color: '#a78bfa', values: upperBand }, { label: 'Basis', color: '#ffc61a', values: sma20 }, { label: 'Lower', color: '#a78bfa', values: lowerBand }], note: 'The selected indicator now affects the center candlestick through a live band overlay.' }
  }
  if (lowerName.includes('vwap')) {
    return { title: selectedIndicatorName, lines: [{ label: 'VWAP', color: '#34d399', values: vwapLine }], note: 'VWAP is drawn directly on top of the main candlestick chart.' }
  }
  if (lowerName.includes('donchian') || lowerName.includes('keltner') || lowerName.includes('channel') || lowerName.includes('envelope')) {
    return { title: selectedIndicatorName, lines: [{ label: 'Upper', color: '#38bdf8', values: upperChannel }, { label: 'Mid', color: '#ffc61a', values: sma20 }, { label: 'Lower', color: '#38bdf8', values: lowerChannel }], note: 'Channel-style indicators are shown directly on the center candlestick.' }
  }
  if (lowerName.includes('fibonacci') || lowerName.includes('pivot') || lowerName.includes('gann') || lowerName.includes('pitchfork')) {
    const high = Math.max(...highs)
    const low = Math.min(...lows)
    const middle = high - (high - low) * 0.382
    return { title: selectedIndicatorName, lines: [{ label: 'Resistance', color: '#f59e0b', values: closes.map(() => high) }, { label: 'Level', color: '#ffc61a', values: closes.map(() => middle) }, { label: 'Support', color: '#38bdf8', values: closes.map(() => low) }], note: 'Support-resistance indicators are affecting the same main candlestick as horizontal overlays.' }
  }
  if (lowerName.includes('ema') || lowerName.includes('sma') || lowerName.includes('wma') || lowerName.includes('hma') || lowerName.includes('dema') || lowerName.includes('tema') || lowerName.includes('vma') || lowerName.includes('supertrend') || lowerName.includes('ichimoku') || lowerName.includes('aroon') || lowerName.includes('parabolic') || lowerName.includes('adx') || lowerName.includes('dmi') || lowerName.includes('trix') || lowerName.includes('vortex') || lowerName.includes('guppy')) {
    return { title: selectedIndicatorName, lines: [{ label: 'Fast', color: '#ffc61a', values: ema12 }, { label: 'Slow', color: '#38bdf8', values: ema26.length === closes.length ? ema26 : sma50 }], note: 'Trend-family indicators are now changing the center candlestick through live guide rails.' }
  }
  return { title: selectedIndicatorName, lines: [{ label: 'Guide', color: '#ffc61a', values: ema12 }, { label: 'Baseline', color: '#38bdf8', values: sma20 }], note: 'This indicator is currently mapped to a live overlay guide on the center candlestick.' }
}

function CandlestickChart({
  candles,
  selectedIndex,
  onSelectCandle,
  overlay,
  width = 580,
  height = 220,
}: {
  candles: CandlePoint[]
  selectedIndex: number | null
  onSelectCandle: (index: number) => void
  overlay?: IndicatorOverlay | null
  width?: number
  height?: number
}) {
  if (!candles.length) return null
  const pad = { top: 12, right: 10, bottom: 24, left: 52 }
  const chartWidth = width - pad.left - pad.right
  const chartHeight = height - pad.top - pad.bottom
  const prices = candles.flatMap(c => [c.high, c.low])
  const minPrice = Math.min(...prices) * 0.999
  const maxPrice = Math.max(...prices) * 1.001
  const priceRange = Math.max(maxPrice - minPrice, 1)
  const candleWidth = Math.max(4, Math.floor(chartWidth / candles.length) - 2)

  const scaleY = (price: number) => chartHeight - ((price - minPrice) / priceRange) * chartHeight + pad.top
  const scaleX = (index: number) => pad.left + (index / candles.length) * chartWidth + candleWidth / 2
  const labelStep = Math.ceil(candles.length / 8)
  const yTicks = Array.from({ length: 5 }, (_, i) => minPrice + (priceRange * i) / 4)
  const linePath = (values: number[]) => values.map((value, index) => `${index === 0 ? 'M' : 'L'} ${scaleX(index)} ${scaleY(value)}`).join(' ')

  return (
    <svg width="100%" viewBox={`0 0 ${width} ${height}`} style={{ display: 'block' }}>
      {yTicks.map((value, index) => (
        <g key={index}>
          <line x1={pad.left} x2={width - pad.right} y1={scaleY(value)} y2={scaleY(value)} stroke="#1a2640" strokeWidth="0.5" strokeDasharray="4 4" />
          <text x={pad.left - 4} y={scaleY(value) + 3.5} textAnchor="end" fill="#64748b" fontSize="9" fontFamily="monospace">
            {value > 1000 ? `${(value / 1000).toFixed(1)}K` : value.toFixed(0)}
          </text>
        </g>
      ))}

      {candles.map((candle, index) => {
        const x = scaleX(index)
        const isUp = candle.close >= candle.open
        const color = isUp ? '#00e676' : '#ff3d57'
        const bodyTop = scaleY(Math.max(candle.open, candle.close))
        const bodyBottom = scaleY(Math.min(candle.open, candle.close))
        const bodyHeight = Math.max(1, bodyBottom - bodyTop)
        const active = selectedIndex === index

        return (
          <g
            key={`${candle.time}-${index}`}
            onClick={() => onSelectCandle(index)}
            className="cursor-pointer"
          >
            <rect
              x={x - candleWidth}
              y={pad.top}
              width={candleWidth * 2}
              height={chartHeight}
              fill={active ? '#1d4ed833' : 'transparent'}
              rx="5"
            />
            <line x1={x} x2={x} y1={scaleY(candle.high)} y2={scaleY(candle.low)} stroke={color} strokeWidth={active ? '1.4' : '0.9'} opacity={active ? 1 : 0.75} />
            <rect
              x={x - candleWidth / 2}
              y={bodyTop}
              width={candleWidth}
              height={bodyHeight}
              fill={color}
              opacity={active ? 1 : 0.88}
              rx="1"
            />
          </g>
        )
      })}

      {overlay?.lines.map(line => (
        <path key={line.label} d={linePath(line.values)} fill="none" stroke={line.color} strokeWidth="1.5" opacity="0.92" />
      ))}

      {overlay && (
        <g>
          <rect x={pad.left} y={pad.top + 6} width="190" height="22" rx="11" fill="#08101dcc" stroke="#243354" />
          <text x={pad.left + 10} y={pad.top + 20} fill="#e2e8f0" fontSize="9" fontWeight="700">{overlay.title}</text>
        </g>
      )}

      {candles.map((candle, index) => index % labelStep === 0 && (
        <text key={index} x={scaleX(index)} y={height - 4} textAnchor="middle" fill="#64748b" fontSize="8">
          {candle.time}
        </text>
      ))}
    </svg>
  )
}

export default function StockChart({ initialTicker = 'RELIANCE', headerLabel = 'Live Candlestick + Move Blueprint', selectedIndicatorName }: { initialTicker?: string; headerLabel?: string; selectedIndicatorName?: string }) {
  const [ticker, setTicker] = useState(initialTicker)
  const [input, setInput] = useState(initialTicker)
  const [range, setRange] = useState('3mo')
  const [candles, setCandles] = useState<CandlePoint[]>([])
  const [quote, setQuote] = useState<LiveQuote | null>(null)
  const [loading, setLoading] = useState(false)
  const [analysis, setAnalysis] = useState('')
  const [analysing, setAnalysing] = useState(false)
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null)
  const [blueprint, setBlueprint] = useState<MoveBlueprint | null>(null)
  const [blueprintLoading, setBlueprintLoading] = useState(false)

  const ranges = ['5d', '1mo', '3mo', '6mo', '1y'] as const

  const resolvedSymbol = useMemo(
    () => (ticker === 'NIFTY50' ? '^NSEI' : ticker),
    [ticker],
  )

  const selectedCandle = selectedIndex !== null ? candles[selectedIndex] : null
  const overlay = useMemo(() => buildIndicatorOverlay(candles, selectedIndicatorName), [candles, selectedIndicatorName])

  useEffect(() => {
    const normalized = initialTicker.trim().toUpperCase()
    if (normalized && normalized !== ticker) {
      setTicker(normalized)
      setInput(normalized)
      setAnalysis('')
      setBlueprint(null)
      setSelectedIndex(null)
    }
  }, [initialTicker])

  const load = async (symbol: string, nextRange: string) => {
    setLoading(true)
    setCandles([])
    setBlueprint(null)
    setSelectedIndex(null)
    const interval = nextRange === '5d' ? '5m' : '1d'
    const yahooSymbol = symbol.startsWith('^') ? symbol : `${symbol}.NS`
    const [candleRows, liveQuote] = await Promise.all([
      fetchCandleData(yahooSymbol, nextRange, interval),
      fetchLiveQuote(yahooSymbol),
    ])
    setCandles(candleRows)
    setQuote(liveQuote)
    setLoading(false)
  }

  useEffect(() => {
    load(resolvedSymbol, range)
  }, [resolvedSymbol, range])

  useEffect(() => {
    if (!selectedCandle || !quote) {
      setBlueprint(null)
      return
    }

    let cancelled = false
    setBlueprintLoading(true)
    buildMoveBlueprint({
      ticker: resolvedSymbol,
      candle: selectedCandle,
      quote,
      candles,
    })
      .then(result => {
        if (!cancelled) setBlueprint(result)
      })
      .catch(() => {
        if (!cancelled) setBlueprint(null)
      })
      .finally(() => {
        if (!cancelled) setBlueprintLoading(false)
      })

    return () => {
      cancelled = true
    }
  }, [candles, quote, resolvedSymbol, selectedCandle])

  const runAnalysis = async () => {
    if (!candles.length || !quote) return
    setAnalysing(true)
    const lastFive = candles.slice(-5).map(c => `${c.time}: O${c.open} H${c.high} L${c.low} C${c.close}`).join(', ')
    const text = await groqChat(
      'You are a technical analyst for NSE India. Be specific, cite price levels. Keep it under 110 words.',
      `${ticker} last 5 candles: ${lastFive}. Current quote: Rs ${quote.price} (${quote.chgPct}%). Analyse: 1) trend direction 2) key support/resistance 3) likely setup 4) one risk signal. Use **bold** for key levels.`
    )
    setAnalysis(text)
    setAnalysing(false)
  }

  const search = () => {
    const next = input.trim().toUpperCase()
    if (next) {
      setTicker(next)
      setInput(next)
      setAnalysis('')
    }
  }

  const stats = candles.length > 0
    ? {
        periodChange: candles.length > 1 ? (((candles[candles.length - 1].close - candles[0].close) / candles[0].close) * 100).toFixed(1) : '0',
        high: Math.max(...candles.map(c => c.high)).toFixed(2),
        low: Math.min(...candles.map(c => c.low)).toFixed(2),
        avgVolume: Math.round(candles.reduce((sum, candle) => sum + candle.volume, 0) / candles.length),
      }
    : null

  const tradeMap = selectedCandle ? buildTradeMap(selectedCandle, blueprint) : null

  return (
    <div className="overflow-hidden rounded-2xl border border-surface-500/50 bg-surface-700">
      <div className="flex items-center gap-3 border-b border-surface-500/40 px-4 py-3">
        <Activity size={14} className="text-brand-400" />
        <p className="text-xs font-semibold text-gray-300">{headerLabel}</p>
        <div className="ml-auto flex gap-1">
          {ranges.map(item => (
            <button
              key={item}
              onClick={() => setRange(item)}
              className={cn(
                'rounded border px-2 py-1 text-[10px] transition-all',
                range === item ? 'border-brand-500/30 bg-brand-500/10 text-brand-400' : 'border-surface-500 bg-surface-600 text-gray-500 hover:text-white',
              )}
            >
              {item}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4 p-4">
        <div className="flex gap-2">
          <input
            value={input}
            onChange={event => setInput(event.target.value.toUpperCase())}
            onKeyDown={event => event.key === 'Enter' && search()}
            placeholder="Any NSE symbol: RELIANCE, TCS, INFY, SBIN..."
            className="flex-1 rounded-lg border border-surface-500 bg-surface-600 px-3 py-2 text-xs text-white outline-none focus:border-brand-500/50"
          />
          <button onClick={search} className="rounded-lg bg-brand-500 px-4 py-2 text-surface-900 transition-colors hover:bg-brand-400">
            <Search size={13} />
          </button>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {['RELIANCE', 'TCS', 'INFY', 'HDFCBANK', 'SBIN', 'TATAMOTORS', 'NIFTY50'].map(item => (
            <button
              key={item}
              onClick={() => {
                setTicker(item)
                setInput(item)
                setAnalysis('')
              }}
              className={cn(
                'rounded-lg border px-2.5 py-1 text-[10px] transition-all',
                ticker === item ? 'border-brand-500/30 bg-brand-500/10 text-brand-400' : 'border-surface-500/40 bg-surface-600/50 text-gray-400 hover:text-white',
              )}
            >
              {item}
            </button>
          ))}
        </div>

        {quote && (
          <div className="flex flex-wrap items-center gap-4">
            <div>
              <p className="font-mono text-xl font-black text-white">Rs {quote.price.toLocaleString('en-IN')}</p>
              <div className="flex items-center gap-2">
                <span className={cn('text-sm font-mono font-bold', quote.chgPct >= 0 ? 'text-neon-green' : 'text-neon-red')}>
                  {quote.chgPct >= 0 ? '+' : ''}{quote.chg} ({quote.chgPct >= 0 ? '+' : ''}{quote.chgPct}%)
                </span>
                {quote.chgPct >= 0 ? <TrendingUp size={14} className="text-neon-green" /> : <TrendingDown size={14} className="text-neon-red" />}
              </div>
            </div>

            {stats && (
              <div className="ml-auto flex gap-4">
                {[
                  { label: 'Period High', value: `Rs ${stats.high}` },
                  { label: 'Period Low', value: `Rs ${stats.low}` },
                  { label: 'Avg Volume', value: `${(stats.avgVolume / 1e5).toFixed(1)}L` },
                  { label: 'Period Chg', value: `${parseFloat(stats.periodChange) >= 0 ? '+' : ''}${stats.periodChange}%` },
                ].map(item => (
                  <div key={item.label} className="text-center">
                    <p className="text-[9px] text-gray-500">{item.label}</p>
                    <p className="text-[11px] font-mono font-semibold text-gray-200">{item.value}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        <div className="relative overflow-hidden rounded-xl bg-surface-800/50" style={{ minHeight: 230 }}>
          {loading ? (
            <div className="absolute inset-0 flex items-center justify-center">
              <Loader2 size={20} className="animate-spin text-brand-400" />
            </div>
          ) : candles.length > 0 ? (
            <div className="p-2">
              <CandlestickChart
                candles={candles}
                selectedIndex={selectedIndex}
                onSelectCandle={setSelectedIndex}
                overlay={overlay}
                width={560}
                height={210}
              />
            </div>
          ) : (
            <div className="absolute inset-0 flex items-center justify-center text-xs text-gray-500">
              No data available for {ticker}
            </div>
          )}

          {selectedCandle && blueprint && !loading && (
            <div className="pointer-events-none absolute left-3 top-3 right-3 flex flex-wrap gap-2">
              {[
                { label: 'Domestic', value: blueprint.domestic[0]?.title ?? 'Monitor', tone: 'border-blue-400/30 bg-blue-500/15 text-blue-200' },
                { label: 'Global', value: blueprint.global[0]?.title ?? 'Monitor', tone: 'border-purple-400/30 bg-purple-500/15 text-purple-200' },
                { label: 'Sector', value: blueprint.sector[0]?.title ?? 'Monitor', tone: 'border-emerald-400/30 bg-emerald-500/15 text-emerald-200' },
                { label: 'Company', value: blueprint.company[0]?.title ?? 'Monitor', tone: 'border-amber-400/30 bg-amber-500/15 text-amber-200' },
              ].map(item => (
                <div key={item.label} className={cn('rounded-xl border px-3 py-2 shadow-card backdrop-blur-sm', item.tone)}>
                  <p className="text-[9px] font-semibold uppercase tracking-[0.16em] opacity-80">{item.label}</p>
                  <p className="max-w-[148px] truncate text-[11px] font-medium">{item.value}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2">
          <button
            onClick={runAnalysis}
            disabled={analysing || !candles.length}
            className="flex items-center gap-2 rounded-lg border border-brand-500/20 bg-brand-500/10 px-3 py-2 text-xs text-brand-400 transition-colors hover:bg-brand-500/20 disabled:opacity-40"
          >
            {analysing ? <Loader2 size={11} className="animate-spin" /> : <BrainCircuit size={11} />}
            {analysing ? 'Groq analysing...' : 'AI Technical Analysis'}
          </button>
          <a
            href={`https://www.tradingview.com/chart/?symbol=${resolvedSymbol.startsWith('^') ? 'NSE:NIFTY' : `NSE:${resolvedSymbol}`}`}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 text-[10px] text-gray-500 transition-colors hover:text-white"
          >
            <BarChart2 size={11} />
            Open in TradingView
            <ExternalLink size={10} />
          </a>
        </div>

        {overlay && (
          <div className="rounded-xl border border-blue-400/20 bg-blue-500/8 px-3 py-2 text-[11px] text-blue-200">
            {overlay.note}
          </div>
        )}

        <AnimatePresence>
          {analysis && (
            <motion.div
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              className="rounded-xl border border-brand-500/20 bg-brand-500/5 p-3"
            >
              <p className="mb-1.5 text-[10px] font-semibold text-brand-400">Groq Technical Analysis - {ticker}</p>
              <p
                className="text-[11px] leading-relaxed text-gray-300"
                dangerouslySetInnerHTML={{ __html: analysis.replace(/\*\*(.*?)\*\*/g, '<strong class="text-white">$1</strong>').replace(/\n/g, '<br/>') }}
              />
            </motion.div>
          )}
        </AnimatePresence>

        <div className="rounded-2xl border border-surface-500/50 bg-surface-800/70 p-4">
          <div className="mb-3 flex items-center justify-between gap-3">
            <div>
              <p className="text-[11px] uppercase tracking-[0.18em] text-gray-500">Move Blueprint</p>
              <h3 className="mt-1 text-sm font-bold text-white">
                Click any candle to inspect domestic, global, sector, and company drivers
              </h3>
            </div>
            {blueprintLoading && <Loader2 size={15} className="animate-spin text-brand-300" />}
          </div>

          {selectedCandle ? (
            <div className="space-y-4">
              <div className="flex flex-wrap gap-2">
                <span className="rounded-full border border-surface-500 bg-surface-700 px-3 py-1 text-xs text-gray-300">
                  Candle: {selectedCandle.time}
                </span>
                <span className="rounded-full border border-brand-400/20 bg-brand-500/10 px-3 py-1 text-xs text-brand-300">
                  Move: {(((selectedCandle.close - selectedCandle.open) / selectedCandle.open) * 100).toFixed(2)}%
                </span>
                {blueprint && (
                  <span className="rounded-full border border-blue-400/20 bg-blue-500/10 px-3 py-1 text-xs text-blue-300">
                    Confidence: {blueprint.confidence}/100
                  </span>
                )}
              </div>

              {blueprint ? (
                <>
                  <BlueprintVisual
                    ticker={ticker}
                    moveType={blueprint.moveType}
                    domestic={blueprint.domestic}
                    global={blueprint.global}
                    sector={blueprint.sector}
                    company={blueprint.company}
                  />

                  <div className="rounded-xl border border-surface-500/50 bg-surface-700/60 p-3">
                    <p className="text-sm leading-6 text-gray-200">{blueprint.summary}</p>
                  </div>

                  {tradeMap && (
                    <div className="rounded-xl border border-brand-400/20 bg-[linear-gradient(180deg,rgba(255,198,26,0.08),rgba(17,24,39,0.9))] p-4">
                      <div className="mb-3 flex items-center gap-2">
                        <BarChart2 size={14} className="text-brand-300" />
                        <p className="text-sm font-bold text-white">Trade Map</p>
                      </div>
                      <div className="grid gap-3 sm:grid-cols-5">
                        <div className="rounded-lg border border-surface-500/40 bg-surface-800/70 p-3">
                          <p className="text-[10px] uppercase tracking-[0.16em] text-gray-500">Entry</p>
                          <p className="mt-1 font-mono text-sm font-bold text-white">Rs {tradeMap.entry.toFixed(2)}</p>
                        </div>
                        <div className="rounded-lg border border-neon-red/20 bg-neon-red/10 p-3">
                          <p className="text-[10px] uppercase tracking-[0.16em] text-neon-red">Stop</p>
                          <p className="mt-1 font-mono text-sm font-bold text-neon-red">Rs {tradeMap.stopLoss.toFixed(2)}</p>
                        </div>
                        <div className="rounded-lg border border-blue-400/20 bg-blue-500/10 p-3">
                          <p className="text-[10px] uppercase tracking-[0.16em] text-blue-300">Target 1</p>
                          <p className="mt-1 font-mono text-sm font-bold text-blue-200">Rs {tradeMap.target1.toFixed(2)}</p>
                        </div>
                        <div className="rounded-lg border border-brand-400/20 bg-brand-500/10 p-3">
                          <p className="text-[10px] uppercase tracking-[0.16em] text-brand-300">Target 2</p>
                          <p className="mt-1 font-mono text-sm font-bold text-brand-200">Rs {tradeMap.target2.toFixed(2)}</p>
                        </div>
                        <div className="rounded-lg border border-emerald-400/20 bg-emerald-500/10 p-3">
                          <p className="text-[10px] uppercase tracking-[0.16em] text-emerald-300">Risk/Reward</p>
                          <p className="mt-1 font-mono text-sm font-bold text-emerald-200">{tradeMap.riskReward}</p>
                        </div>
                      </div>
                      <div className="mt-3 rounded-lg border border-surface-500/40 bg-surface-800/70 p-3 text-[11px] leading-5 text-gray-300">
                        {tradeMap.confirmation}
                      </div>
                    </div>
                  )}

                  <div className="grid gap-3 md:grid-cols-2">
                    {[
                      { label: 'Domestic Factors', items: blueprint.domestic, tone: 'text-blue-300' },
                      { label: 'Global Factors', items: blueprint.global, tone: 'text-purple-300' },
                      { label: 'Sector Forces', items: blueprint.sector, tone: 'text-emerald-300' },
                      { label: 'Company Triggers', items: blueprint.company, tone: 'text-amber-300' },
                    ].map(section => (
                      <div key={section.label} className="rounded-xl border border-surface-500/50 bg-surface-700/60 p-3">
                        <p className={cn('text-[11px] font-semibold uppercase tracking-[0.16em]', section.tone)}>{section.label}</p>
                        <div className="mt-3 grid gap-2">
                          {section.items.map(item => (
                            <div key={`${section.label}-${item.title}`} className="rounded-lg border border-surface-500/40 bg-surface-800/70 p-2.5">
                              <p className="text-xs font-semibold text-white">{item.title}</p>
                              <p className="mt-1 text-[11px] leading-5 text-gray-400">{item.impact}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="grid gap-3 lg:grid-cols-[1fr_1.1fr]">
                    <div className="rounded-xl border border-surface-500/50 bg-surface-700/60 p-3">
                      <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-gray-400">What To Verify Next</p>
                      <div className="mt-3 flex flex-wrap gap-2">
                        {blueprint.verify.map(item => (
                          <span key={item} className="rounded-full border border-neon-red/20 bg-neon-red/10 px-3 py-1 text-xs text-neon-red">
                            {item}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="rounded-xl border border-surface-500/50 bg-surface-700/60 p-3">
                      <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-gray-400">Supporting Headlines</p>
                      <div className="mt-3 space-y-2">
                        {blueprint.headlines.length > 0 ? blueprint.headlines.map(item => (
                          <div key={item} className="rounded-lg border border-surface-500/40 bg-surface-800/70 px-3 py-2 text-[11px] text-gray-300">
                            {item}
                          </div>
                        )) : (
                          <div className="rounded-lg border border-dashed border-surface-500 px-3 py-3 text-[11px] text-gray-500">
                            No linked headlines were returned, so the blueprint leans more on technical-flow interpretation.
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </>
              ) : (
                <div className="rounded-xl border border-dashed border-surface-500 px-4 py-6 text-sm text-gray-500">
                  {blueprintLoading ? 'Building stock blueprint from candles and related headlines...' : 'Select a candle to build the explanation blueprint.'}
                </div>
              )}
            </div>
          ) : (
            <div className="rounded-xl border border-dashed border-surface-500 px-4 py-6 text-sm text-gray-500">
              Click a candle to open the blueprint and trade map for that move.
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
