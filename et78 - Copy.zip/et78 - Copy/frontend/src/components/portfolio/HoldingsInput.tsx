import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Plus, Trash2, RefreshCw, CheckCircle2, Upload, ExternalLink } from 'lucide-react'
import { useStore } from '@/store'
import { fetchLivePortfolio, PORTFOLIO_TICKERS, cn, formatINR } from '@/lib/api'

interface ManualHolding {
  ticker: string
  qty:    string
  avgCost:string
}

const COMMON_TICKERS = [
  'RELIANCE','TCS','INFY','HDFCBANK','ICICIBANK','TATAMOT',
  'WIPRO','ZOMATO','BAJFINANCE','ADANIPORTS','HINDUNILVR',
  'MARUTI','AXISBANK','SUNPHARMA','LTIM','KOTAKBANK',
]

export default function HoldingsInput({ onDone }: { onDone: () => void }) {
  const { setPortfolio, setPortfolioLoading } = useStore()
  const [rows, setRows] = useState<ManualHolding[]>([
    { ticker: '', qty: '', avgCost: '' },
  ])
  const [loading, setLoading] = useState(false)
  const [saved, setSaved]     = useState(false)
  const [error, setError]     = useState<string | null>(null)

  const addRow = () => setRows(r => [...r, { ticker: '', qty: '', avgCost: '' }])
  const removeRow = (i: number) => setRows(r => r.filter((_, idx) => idx !== i))
  const updateRow = (i: number, field: keyof ManualHolding, val: string) =>
    setRows(r => r.map((row, idx) => idx === i ? { ...row, [field]: val } : row))

  const loadLivePrices = async () => {
    const valid = rows.filter(r => r.ticker.trim() && r.qty.trim() && r.avgCost.trim())
    if (!valid.length) { setError('Add at least one holding'); return }
    setLoading(true)
    setError(null)

    try {
      // Build Yahoo Finance symbols for user's tickers
      const customTickers = valid.map(r => ({
        ticker: r.ticker.toUpperCase().trim(),
        yfSym:  r.ticker.toUpperCase().trim() + '.NS',
        name:   r.ticker.toUpperCase().trim(),
        qty:    parseInt(r.qty),
        avgCost:parseFloat(r.avgCost),
        sector: 'Equity',
      }))

      // Fetch live prices via Yahoo Finance
      const { fetchMultipleQuotes } = await import('@/lib/api')
      const quotes = await fetchMultipleQuotes(customTickers.map(t => t.yfSym))

      const holdings = customTickers.map(t => {
        const q            = quotes[t.yfSym]
        const ltp          = q?.price ?? t.avgCost
        const currentValue = +(ltp * t.qty).toFixed(0)
        const invested     = t.avgCost * t.qty
        const pnl          = +(currentValue - invested).toFixed(0)
        const pnlPct       = +((pnl / invested) * 100).toFixed(2)
        return { ...t, ltp: +ltp.toFixed(2), currentValue, pnl, pnlPct, weight: 0 }
      })

      const total = holdings.reduce((s, h) => s + h.currentValue, 0)
      const withWeight = holdings.map(h => ({
        ...h, weight: +((h.currentValue / total) * 100).toFixed(1)
      }))

      const totalValue    = total
      const totalInvested = holdings.reduce((s, h) => s + h.avgCost * h.qty, 0)
      const totalPnl      = totalValue - totalInvested

      setPortfolio({
        holdings:       withWeight,
        totalValue,
        totalInvested,
        overallPnl:     totalPnl,
        overallPnlPct:  +((totalPnl / totalInvested) * 100).toFixed(2),
        overallXirr:    0,   // needs proper XIRR calculation
        healthScore:    65,
        loaded:         true,
      })

      setSaved(true)
      setTimeout(onDone, 1200)
    } catch (e: any) {
      setError('Failed to fetch prices. Check your internet connection.')
    } finally {
      setLoading(false)
    }
  }

  const useDefaultData = async () => {
    setLoading(true)
    try {
      const holdings = await fetchLivePortfolio()
      const totalValue    = holdings.reduce((s, h) => s + h.currentValue, 0)
      const totalInvested = holdings.reduce((s, h) => s + h.avgCost * h.qty, 0)
      const totalPnl      = totalValue - totalInvested
      setPortfolio({
        holdings, totalValue, totalInvested,
        overallPnl: totalPnl,
        overallPnlPct: +((totalPnl / totalInvested) * 100).toFixed(2),
        overallXirr: 18.4, healthScore: 72, loaded: true,
      })
      setSaved(true)
      setTimeout(onDone, 1000)
    } catch {
      setError('Price fetch failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-5 space-y-4">
      <div>
        <h3 className="text-sm font-bold text-white">Enter your real holdings</h3>
        <p className="text-[11px] text-gray-400 mt-0.5">
          Live prices are fetched from NSE via Yahoo Finance automatically
        </p>
      </div>

      {/* Manual entry table */}
      <div className="space-y-2">
        <div className="grid grid-cols-12 gap-2 px-1">
          <span className="col-span-5 text-[10px] text-gray-500 uppercase">Ticker</span>
          <span className="col-span-3 text-[10px] text-gray-500 uppercase">Qty</span>
          <span className="col-span-3 text-[10px] text-gray-500 uppercase">Avg Cost ₹</span>
          <span className="col-span-1" />
        </div>

        {rows.map((row, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            className="grid grid-cols-12 gap-2 items-center"
          >
            {/* Ticker autocomplete */}
            <div className="col-span-5 relative">
              <input
                list={`tickers-${i}`}
                value={row.ticker}
                onChange={e => updateRow(i, 'ticker', e.target.value.toUpperCase())}
                placeholder="RELIANCE"
                className="w-full bg-surface-600 border border-surface-500 rounded-lg px-2.5 py-2 text-xs text-white placeholder-gray-600 focus:outline-none focus:border-brand-500 font-mono uppercase"
              />
              <datalist id={`tickers-${i}`}>
                {COMMON_TICKERS.map(t => <option key={t} value={t} />)}
              </datalist>
            </div>
            <input
              type="number"
              value={row.qty}
              onChange={e => updateRow(i, 'qty', e.target.value)}
              placeholder="100"
              className="col-span-3 bg-surface-600 border border-surface-500 rounded-lg px-2.5 py-2 text-xs text-white placeholder-gray-600 focus:outline-none focus:border-brand-500 font-mono"
            />
            <input
              type="number"
              value={row.avgCost}
              onChange={e => updateRow(i, 'avgCost', e.target.value)}
              placeholder="2000"
              className="col-span-3 bg-surface-600 border border-surface-500 rounded-lg px-2.5 py-2 text-xs text-white placeholder-gray-600 focus:outline-none focus:border-brand-500 font-mono"
            />
            <button
              onClick={() => removeRow(i)}
              disabled={rows.length === 1}
              className="col-span-1 p-1.5 text-gray-600 hover:text-neon-red transition-colors disabled:opacity-30"
            >
              <Trash2 size={12} />
            </button>
          </motion.div>
        ))}
      </div>

      <button
        onClick={addRow}
        className="flex items-center gap-1.5 text-xs text-brand-400 hover:text-brand-300 transition-colors"
      >
        <Plus size={13} /> Add stock
      </button>

      {error && (
        <p className="text-xs text-neon-red bg-neon-red/10 border border-neon-red/20 rounded-lg px-3 py-2">
          {error}
        </p>
      )}

      <div className="flex items-center gap-3 pt-1">
        <button
          onClick={loadLivePrices}
          disabled={loading || saved}
          className={cn(
            'flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all',
            saved
              ? 'bg-neon-green/10 border border-neon-green/20 text-neon-green'
              : 'bg-brand-500 text-surface-900 hover:bg-brand-400 disabled:opacity-50'
          )}
        >
          {saved ? (
            <><CheckCircle2 size={13} /> Loaded with live prices</>
          ) : loading ? (
            <><RefreshCw size={13} className="animate-spin" /> Fetching NSE prices...</>
          ) : (
            <><RefreshCw size={13} /> Load live prices</>
          )}
        </button>

        <span className="text-gray-600 text-xs">or</span>

        <button
          onClick={useDefaultData}
          disabled={loading}
          className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-white border border-surface-500 hover:border-surface-400 px-3 py-2 rounded-lg transition-all"
        >
          Use demo holdings
        </button>
      </div>

      {/* Browser agent option */}
      <div className="border-t border-surface-500/30 pt-3">
        <p className="text-[10px] text-gray-500 mb-2">
          Or import directly from your broker (requires backend running):
        </p>
        <div className="flex gap-2">
          {['zerodha', 'sharekhan', 'groww', 'angel'].map(p => (
            <button
              key={p}
              onClick={() => {
                window.open(`http://localhost:8000/api/browser/launch?platform=${p}`, '_blank')
              }}
              className="flex items-center gap-1 text-[10px] bg-surface-600 border border-surface-500 text-gray-400 hover:text-white px-2.5 py-1.5 rounded-lg capitalize transition-colors"
            >
              <ExternalLink size={9} /> {p}
            </button>
          ))}
        </div>
        <p className="text-[9px] text-gray-600 mt-1.5">
          Run <code className="bg-surface-600 px-1 rounded text-brand-300">python backend/tools/browser_agent.py zerodha</code> to auto-import
        </p>
      </div>
    </div>
  )
}
