import { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Area, AreaChart, ResponsiveContainer } from 'recharts'
import { BarChart3, BrainCircuit, CalendarClock, ExternalLink, Globe2, Loader2, Minus, RefreshCw, Search, SplitSquareHorizontal, TrendingDown, TrendingUp, Zap } from 'lucide-react'
import { useStore } from '@/store'
import { analyzeTickerWithAI, cn, fetchMarketDashboard, groqChat, timeAgo, type MarketIndicator } from '@/lib/api'
import type { Signal } from '@/store'

const TYPE_COLORS: Record<string, string> = {
  insider_trade: 'text-purple-400 bg-purple-500/10 border-purple-500/20',
  bulk_deal: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
  pattern: 'text-brand-400 bg-brand-500/10 border-brand-500/20',
  fundamental: 'text-teal-400 bg-teal-500/10 border-teal-500/20',
  alert: 'text-orange-400 bg-orange-500/10 border-orange-500/20',
}

const TYPE_LABELS: Record<string, string> = {
  insider_trade: 'Insider Trade',
  bulk_deal: 'Bulk Deal',
  pattern: 'Chart Pattern',
  fundamental: 'Fundamental',
  alert: 'Risk Alert',
}

const FALLBACK_EARNINGS = [
  { ticker: 'RELIANCE', note: 'Watch the next result cycle for margin commentary, retail traction, and Jio subscriber monetization.', source: 'ET Alpha', url: 'https://www.nseindia.com/' },
  { ticker: 'TCS', note: 'Track deal wins, BFSI demand, and management commentary for short-term earnings sentiment.', source: 'ET Alpha', url: 'https://www.nseindia.com/' },
  { ticker: 'INFY', note: 'Guidance changes and client spending commentary remain the key earnings volatility trigger.', source: 'ET Alpha', url: 'https://www.nseindia.com/' },
]
const newsCache = new Map<string, Array<{ title: string; publisher: string; link: string }>>()

function withTimeout<T>(promise: Promise<T>, ms = 8000): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => setTimeout(() => reject(new Error('timeout')), ms)),
  ])
}

async function fetchTickerNews(symbol: string) {
  const query = symbol.replace('.NS', '').replace('^', '')
  if (newsCache.has(query)) return newsCache.get(query)!
  try {
    const res = await withTimeout(fetch(`/yf/v1/finance/search?q=${encodeURIComponent(query)}&quotesCount=1&newsCount=6`), 3500)
    const data = await res.json()
    const items = (data?.news ?? []).slice(0, 5).map((item: any) => ({
      title: item.title as string,
      publisher: item.publisher as string,
      link: item.link as string,
    }))
    newsCache.set(query, items)
    return items
  } catch {
    return []
  }
}

function makeSparkline(id: string, sentiment: string) {
  let value = 100
  const seed = id.split('').reduce((sum, char) => sum + char.charCodeAt(0), 0)
  return Array.from({ length: 20 }, (_, index) => {
    value += (Math.sin(index * seed * 0.1) + (Math.random() - (sentiment === 'bearish' ? 0.55 : 0.45))) * 1.5
    return { value: Math.max(80, Math.min(130, value)) }
  })
}

function parseJsonArray<T>(text: string) {
  const match = text.match(/\[[\s\S]*\]/)
  if (!match) return [] as T[]
  try {
    return JSON.parse(match[0]) as T[]
  } catch {
    return [] as T[]
  }
}

function buildLocalCompareSummary(rows: MarketIndicator[]) {
  if (rows.length === 0) return 'No live rows are available for comparison.'
  const ranked = [...rows].sort((a, b) => b.conviction - a.conviction)
  const strongest = ranked[0]
  const weakest = ranked[ranked.length - 1]
  return `${strongest.ticker} looks strongest right now with ${strongest.conviction}/100 conviction, ${strongest.setup.toLowerCase()}, and RSI ${strongest.rsi}. ${weakest.ticker} is the weakest among this set with ${weakest.conviction}/100 conviction and ${weakest.trend} structure. Best risk-reward usually sits with the name that has bullish trend alignment plus support close to price.`
}

function buildLocalWatchlist(theme: string, rows: MarketIndicator[]) {
  const lower = theme.toLowerCase()
  const tokens = lower.split(/[^a-z]+/).filter(Boolean)
  return rows
    .map(row => {
      const haystack = `${row.company} ${row.sector} ${row.setup}`.toLowerCase()
      const themeHits = tokens.filter(token => haystack.includes(token)).length
      const score = row.conviction + themeHits * 10 + (row.trend === 'bullish' ? 6 : 0)
      return {
        ticker: row.ticker,
        reason: `${row.company} fits through ${row.sector.toLowerCase()} exposure, ${row.setup.toLowerCase()}, and ${row.conviction}/100 conviction.`,
        trigger: `Watch ${row.ticker} near support Rs ${row.support.toFixed(2)} and resistance Rs ${row.resistance.toFixed(2)}.`,
        score,
      }
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, 5)
    .map(({ ticker, reason, trigger }) => ({ ticker, reason, trigger }))
}

function summarizeSectorRotation(rows: MarketIndicator[]) {
  const grouped = rows.reduce<Record<string, { count: number; conviction: number; momentum: number; advancers: number }>>((acc, row) => {
    const key = row.sector
    if (!acc[key]) acc[key] = { count: 0, conviction: 0, momentum: 0, advancers: 0 }
    acc[key].count += 1
    acc[key].conviction += row.conviction
    acc[key].momentum += row.momentum5d
    if (row.changePct >= 0) acc[key].advancers += 1
    return acc
  }, {})

  return Object.entries(grouped).map(([sector, value]) => ({
    sector,
    avgConviction: +(value.conviction / value.count).toFixed(1),
    avgMomentum: +(value.momentum / value.count).toFixed(1),
    breadth: +((value.advancers / value.count) * 100).toFixed(0),
  })).sort((a, b) => b.avgConviction - a.avgConviction)
}

export function SignalCard({ signal, index }: { signal: Signal; index: number }) {
  const [open, setOpen] = useState(false)
  const [analysis, setAnalysis] = useState('')
  const [analysing, setAnalysing] = useState(false)
  const sparkline = useMemo(() => makeSparkline(signal.id, signal.sentiment), [signal.id, signal.sentiment])
  const color = signal.sentiment === 'bullish' ? '#00e676' : signal.sentiment === 'bearish' ? '#ff3d57' : '#888780'

  const runDeepAnalysis = async (event: React.MouseEvent) => {
    event.stopPropagation()
    setAnalysing(true)
    setOpen(true)
    try {
      const text = await groqChat(
        'You are an elite NSE India market analyst. Be specific, cite real numbers, and give a clear verdict.',
        `Deep analysis for ${signal.ticker} (${signal.company}):
Signal: ${signal.headline}
Context: ${signal.detail}
Sentiment: ${signal.sentiment} | Strength: ${signal.strength}/100

Provide: 1) signal meaning 2) key risks 3) price target range 4) final verdict.
Keep it under 150 words.`
      )
      setAnalysis(text)
    } catch {
      setAnalysis('Analysis failed. Please retry.')
    } finally {
      setAnalysing(false)
    }
  }

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.03 }} className={cn('overflow-hidden rounded-xl border bg-surface-700 transition-all duration-200', signal.actionable ? 'border-surface-500/80 hover:border-brand-500/40' : 'border-surface-500/30 hover:border-surface-400/50')} onClick={() => setOpen(value => !value)}>
      <div className="flex items-start gap-3 p-4">
        <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg border border-surface-500/50 bg-surface-600">
          <span className="text-[9px] font-black text-white">{signal.ticker?.slice(0, 5)}</span>
        </div>
        <div className="min-w-0 flex-1">
          <div className="mb-1 flex flex-wrap items-center gap-1.5">
            <span className={cn('rounded border px-1.5 py-0.5 text-[10px] font-medium', TYPE_COLORS[signal.type] || 'text-gray-400 bg-surface-600 border-surface-500')}>
              {TYPE_LABELS[signal.type] || signal.type}
            </span>
            {signal.actionable && <span className="flex items-center gap-1 rounded border border-brand-500/30 bg-brand-500/10 px-1.5 py-0.5 text-[10px] font-bold text-brand-400"><Zap size={8} />ACTIONABLE</span>}
            <span className="text-[10px] text-gray-500">{timeAgo(signal.timestamp)}</span>
          </div>
          <p className="text-sm font-semibold leading-snug text-white">{signal.headline}</p>
          <p className="mt-0.5 text-[11px] text-gray-400">{signal.company} · {signal.source}</p>
        </div>
        <div className="flex flex-shrink-0 flex-col items-end gap-1.5">
          <div className="h-8 w-20">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={sparkline}>
                <defs><linearGradient id={`g-${signal.id}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={color} stopOpacity={0.3} /><stop offset="100%" stopColor={color} stopOpacity={0} /></linearGradient></defs>
                <Area type="monotone" dataKey="value" stroke={color} strokeWidth={1.5} fill={`url(#g-${signal.id})`} dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="h-1.5 w-16 overflow-hidden rounded-full bg-surface-600"><motion.div className="h-full rounded-full" initial={{ width: 0 }} animate={{ width: `${signal.strength}%` }} transition={{ delay: index * 0.03 + 0.3, duration: 0.6 }} style={{ backgroundColor: signal.strength > 70 ? color : '#888780' }} /></div>
            <span className="text-[10px] font-mono text-gray-400">{signal.strength}</span>
          </div>
          <span className={cn('flex items-center gap-1 text-[10px] font-medium capitalize', signal.sentiment === 'bullish' ? 'text-neon-green' : signal.sentiment === 'bearish' ? 'text-neon-red' : 'text-gray-400')}>
            {signal.sentiment === 'bullish' ? <TrendingUp size={10} /> : signal.sentiment === 'bearish' ? <TrendingDown size={10} /> : <Minus size={10} />}
            {signal.sentiment}
          </span>
        </div>
      </div>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden border-t border-surface-500/40">
            <div className="space-y-3 bg-surface-800/60 p-4">
              <p className="text-sm leading-relaxed text-gray-300">{signal.detail}</p>
              {(analysing || analysis) && <div className="rounded-lg border border-brand-500/20 bg-brand-500/5 p-3"><p className="mb-1.5 flex items-center gap-1 text-[10px] font-semibold text-brand-400"><BrainCircuit size={11} />Groq Deep Analysis</p>{analysing ? <div className="flex items-center gap-2 text-xs text-gray-400"><Loader2 size={12} className="animate-spin" />Analysing...</div> : <p className="whitespace-pre-wrap text-[11px] leading-relaxed text-gray-300">{analysis}</p>}</div>}
              <div className="flex items-center gap-2">
                <button onClick={runDeepAnalysis} disabled={analysing} className="flex items-center gap-1.5 rounded-lg border border-brand-500/20 bg-brand-500/10 px-3 py-1.5 text-xs text-brand-400 transition-colors hover:bg-brand-500/20 disabled:opacity-50">{analysing ? <Loader2 size={11} className="animate-spin" /> : <BrainCircuit size={11} />}{analysing ? 'Analysing...' : 'Deep Analysis'}</button>
                <a href={`https://www.nseindia.com/get-quotes/equity?symbol=${signal.ticker}`} target="_blank" rel="noopener noreferrer" onClick={event => event.stopPropagation()} className="flex items-center gap-1.5 rounded-lg border border-surface-500 bg-surface-600 px-3 py-1.5 text-xs text-gray-300 transition-colors hover:bg-surface-500"><ExternalLink size={11} />NSE Page</a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

export function CompareBoard() {
  const [selectedTickers, setSelectedTickers] = useState<string[]>(['RELIANCE', 'TCS', 'INFY'])
  const [input, setInput] = useState('')
  const [rows, setRows] = useState<MarketIndicator[]>([])
  const [loading, setLoading] = useState(true)
  const [analysis, setAnalysis] = useState('')
  const [analysing, setAnalysing] = useState(false)

  useEffect(() => {
    setLoading(true)
    withTimeout(fetchMarketDashboard(selectedTickers))
      .then(data => setRows(data.indicators))
      .catch(() => setRows([]))
      .finally(() => setLoading(false))
  }, [selectedTickers])

  const addTicker = () => {
    const next = input.trim().toUpperCase()
    if (!next || selectedTickers.includes(next) || selectedTickers.length >= 4) return
    setSelectedTickers(prev => [...prev, next]); setInput('')
  }

  const runCompareAnalysis = async () => {
    if (!rows.length) return
    setAnalysing(true)
    try {
      const context = rows.map(row => `${row.ticker}: change ${row.changePct}%, RSI ${row.rsi}, setup ${row.setup}, conviction ${row.conviction}`).join('\n')
      setAnalysis(await groqChat('You compare Indian equity setups directly.', `Compare these stocks and rank strongest, weakest, and best risk-reward.\n${context}`))
    } catch {
      setAnalysis(buildLocalCompareSummary(rows))
    } finally {
      setAnalysing(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-surface-500/50 bg-surface-700 p-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div><p className="text-[11px] uppercase tracking-[0.18em] text-gray-500">Compare Mode</p><h3 className="mt-1 text-lg font-bold text-white">Multi-stock compare board</h3></div>
          <div className="flex gap-2">
            <input value={input} onChange={event => setInput(event.target.value)} onKeyDown={event => event.key === 'Enter' && addTicker()} placeholder="Add ticker" className="rounded-lg border border-surface-500 bg-surface-800 px-3 py-2 text-xs text-white outline-none focus:border-brand-500/50" />
            <button onClick={addTicker} className="rounded-lg bg-brand-500 px-3 py-2 text-surface-900 transition hover:bg-brand-400"><Search size={12} /></button>
            <button onClick={runCompareAnalysis} disabled={analysing || rows.length === 0} className="flex items-center gap-1.5 rounded-lg border border-brand-500/20 bg-brand-500/10 px-3 py-2 text-xs text-brand-400 transition hover:bg-brand-500/20 disabled:opacity-50">{analysing ? <Loader2 size={11} className="animate-spin" /> : <BrainCircuit size={11} />}AI compare</button>
          </div>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">{selectedTickers.map(ticker => <button key={ticker} onClick={() => setSelectedTickers(prev => prev.filter(item => item !== ticker))} className="rounded-full border border-surface-500 bg-surface-800 px-3 py-1 text-xs text-gray-300 transition hover:border-neon-red/30 hover:text-neon-red">{ticker} ×</button>)}</div>
      </div>
      <div className="grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
        <div className="grid gap-4 md:grid-cols-2">
          {loading ? <div className="col-span-full flex min-h-[220px] items-center justify-center rounded-2xl border border-surface-500/50 bg-surface-700 text-gray-400"><Loader2 size={18} className="animate-spin" /></div> : rows.map(row => (
            <div key={row.ticker} className="rounded-2xl border border-surface-500/50 bg-surface-700 p-4">
              <div className="flex items-start justify-between gap-3"><div><p className="text-lg font-black text-white">{row.ticker}</p><p className="text-xs text-gray-500">{row.company}</p></div><span className={cn('text-sm font-bold', row.changePct >= 0 ? 'text-neon-green' : 'text-neon-red')}>{row.changePct >= 0 ? '+' : ''}{row.changePct}%</span></div>
              <div className="mt-4 grid grid-cols-2 gap-3">{[{ label: 'RSI', value: row.rsi, tone: row.rsi >= 65 ? 'text-neon-green' : row.rsi <= 35 ? 'text-neon-red' : 'text-white' }, { label: 'Conviction', value: row.conviction, tone: 'text-brand-400' }, { label: 'Support', value: `Rs ${row.support.toFixed(2)}`, tone: 'text-blue-300' }, { label: 'Resistance', value: `Rs ${row.resistance.toFixed(2)}`, tone: 'text-orange-300' }].map(item => <div key={`${row.ticker}-${item.label}`} className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-3"><p className="text-[10px] uppercase tracking-[0.16em] text-gray-500">{item.label}</p><p className={cn('mt-1 text-sm font-bold', item.tone)}>{item.value}</p></div>)}</div>
              <div className="mt-4 rounded-xl border border-surface-500/40 bg-surface-800/70 p-3"><p className="text-[10px] uppercase tracking-[0.16em] text-gray-500">Setup</p><p className="mt-1 text-sm font-semibold text-white">{row.setup}</p></div>
            </div>
          ))}
        </div>
        <div className="space-y-4">
          <div className="rounded-2xl border border-surface-500/50 bg-surface-700 p-4"><div className="mb-3 flex items-center gap-2"><SplitSquareHorizontal size={14} className="text-brand-300" /><p className="text-sm font-bold text-white">AI Compare Verdict</p></div><p className="whitespace-pre-wrap text-sm leading-6 text-gray-300">{analysis || 'Run AI compare to rank the selected stocks.'}</p></div>
        </div>
      </div>
    </div>
  )
}

export function RotationBoard() {
  const [rows, setRows] = useState<MarketIndicator[]>([])
  const [loading, setLoading] = useState(true)
  useEffect(() => {
    setLoading(true)
    withTimeout(fetchMarketDashboard())
      .then(data => setRows(data.indicators))
      .catch(() => setRows([]))
      .finally(() => setLoading(false))
  }, [])
  const sectors = useMemo(() => summarizeSectorRotation(rows), [rows])
  return loading ? (
    <div className="flex min-h-[220px] items-center justify-center rounded-2xl border border-surface-500/50 bg-surface-700 text-gray-400">
      <Loader2 size={18} className="animate-spin" />
    </div>
  ) : sectors.length > 0 ? (
    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
      {sectors.map(item => (
        <div key={item.sector} className="rounded-2xl border border-surface-500/50 bg-surface-700 p-4">
          <div className="flex items-center justify-between">
            <p className="text-lg font-bold text-white">{item.sector}</p>
            <span className={cn('text-sm font-semibold', item.avgMomentum >= 0 ? 'text-neon-green' : 'text-neon-red')}>
              {item.avgMomentum >= 0 ? '+' : ''}{item.avgMomentum}%
            </span>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <div className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-3">
              <p className="text-[10px] uppercase tracking-[0.16em] text-gray-500">Conviction</p>
              <p className="mt-1 font-mono text-sm font-bold text-brand-400">{item.avgConviction}</p>
            </div>
            <div className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-3">
              <p className="text-[10px] uppercase tracking-[0.16em] text-gray-500">Breadth</p>
              <p className="mt-1 font-mono text-sm font-bold text-white">{item.breadth}%</p>
            </div>
          </div>
          <div className="mt-4 h-2 overflow-hidden rounded-full bg-surface-800">
            <div className={cn('h-full rounded-full', item.avgMomentum >= 0 ? 'bg-neon-green' : 'bg-neon-red')} style={{ width: `${Math.min(100, Math.abs(item.avgMomentum) * 8 + item.avgConviction / 2)}%` }} />
          </div>
        </div>
      ))}
    </div>
  ) : (
    <div className="rounded-2xl border border-dashed border-surface-500 px-4 py-8 text-sm text-gray-500">
      Rotation data is not available right now. Refresh `Signals` once, then come back here.
    </div>
  )
}

export function EventHeatmap() {
  const { signals } = useStore()
  const [theme, setTheme] = useState('crude oil spike')
  const [rows, setRows] = useState<MarketIndicator[]>([])
  const [loading, setLoading] = useState(false)
  const [events, setEvents] = useState<Array<{ ticker: string; impact: 'bullish' | 'bearish' | 'neutral'; reason: string; confidence: number }>>([])
  useEffect(() => {
    withTimeout(fetchMarketDashboard())
      .then(data => setRows(data.indicators))
      .catch(() => setRows([]))
  }, [])
  const run = async () => {
    setLoading(true)
    try {
      let workingRows = rows
      if (workingRows.length === 0) {
        try {
          const data = await withTimeout(fetchMarketDashboard(), 5000)
          workingRows = data.indicators
          setRows(data.indicators)
        } catch {
          workingRows = []
        }
      }

      const lower = theme.toLowerCase()
      const sectorBias: Record<string, number> = {
        Banking: lower.includes('rbi') || lower.includes('rate') ? 1 : lower.includes('inflation') ? -1 : 0,
        Energy: lower.includes('crude') || lower.includes('oil') ? 1 : 0,
        IT: lower.includes('us') || lower.includes('dollar') || lower.includes('inr') ? 1 : 0,
        Auto: lower.includes('crude') ? -1 : lower.includes('rate') ? 1 : 0,
        Consumer: lower.includes('inflation') ? -1 : 0,
      }

      const mapped = workingRows.length > 0
        ? workingRows
        .map(row => {
          const bias = sectorBias[row.sector] ?? 0
          const technicalBoost = row.changePct >= 0 ? 0.25 : -0.25
          const score = bias + technicalBoost
          return {
            ticker: row.ticker,
            impact: score > 0.3 ? 'bullish' as const : score < -0.3 ? 'bearish' as const : 'neutral' as const,
            reason: `${row.sector} exposure and current market structure suggest ${row.ticker} is ${score > 0.3 ? 'positively' : score < -0.3 ? 'negatively' : 'moderately'} linked to this event theme.`,
            confidence: Math.min(88, Math.round(48 + Math.abs(score) * 22 + row.conviction * 0.22)),
          }
        })
        .sort((a, b) => b.confidence - a.confidence)
        .slice(0, 6)
        : signals.slice(0, 6).map(signal => ({
            ticker: signal.ticker,
            impact: signal.sentiment,
            reason: `${signal.company} is being approximated from the current radar signal feed because the full market dataset is not loaded yet.`,
            confidence: Math.min(84, signal.strength),
          }))

      setEvents(mapped)
    } finally { setLoading(false) }
  }
  const heatmapCards: Array<{ ticker: string; impact: 'bullish' | 'bearish' | 'neutral'; reason: string; confidence: number } | null> =
    loading ? Array.from({ length: 3 }, () => null) : events
  return <div className="space-y-4"><div className="rounded-2xl border border-surface-500/50 bg-surface-700 p-4"><div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between"><div><p className="text-[11px] uppercase tracking-[0.18em] text-gray-500">Event Heatmap</p><h3 className="mt-1 text-lg font-bold text-white">Who moves if a macro event hits</h3></div><div className="flex gap-2"><input value={theme} onChange={event => setTheme(event.target.value)} onKeyDown={event => event.key === 'Enter' && run()} className="rounded-lg border border-surface-500 bg-surface-800 px-3 py-2 text-xs text-white outline-none focus:border-brand-500/50" /><button onClick={run} className="rounded-lg bg-brand-500 px-3 py-2 text-surface-900 transition hover:bg-brand-400">{loading ? <Loader2 size={12} className="animate-spin" /> : <Search size={12} />}</button></div></div></div>{!loading && heatmapCards.length === 0 ? <div className="rounded-2xl border border-dashed border-surface-500 px-4 py-8 text-sm text-gray-500">No event mapping is available yet. Try refresh on Signals first, then come back here and search again.</div> : <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{heatmapCards.map((item, index) => <div key={item ? item.ticker : `loading-${index}`} className="rounded-2xl border border-surface-500/50 bg-surface-700 p-4">{!item ? <div className="flex min-h-[120px] items-center justify-center text-gray-400"><Loader2 size={18} className="animate-spin" /></div> : <><div className="flex items-center justify-between"><p className="text-lg font-black text-white">{item.ticker}</p><span className={cn('rounded-full border px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.14em]', item.impact === 'bullish' ? 'border-neon-green/20 bg-neon-green/10 text-neon-green' : item.impact === 'bearish' ? 'border-neon-red/20 bg-neon-red/10 text-neon-red' : 'border-surface-500 bg-surface-800 text-gray-300')}>{item.impact}</span></div><p className="mt-3 text-sm leading-6 text-gray-300">{item.reason}</p><div className="mt-4 h-2 overflow-hidden rounded-full bg-surface-800"><div className="h-full rounded-full bg-brand-400" style={{ width: `${item.confidence}%` }} /></div><p className="mt-2 text-[11px] text-gray-500">Confidence {item.confidence}/100</p></>}</div>)}</div>}</div>
}

export function ImpactSimulator() {
  const { portfolio } = useStore()
  const [scenario, setScenario] = useState('RBI rate cut')
  const sectorMap: Record<string, number> = { Banking: scenario.includes('RBI') ? 3.5 : scenario.includes('INR') ? -1.2 : 0.5, Energy: scenario.includes('crude') ? 4.2 : scenario.includes('RBI') ? -0.5 : 1.1, IT: scenario.includes('INR') ? 3.8 : scenario.includes('US') ? 2.5 : 0.9, Auto: scenario.includes('crude') ? -2.8 : scenario.includes('RBI') ? 2.2 : 0.8, Consumer: scenario.includes('inflation') ? -2.4 : 1.1 }
  const projected = portfolio.holdings.map(holding => ({ ...holding, sectorImpact: sectorMap[holding.sector] ?? 0.7, impactValue: holding.currentValue * (sectorMap[holding.sector] ?? 0.7) / 100 }))
  const totalImpact = projected.reduce((sum, item) => sum + item.impactValue, 0)
  return <div className="space-y-4"><div className="rounded-2xl border border-surface-500/50 bg-surface-700 p-4"><div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between"><div><p className="text-[11px] uppercase tracking-[0.18em] text-gray-500">Portfolio Impact Simulator</p><h3 className="mt-1 text-lg font-bold text-white">Scenario impact on your holdings</h3></div><select value={scenario} onChange={event => setScenario(event.target.value)} className="rounded-lg border border-surface-500 bg-surface-800 px-3 py-2 text-xs text-white outline-none focus:border-brand-500/50"><option>RBI rate cut</option><option>crude oil spike</option><option>INR weakness</option><option>US demand rebound</option><option>inflation surprise</option></select></div></div><div className="grid gap-4 xl:grid-cols-[1.1fr_0.9fr]"><div className="space-y-3">{projected.map(item => <div key={item.ticker} className="rounded-2xl border border-surface-500/50 bg-surface-700 p-4"><div className="flex items-center justify-between"><div><p className="text-sm font-bold text-white">{item.ticker}</p><p className="text-[11px] text-gray-500">{item.sector}</p></div><span className={cn('text-sm font-bold', item.sectorImpact >= 0 ? 'text-neon-green' : 'text-neon-red')}>{item.sectorImpact >= 0 ? '+' : ''}{item.sectorImpact.toFixed(1)}%</span></div><p className={cn('mt-3 text-sm font-mono', item.impactValue >= 0 ? 'text-neon-green' : 'text-neon-red')}>{item.impactValue >= 0 ? '+' : ''}Rs {Math.abs(item.impactValue).toFixed(0)} projected</p></div>)}</div><div className="rounded-2xl border border-surface-500/50 bg-surface-700 p-4"><p className="text-[11px] uppercase tracking-[0.18em] text-gray-500">Portfolio Shock Estimate</p><p className={cn('mt-3 font-mono text-3xl font-black', totalImpact >= 0 ? 'text-neon-green' : 'text-neon-red')}>{totalImpact >= 0 ? '+' : '-'}Rs {Math.abs(totalImpact).toFixed(0)}</p><p className="mt-3 text-sm leading-6 text-gray-400">This is a directional impact model based on sector sensitivity and live portfolio weights.</p></div></div></div>
}

export function AlertBuilder() {
  const [ticker, setTicker] = useState('RELIANCE')
  const [rsiThreshold, setRsiThreshold] = useState(35)
  const [volumeSpike, setVolumeSpike] = useState(1.5)
  const [alerts, setAlerts] = useState<Array<{ id: string; ticker: string; rule: string; status: string }>>([])
  const [rows, setRows] = useState<MarketIndicator[]>([])
  useEffect(() => {
    withTimeout(fetchMarketDashboard())
      .then(data => setRows(data.indicators))
      .catch(() => setRows([]))
  }, [])
  const createAlert = () => {
    const row = rows.find(item => item.ticker === ticker)
    const status = row && row.rsi <= rsiThreshold && row.volumeSpike >= volumeSpike ? 'Triggered' : 'Watching'
    setAlerts(prev => [{ id: `alert-${Date.now()}`, ticker, rule: `RSI <= ${rsiThreshold} and volume spike >= ${volumeSpike}x`, status }, ...prev])
  }
  return <div className="space-y-4"><div className="rounded-2xl border border-surface-500/50 bg-surface-700 p-4"><p className="text-[11px] uppercase tracking-[0.18em] text-gray-500">Alert Builder</p><h3 className="mt-1 text-lg font-bold text-white">Build smart market alerts</h3><div className="mt-4 grid gap-3 md:grid-cols-4"><input value={ticker} onChange={event => setTicker(event.target.value.toUpperCase())} className="rounded-lg border border-surface-500 bg-surface-800 px-3 py-2 text-xs text-white outline-none focus:border-brand-500/50" /><input value={rsiThreshold} onChange={event => setRsiThreshold(Number(event.target.value))} type="number" className="rounded-lg border border-surface-500 bg-surface-800 px-3 py-2 text-xs text-white outline-none focus:border-brand-500/50" /><input value={volumeSpike} onChange={event => setVolumeSpike(Number(event.target.value))} step="0.1" type="number" className="rounded-lg border border-surface-500 bg-surface-800 px-3 py-2 text-xs text-white outline-none focus:border-brand-500/50" /><button onClick={createAlert} className="rounded-lg bg-brand-500 px-3 py-2 text-xs font-semibold text-surface-900 transition hover:bg-brand-400">Create alert</button></div></div><div className="space-y-3">{alerts.length > 0 ? alerts.map(alert => <div key={alert.id} className="rounded-2xl border border-surface-500/50 bg-surface-700 p-4"><div className="flex items-center justify-between"><div><p className="text-sm font-bold text-white">{alert.ticker}</p><p className="text-[11px] text-gray-400">{alert.rule}</p></div><span className={cn('rounded-full border px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.14em]', alert.status === 'Triggered' ? 'border-neon-green/20 bg-neon-green/10 text-neon-green' : 'border-surface-500 bg-surface-800 text-gray-300')}>{alert.status}</span></div></div>) : <div className="rounded-2xl border border-dashed border-surface-500 px-4 py-6 text-sm text-gray-500">Create an alert rule to start monitoring indicator conditions.</div>}</div></div>
}

export function StrategyLab() {
  const [rows, setRows] = useState<MarketIndicator[]>([])
  useEffect(() => {
    withTimeout(fetchMarketDashboard())
      .then(data => setRows(data.indicators))
      .catch(() => setRows([]))
  }, [])
  const strategies = [{ name: 'RSI Reversal', matches: rows.filter(row => row.rsi <= 35 && row.momentum5d > 0), note: 'Looks for oversold names starting to rebound.' }, { name: 'Breakout + Volume', matches: rows.filter(row => row.volumeSpike >= 1.5 && row.changePct > 0 && row.conviction >= 65), note: 'Looks for momentum continuation with participation.' }, { name: 'Trend Follow', matches: rows.filter(row => row.price > row.sma20 && row.price > row.sma50 && row.trend === 'bullish'), note: 'Looks for clean moving-average alignment.' }]
  return <div className="grid gap-4 md:grid-cols-3">{strategies.map(strategy => <div key={strategy.name} className="rounded-2xl border border-surface-500/50 bg-surface-700 p-4"><p className="text-lg font-bold text-white">{strategy.name}</p><p className="mt-2 text-sm leading-6 text-gray-400">{strategy.note}</p><div className="mt-4 flex items-center justify-between"><span className="text-[11px] uppercase tracking-[0.16em] text-gray-500">Matches</span><span className="text-sm font-black text-brand-400">{strategy.matches.length}</span></div><div className="mt-3 flex flex-wrap gap-2">{strategy.matches.slice(0, 6).map(item => <span key={`${strategy.name}-${item.ticker}`} className="rounded-full border border-surface-500 bg-surface-800 px-2.5 py-1 text-[10px] text-gray-300">{item.ticker}</span>)}</div></div>)}</div>
}

export function WatchlistBuilder() {
  const [theme, setTheme] = useState('defense and manufacturing')
  const [loading, setLoading] = useState(false)
  const [watchlist, setWatchlist] = useState<Array<{ ticker: string; reason: string; trigger: string }>>([])
  const build = async () => {
    setLoading(true)
    try {
      const data = await withTimeout(fetchMarketDashboard())
      const context = data.indicators.map(row => `${row.ticker}: sector ${row.sector}, setup ${row.setup}, conviction ${row.conviction}, momentum ${row.momentum5d}%`).join('\n')
      const text = await groqChat('You are a thematic watchlist builder for Indian equities. Return only JSON.', `Theme: ${theme}\nLive market context:\n${context}\nReturn only JSON array [{"ticker":"RELIANCE","reason":"why this fits the theme","trigger":"what to watch next"}] and choose 4 to 6 names.`)
      const parsed = parseJsonArray<{ ticker: string; reason: string; trigger: string }>(text)
      setWatchlist(parsed.length > 0 ? parsed : buildLocalWatchlist(theme, data.indicators))
    } catch {
      try {
        const data = await withTimeout(fetchMarketDashboard())
        setWatchlist(buildLocalWatchlist(theme, data.indicators))
      } catch {
        setWatchlist([])
      }
    } finally { setLoading(false) }
  }
  return <div className="space-y-4"><div className="rounded-2xl border border-surface-500/50 bg-surface-700 p-4"><div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between"><div><p className="text-[11px] uppercase tracking-[0.18em] text-gray-500">AI Watchlist Builder</p><h3 className="mt-1 text-lg font-bold text-white">Build a live theme watchlist</h3></div><div className="flex gap-2"><input value={theme} onChange={event => setTheme(event.target.value)} className="rounded-lg border border-surface-500 bg-surface-800 px-3 py-2 text-xs text-white outline-none focus:border-brand-500/50" /><button onClick={build} className="rounded-lg bg-brand-500 px-3 py-2 text-surface-900 transition hover:bg-brand-400">{loading ? <Loader2 size={12} className="animate-spin" /> : <Search size={12} />}</button></div></div></div><div className="grid gap-4 md:grid-cols-2">{watchlist.map(item => <div key={item.ticker} className="rounded-2xl border border-surface-500/50 bg-surface-700 p-4"><p className="text-lg font-black text-white">{item.ticker}</p><p className="mt-3 text-sm leading-6 text-gray-300">{item.reason}</p><div className="mt-4 rounded-xl border border-surface-500/40 bg-surface-800/70 p-3 text-[11px] text-brand-300">Trigger: {item.trigger}</div></div>)}</div></div>
}

export function EarningsRadar() {
  const [loading, setLoading] = useState(false)
  const [items, setItems] = useState<Array<{ ticker: string; note: string; source: string; url: string }>>([])
  const load = async () => {
    setLoading(true)
    try {
      const tickers = ['RELIANCE', 'TCS', 'INFY', 'HDFCBANK', 'TATAMOTORS']
      const newsSets = await Promise.all(tickers.map(async ticker => ({
        ticker,
        news: await fetchTickerNews(ticker),
      })))
      const fastItems = newsSets.map(({ ticker, news }) => {
        const first = news[0]
        if (!first) {
          return FALLBACK_EARNINGS.find(item => item.ticker === ticker) ?? {
            ticker,
            note: `Track the next earnings update and management commentary for ${ticker}.`,
            source: 'ET Alpha',
            url: 'https://www.nseindia.com/',
          }
        }
        return {
          ticker,
          note: first.title,
          source: first.publisher,
          url: first.link,
        }
      })
      setItems(fastItems)
    } catch {
      setItems(FALLBACK_EARNINGS)
    } finally { setLoading(false) }
  }
  useEffect(() => { load() }, [])
  const earningsCards: Array<{ ticker: string; note: string; source: string; url: string } | null> = loading && items.length === 0 ? Array.from({ length: 4 }, () => null) : items
  return <div className="space-y-4"><div className="rounded-2xl border border-surface-500/50 bg-surface-700 p-4"><div className="flex items-center justify-between"><div><p className="text-[11px] uppercase tracking-[0.18em] text-gray-500">Earnings Radar</p><h3 className="mt-1 text-lg font-bold text-white">Current result and earnings watch</h3></div><button onClick={load} className="flex items-center gap-1.5 rounded-lg border border-surface-500 bg-surface-800 px-3 py-2 text-xs text-gray-300 transition hover:text-white"><RefreshCw size={11} className={loading ? 'animate-spin' : ''} />Refresh</button></div></div><div className="grid gap-4 md:grid-cols-2">{earningsCards.map((item, index) => <div key={item ? item.url : `loading-${index}`} className="rounded-2xl border border-surface-500/50 bg-surface-700 p-4">{!item ? <div className="flex min-h-[120px] items-center justify-center text-gray-400"><Loader2 size={18} className="animate-spin" /></div> : <><p className="text-lg font-black text-white">{item.ticker}</p><p className="mt-3 text-sm leading-6 text-gray-300">{item.note}</p><a href={item.url} target="_blank" rel="noreferrer" className="mt-4 inline-flex items-center gap-1.5 text-xs text-brand-300 hover:text-white">{item.source}<ExternalLink size={11} /></a></>}</div>)}</div></div>
}

export function ExplainStock() {
  const [ticker, setTicker] = useState('RELIANCE')
  const [input, setInput] = useState('RELIANCE')
  const [row, setRow] = useState<MarketIndicator | null>(null)
  const [analysis, setAnalysis] = useState('')
  const [loading, setLoading] = useState(true)
  const load = async (symbol: string) => {
    setLoading(true)
    try {
      const data = await withTimeout(fetchMarketDashboard([symbol]))
      const selected = data.indicators[0] ?? null
      setRow(selected)
      if (selected) {
        try {
          const ai = await withTimeout(analyzeTickerWithAI(selected.ticker), 7000)
          setAnalysis(ai.analysis)
        } catch {
          setAnalysis('Live AI analysis is temporarily unavailable. The technical snapshot is still based on fetched market data.')
        }
      } else {
        setAnalysis('')
      }
    } catch {
      setRow(null)
      setAnalysis('')
    } finally { setLoading(false) }
  }
  useEffect(() => { load(ticker) }, [ticker])
  const metrics: Array<{ label: string; value: string; tone: string }> = row ? [
    { label: 'Price', value: `Rs ${row.price.toFixed(2)}`, tone: 'text-white' },
    { label: 'RSI', value: `${row.rsi}`, tone: row.rsi >= 65 ? 'text-neon-green' : row.rsi <= 35 ? 'text-neon-red' : 'text-white' },
    { label: 'Setup', value: row.setup, tone: 'text-brand-300' },
    { label: 'Conviction', value: `${row.conviction}/100`, tone: 'text-blue-300' },
    { label: 'Support', value: `Rs ${row.support.toFixed(2)}`, tone: 'text-blue-300' },
    { label: 'Resistance', value: `Rs ${row.resistance.toFixed(2)}`, tone: 'text-orange-300' },
  ] : []
  return <div className="space-y-4"><div className="rounded-2xl border border-surface-500/50 bg-surface-700 p-4"><div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between"><div><p className="text-[11px] uppercase tracking-[0.18em] text-gray-500">Explain This Stock</p><h3 className="mt-1 text-lg font-bold text-white">Single-stock intelligence summary</h3></div><div className="flex gap-2"><input value={input} onChange={event => setInput(event.target.value.toUpperCase())} onKeyDown={event => event.key === 'Enter' && setTicker(input.trim().toUpperCase() || 'RELIANCE')} className="rounded-lg border border-surface-500 bg-surface-800 px-3 py-2 text-xs text-white outline-none focus:border-brand-500/50" /><button onClick={() => setTicker(input.trim().toUpperCase() || 'RELIANCE')} className="rounded-lg bg-brand-500 px-3 py-2 text-surface-900 transition hover:bg-brand-400"><Search size={12} /></button></div></div></div>{loading ? <div className="flex min-h-[240px] items-center justify-center rounded-2xl border border-surface-500/50 bg-surface-700 text-gray-400"><Loader2 size={18} className="animate-spin" /></div> : row ? <div className="grid gap-4 xl:grid-cols-[1fr_1fr]"><div className="rounded-2xl border border-surface-500/50 bg-surface-700 p-4"><div className="flex items-start justify-between gap-3"><div><p className="text-2xl font-black text-white">{row.ticker}</p><p className="text-sm text-gray-500">{row.company}</p></div><span className={cn('text-lg font-bold', row.changePct >= 0 ? 'text-neon-green' : 'text-neon-red')}>{row.changePct >= 0 ? '+' : ''}{row.changePct}%</span></div><div className="mt-4 grid grid-cols-2 gap-3">{metrics.map(item => <div key={item.label} className="rounded-xl border border-surface-500/40 bg-surface-800/70 p-3"><p className="text-[10px] uppercase tracking-[0.16em] text-gray-500">{item.label}</p><p className={cn('mt-1 text-sm font-bold', item.tone)}>{item.value}</p></div>)}</div></div><div className="rounded-2xl border border-surface-500/50 bg-surface-700 p-4"><p className="text-[11px] uppercase tracking-[0.18em] text-gray-500">AI Summary</p><p className="mt-3 text-sm leading-6 text-gray-300">{analysis || 'No analysis available.'}</p><div className="mt-4 flex flex-wrap gap-2">{(row.riskFlags ?? []).map(flag => <span key={flag} className="rounded-full border border-neon-red/20 bg-neon-red/10 px-2.5 py-1 text-[10px] text-neon-red">{flag}</span>)}</div></div></div> : <div className="rounded-2xl border border-dashed border-surface-500 px-4 py-6 text-sm text-gray-500">No stock found for that symbol.</div>}</div>
}
