import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Newspaper, X, ChevronRight } from 'lucide-react'
import { useStore } from '@/store'

export default function WeeklyDigestToast() {
  const { weeklyDigestReady, setWeeklyDigestReady, setActiveTab } = useStore()
  const [expanded, setExpanded] = useState(false)

  const DIGEST = [
    { label: 'Signals fired this week',   value: '14',        color: 'text-brand-400' },
    { label: 'Portfolio change',          value: '+₹18,240',  color: 'text-neon-green' },
    { label: 'Top mover in your holdings', value: 'TATAMOT +8.1%', color: 'text-neon-green' },
    { label: 'Risk flag',                 value: 'ZOMATO puts spike', color: 'text-orange-400' },
  ]

  return (
    <AnimatePresence>
      {weeklyDigestReady && (
        <motion.div
          initial={{ x: 120, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: 120, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 350, damping: 28 }}
          className="fixed top-24 right-4 z-50 w-72"
          style={{ position: 'fixed' }}
        >
          <div className="bg-surface-700 border border-brand-500/30 rounded-xl shadow-xl overflow-hidden">
            <div className="flex items-center gap-2 p-3 bg-brand-500/5 border-b border-brand-500/20">
              <div className="w-6 h-6 bg-brand-500/15 rounded-md flex items-center justify-center">
                <Newspaper size={12} className="text-brand-400" />
              </div>
              <div className="flex-1">
                <p className="text-xs font-semibold text-white">Weekly Digest Ready</p>
                <p className="text-[10px] text-gray-500">Agent compiled your week</p>
              </div>
              <button
                onClick={() => setWeeklyDigestReady(false)}
                className="p-0.5 text-gray-500 hover:text-white"
              >
                <X size={12} />
              </button>
            </div>

            <AnimatePresence>
              {expanded && (
                <motion.div
                  initial={{ height: 0 }}
                  animate={{ height: 'auto' }}
                  exit={{ height: 0 }}
                  className="overflow-hidden"
                >
                  <div className="p-3 space-y-2">
                    {DIGEST.map((d, i) => (
                      <div key={i} className="flex items-center justify-between">
                        <span className="text-[11px] text-gray-400">{d.label}</span>
                        <span className={`text-[11px] font-mono font-semibold ${d.color}`}>{d.value}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="flex items-center gap-2 p-3 pt-2">
              <button
                onClick={() => setExpanded(e => !e)}
                className="flex-1 text-[11px] text-brand-400 hover:text-brand-300 font-medium flex items-center gap-1"
              >
                {expanded ? 'Hide' : 'Show digest'}
                <ChevronRight size={11} className={expanded ? 'rotate-90' : ''} />
              </button>
              <button
                onClick={() => { setActiveTab('radar'); setWeeklyDigestReady(false) }}
                className="text-[11px] bg-brand-500/10 border border-brand-500/20 text-brand-400 px-2 py-1 rounded-md hover:bg-brand-500/20 transition-colors"
              >
                Open Radar
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
