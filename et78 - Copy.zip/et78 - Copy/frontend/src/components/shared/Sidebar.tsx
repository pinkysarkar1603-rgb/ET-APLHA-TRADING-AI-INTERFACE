import { motion } from 'framer-motion'
import { Radar, Layers, Target, GraduationCap, Globe, Video, TrendingUp, BarChart2, Wrench, Bot, ChevronLeft, Settings, Shield, AudioLines, Database } from 'lucide-react'
import { useStore } from '@/store'
import { cn } from '@/lib/api'

const NAV = [
  { id:'agent',    label:'Agentic Trade Mode', icon:Bot,    badge:'HOT' },
  { id:'guardian', label:'AUERON Guardian',    icon:Shield, badge:'NEW' },
  { id:'radar',    label:'Opportunity Radar', icon:Radar,          badge:'signals' },
  { id:'markets',  label:'Markets',           icon:BarChart2,      badge:null      },
  { id:'bharat',   label:'Bharat Intelligence', icon:AudioLines,   badge:'NEW'     },
  { id:'xray',     label:'Portfolio X-Ray',   icon:Layers,         badge:null      },
  { id:'planner',  label:'FIRE Planner',      icon:Target,         badge:null      },
  { id:'mentor',   label:'Money Mentor',      icon:GraduationCap,  badge:null      },
  { id:'tools',    label:'Financial Tools',   icon:Wrench,         badge:null      },
  { id:'sidekick', label:'Sidekick Mode',     icon:Globe,          badge:'NEW'     },
  { id:'video',    label:'AI Video',          icon:Video,          badge:'NEW'     },
  { id:'impact',   label:'Impact Model',      icon:TrendingUp,     badge:null      },
  { id:'data',     label:'Data Lab',          icon:Database,       badge:'NEW'     },
] as const

export default function Sidebar() {
  const { activeTab, setActiveTab, setSidebarOpen, signals, agents } = useStore()
  const running = Object.values(agents).filter(a => a.status==='running'||a.status==='thinking').length
  return (
    <div className="h-full bg-surface-800 border-r border-surface-500/50 flex flex-col">
      <div className="p-4 border-b border-surface-500/30 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 bg-brand-500 rounded-lg flex items-center justify-center"><TrendingUp size={14} className="text-surface-900" /></div>
          <div><p className="font-bold text-white text-sm">ET Alpha</p><p className="text-[10px] text-gray-500">AI Market Co-Pilot</p></div>
        </div>
        <button onClick={() => setSidebarOpen(false)} className="p-1 text-gray-500 hover:text-white"><ChevronLeft size={14} /></button>
      </div>
      <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
        {NAV.map(item => {
          const Icon = item.icon; const isActive = activeTab === item.id
          const sigBadge = item.id === 'radar' ? signals.filter(s => s.actionable).length : 0
          return (
            <motion.button key={item.id} whileHover={{x:2}} whileTap={{scale:0.98}}
              onClick={() => setActiveTab(item.id as any)}
              className={cn('w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-all text-xs',
                isActive ? 'bg-brand-500/10 text-brand-400 border border-brand-500/20' : 'text-gray-400 hover:text-white hover:bg-surface-600/50')}>
              <Icon size={14} className={isActive ? 'text-brand-400' : ''} />
              <span className="flex-1 font-medium">{item.label}</span>
              {sigBadge > 0 && <span className="bg-brand-500 text-surface-900 text-[9px] font-bold px-1.5 py-0.5 rounded-full">{sigBadge}</span>}
              {item.badge==='NEW' && sigBadge===0 && <span className="bg-neon-green/10 text-neon-green text-[9px] font-bold px-1.5 py-0.5 rounded-full">NEW</span>}
              {item.badge==='HOT' && sigBadge===0 && <span className="bg-neon-red/10 text-neon-red text-[9px] font-bold px-1.5 py-0.5 rounded-full animate-pulse">HOT</span>}
            </motion.button>
          )
        })}
      </nav>
      <div className="p-3 border-t border-surface-500/30">
        <div className="bg-surface-700 rounded-lg p-2.5">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] text-gray-500 font-medium uppercase tracking-wider">Agents</span>
            <div className={cn('flex items-center gap-1 text-[10px]', running > 0 ? 'text-neon-green' : 'text-gray-500')}>
              <div className={cn('w-1.5 h-1.5 rounded-full', running > 0 ? 'bg-neon-green animate-pulse' : 'bg-gray-600')} />
              {running > 0 ? `${running} running` : 'idle'}
            </div>
          </div>
          {Object.entries(useStore.getState().agents).map(([k,a]) => (
            <div key={k} className="flex items-center gap-2 py-0.5">
              <div className={cn('w-1 h-1 rounded-full', a.status==='running'||a.status==='thinking'?'bg-neon-green animate-pulse':a.status==='done'?'bg-brand-400':a.status==='error'?'bg-neon-red':'bg-surface-400')} />
              <span className="text-[9px] text-gray-500 truncate">{a.name}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="p-3">
        <button className="w-full flex items-center gap-2 px-3 py-2 text-gray-500 hover:text-white rounded-lg hover:bg-surface-600/50 transition-colors text-xs">
          <Settings size={13} />Settings
        </button>
      </div>
    </div>
  )
}
