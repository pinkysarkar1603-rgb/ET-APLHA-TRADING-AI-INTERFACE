import { motion, AnimatePresence } from 'framer-motion'
import { Cpu, Zap, Eye, BrainCircuit, Globe, BarChart3 } from 'lucide-react'
import { useStore } from '@/store'
import { cn } from '@/lib/api'

const AGENT_META: Record<string, { icon: any; color: string }> = {
  radar:     { icon: Zap,          color: 'text-brand-400'  },
  portfolio: { icon: BarChart3,    color: 'text-blue-400'   },
  planner:   { icon: BrainCircuit, color: 'text-purple-400' },
  overlap:   { icon: Eye,          color: 'text-orange-400' },
  browser:   { icon: Globe,        color: 'text-neon-green' },
}

export default function AgentStatusBar() {
  const { agents } = useStore()
  const active = Object.entries(agents).filter(([, a]) => a.status === 'running' || a.status === 'thinking')
  if (active.length === 0) return null

  return (
    <AnimatePresence>
      <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
        className="bg-surface-800/80 border-b border-brand-500/20 overflow-hidden">
        <div className="flex items-center gap-3 px-4 py-1.5 overflow-x-auto">
          <div className="flex items-center gap-1.5 text-[10px] text-brand-400 font-medium flex-shrink-0">
            <Cpu size={11} className="animate-spin-slow" />
            AGENTS RUNNING
          </div>
          {active.map(([key, agent]) => {
            const meta = AGENT_META[key] || { icon: Cpu, color: 'text-gray-400' }
            const Icon = meta.icon
            return (
              <motion.div key={key} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
                className="flex items-center gap-2 bg-surface-700 border border-surface-500/50 rounded-full px-2.5 py-0.5 flex-shrink-0">
                <Icon size={10} className={cn(meta.color, 'animate-pulse')} />
                <span className="text-[10px] text-gray-300 font-medium">{agent.name}</span>
                <span className="text-[10px] text-gray-500 max-w-[160px] truncate">{agent.lastAction}</span>
                <div className="w-12 h-1 bg-surface-600 rounded-full overflow-hidden">
                  <motion.div className={cn('h-full rounded-full', meta.color.replace('text-','bg-').replace('/','[') )}
                    style={{ background: meta.color.includes('brand') ? '#ffc61a' : meta.color.includes('green') ? '#00e676' : meta.color.includes('blue') ? '#4fc3f7' : meta.color.includes('purple') ? '#b388ff' : '#f97316' }}
                    animate={{ x: ['-100%', '200%'] }} transition={{ duration: 1.2, repeat: Infinity, ease: 'easeInOut' }} />
                </div>
              </motion.div>
            )
          })}
        </div>
      </motion.div>
    </AnimatePresence>
  )
}
