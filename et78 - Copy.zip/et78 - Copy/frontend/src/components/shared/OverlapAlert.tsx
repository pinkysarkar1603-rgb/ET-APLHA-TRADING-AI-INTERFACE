import { motion, AnimatePresence } from 'framer-motion'
import { AlertTriangle, X, ArrowRight } from 'lucide-react'
import { useStore } from '@/store'

export default function OverlapAlert() {
  const { portfolio, overlapAlertDismissed, dismissOverlapAlert, setActiveTab } = useStore()

  const highOverlapFunds = portfolio.funds.filter(f => (f.overlapPct ?? 0) > 60)
  const show = portfolio.loaded && highOverlapFunds.length >= 2 && !overlapAlertDismissed

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ type: 'spring', stiffness: 400, damping: 30 }}
          className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 w-full max-w-lg mx-auto px-4"
          style={{ position: 'fixed' }}
        >
          <div className="bg-surface-700 border border-orange-500/40 rounded-xl p-4 shadow-xl flex items-start gap-3">
            <div className="w-8 h-8 bg-orange-500/10 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
              <AlertTriangle size={16} className="text-orange-400" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-white">
                Overlap Alert — Agent detected redundant holdings
              </p>
              <p className="text-xs text-gray-400 mt-1">
                <span className="text-orange-400 font-medium">{highOverlapFunds[0]?.name}</span> and{' '}
                <span className="text-orange-400 font-medium">{highOverlapFunds[1]?.name}</span> share{' '}
                <span className="text-white font-bold">{highOverlapFunds[0]?.overlapPct}%</span> of holdings.
                You may be over-diversifying with zero benefit.
              </p>
              <div className="flex items-center gap-2 mt-2">
                <button
                  onClick={() => { setActiveTab('xray'); dismissOverlapAlert() }}
                  className="flex items-center gap-1 text-xs text-brand-400 hover:text-brand-300 font-medium"
                >
                  View X-Ray <ArrowRight size={11} />
                </button>
              </div>
            </div>
            <button
              onClick={dismissOverlapAlert}
              className="p-1 text-gray-500 hover:text-white transition-colors flex-shrink-0"
            >
              <X size={14} />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
