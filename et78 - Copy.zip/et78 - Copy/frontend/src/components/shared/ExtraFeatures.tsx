import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Bell, Plus, Trash2, TrendingUp, TrendingDown, Languages, Sliders, AlertTriangle, Loader2, CheckCircle2 } from 'lucide-react'
import { useStore } from '@/store'
import { fetchLiveQuote } from '@/lib/marketData'
import { cn, formatINR } from '@/lib/api'

// ─── PRICE ALERTS ─────────────────────────────────────────────────────────────
export function PriceAlertWidget() {
  const { priceAlerts, addPriceAlert, triggerAlert, removePriceAlert, addNotification } = useStore()
  const [ticker, setTicker]     = useState('')
  const [price, setPrice]       = useState('')
  const [dir, setDir]           = useState<'above'|'below'>('above')
  const [adding, setAdding]     = useState(false)
  const [livePrice, setLivePrice] = useState<number|null>(null)
  const [fetchErr, setFetchErr] = useState('')
  const pollRef                 = useRef<ReturnType<typeof setInterval>>()

  // ── Real polling: check every 30s if any alert has triggered ──
  useEffect(() => {
    const checkAlerts = async () => {
      const activeAlerts = useStore.getState().priceAlerts.filter(a => !a.triggered)
      if (!activeAlerts.length) return

      // Batch unique tickers
      const tickers = [...new Set(activeAlerts.map(a => a.ticker))]
      await Promise.all(tickers.map(async (sym) => {
        try {
          const q = await fetchLiveQuote(`${sym}.NS`)
          if (!q) return
          const current = useStore.getState()
          current.priceAlerts
            .filter(a => a.ticker === sym && !a.triggered)
            .forEach(a => {
              const hit = a.direction === 'above' ? q.price >= a.targetPrice : q.price <= a.targetPrice
              if (hit) {
                triggerAlert(a.id)
                addNotification({
                  type: 'price',
                  title: `🔔 ${sym} Alert Triggered!`,
                  body: `${sym} is ${a.direction} ₹${a.targetPrice.toLocaleString('en-IN')} — now at ₹${q.price.toFixed(2)}`,
                })
                if (Notification.permission === 'granted') {
                  new Notification(`ET Alpha: ${sym} Alert!`, {
                    body: `${sym} ${a.direction} ₹${a.targetPrice} — now ₹${q.price.toFixed(2)}`,
                    icon: '/vite.svg',
                  })
                }
              }
            })
        } catch {}
      }))
    }

    checkAlerts() // immediate check on mount / when alerts change
    pollRef.current = setInterval(checkAlerts, 30_000)
    return () => clearInterval(pollRef.current)
  }, [priceAlerts.length]) // re-register when alert count changes

  // ── Live price preview while typing ticker ──
  useEffect(() => {
    if (!ticker || ticker.length < 2) { setLivePrice(null); setFetchErr(''); return }
    const t = setTimeout(async () => {
      try {
        const q = await fetchLiveQuote(`${ticker}.NS`)
        if (q) { setLivePrice(q.price); setFetchErr('') }
        else setFetchErr('Not found')
      } catch { setFetchErr('Fetch error') }
    }, 600)
    return () => clearTimeout(t)
  }, [ticker])

  const addAlert = async () => {
    if (!ticker.trim() || !price || adding) return
    const sym = ticker.toUpperCase()
    const target = parseFloat(price)
    if (isNaN(target) || target <= 0) { setFetchErr('Enter a valid price'); return }

    // Add immediately — never block the user
    addPriceAlert({ ticker: sym, targetPrice: target, direction: dir })
    setTicker(''); setPrice(''); setLivePrice(null); setFetchErr('')

    if (Notification.permission !== 'granted') Notification.requestPermission()

    // Validate + check trigger in background (non-blocking)
    setAdding(true)
    try {
      const q = await fetchLiveQuote(`${sym}.NS`)
      if (q) {
        const hit = dir === 'above' ? q.price >= target : q.price <= target
        if (hit) {
          addNotification({
            type: 'price',
            title: `🔔 ${sym} already ${dir} ₹${target.toLocaleString('en-IN')}!`,
            body: `Current price ₹${q.price.toFixed(2)} — alert triggered immediately`,
          })
          if (Notification.permission === 'granted') {
            new Notification(`ET Alpha: ${sym} Alert!`, {
              body: `${sym} is already ${dir} ₹${target} — now at ₹${q.price.toFixed(2)}`,
              icon: '/vite.svg',
            })
          }
        }
      }
    } catch {}
    setAdding(false)
  }

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') addAlert()
  }

  return (
    <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-4 space-y-3">
      <div className="flex items-center gap-2">
        <Bell size={14} className="text-brand-400" />
        <p className="text-xs font-semibold text-gray-300">Price Alerts</p>
        <span className="text-[10px] text-gray-500 bg-surface-600 px-1.5 py-0.5 rounded">
          Live · polls every 30s
        </span>
        <button
          onClick={() => Notification.requestPermission()}
          className="ml-auto text-[10px] text-gray-500 hover:text-white bg-surface-600 px-2 py-0.5 rounded"
        >
          Enable notifications
        </button>
      </div>

      {/* Add alert row */}
      <div className="flex gap-2 items-center w-full">
        <div className="relative">
          <input
            value={ticker}
            onChange={e => { setTicker(e.target.value.toUpperCase()); setFetchErr('') }}
            onKeyDown={handleKey}
            placeholder="RELIANCE"
            className="w-24 bg-surface-600 border border-surface-500 text-xs text-white px-2 py-1.5 rounded-lg outline-none focus:border-brand-500/50"
          />
          {livePrice && (
            <span className="absolute -bottom-4 left-0 text-[9px] text-neon-green font-mono">₹{livePrice.toFixed(0)}</span>
          )}
          {fetchErr && (
            <span className="absolute -bottom-4 left-0 text-[9px] text-neon-red">{fetchErr}</span>
          )}
        </div>
        <select
          value={dir}
          onChange={e => setDir(e.target.value as 'above'|'below')}
          className="bg-surface-600 border border-surface-500 text-xs text-gray-300 px-2 py-1.5 rounded-lg outline-none"
        >
          <option value="above">above</option>
          <option value="below">below</option>
        </select>
        <input
          value={price}
          onChange={e => setPrice(e.target.value)}
          onKeyDown={handleKey}
          placeholder="2500"
          type="number"
          className="flex-1 bg-surface-600 border border-surface-500 text-xs text-white px-2 py-1.5 rounded-lg outline-none focus:border-brand-500/50"
        />
      </div>

      {/* Add button — full width, no icon clipping issues */}
      <button
        onClick={addAlert}
        disabled={!ticker.trim() || !price || adding}
        className="w-full flex items-center justify-center gap-2 py-2 bg-brand-500/10 border border-brand-500/20 text-brand-400 text-xs font-semibold rounded-lg hover:bg-brand-500/20 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
      >
        {adding ? <Loader2 size={13} className="animate-spin" /> : <Plus size={13} />}
        {adding ? 'Adding...' : 'Add Alert'}
      </button>

      {/* Alert list */}
      <div className="space-y-1.5 max-h-48 overflow-y-auto mt-2">
        {priceAlerts.length === 0 ? (
          <p className="text-[10px] text-gray-600 text-center py-3">No alerts set — type a ticker and target price above</p>
        ) : priceAlerts.map(a => (
          <motion.div
            key={a.id}
            initial={{ opacity: 0, x: -6 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 6 }}
            className={cn(
              'flex items-center gap-2 px-2.5 py-2 rounded-lg border text-[11px]',
              a.triggered
                ? 'bg-neon-green/5 border-neon-green/20'
                : 'bg-surface-600/50 border-surface-500/30'
            )}
          >
            {a.triggered
              ? <Bell size={10} className="text-neon-green animate-bounce flex-shrink-0" />
              : <Bell size={10} className="text-gray-500 flex-shrink-0" />
            }
            <span className="font-bold text-white">{a.ticker}</span>
            <span className="text-gray-500">{a.direction}</span>
            <span className="font-mono text-gray-300">₹{a.targetPrice.toLocaleString('en-IN')}</span>
            {a.triggered && (
              <span className="ml-auto text-[9px] bg-neon-green/10 text-neon-green px-1.5 py-0.5 rounded font-bold flex items-center gap-1">
                <CheckCircle2 size={8} /> TRIGGERED
              </span>
            )}
            <button
              onClick={() => removePriceAlert(a.id)}
              className={cn('text-gray-600 hover:text-neon-red transition-colors', !a.triggered && 'ml-auto')}
              title="Remove alert"
            >
              <Trash2 size={10} />
            </button>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

// ─── LANGUAGE TOGGLE ─────────────────────────────────────────────────────────
export function LanguageToggle() {
  const { language, setLanguage } = useStore()
  const LANGS = [
    { code: 'en', label: 'English',  flag: '🇬🇧' },
    { code: 'hi', label: 'हिंदी',    flag: '🇮🇳' },
    { code: 'mr', label: 'मराठी',    flag: '🇮🇳' },
  ] as const

  return (
    <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-3">
      <div className="flex items-center gap-2 mb-2">
        <Languages size={13} className="text-blue-400" />
        <p className="text-xs font-semibold text-gray-300">Co-pilot language</p>
      </div>
      <div className="flex gap-2">
        {LANGS.map(l => (
          <button key={l.code} onClick={() => setLanguage(l.code)}
            className={cn(
              'flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-medium border transition-all',
              language === l.code
                ? 'bg-brand-500/10 border-brand-500/30 text-brand-400'
                : 'bg-surface-600 border-surface-500 text-gray-400 hover:text-white'
            )}>
            <span style={{ fontSize: '14px' }}>{l.flag}</span>
            {l.label}
          </button>
        ))}
      </div>
      {language !== 'en' && (
        <p className="text-[10px] text-brand-400 mt-2 text-center">
          Co-pilot will now respond in {language === 'hi' ? 'Hindi' : 'Marathi'} — powered by Groq
        </p>
      )}
    </div>
  )
}

// ─── WHAT-IF SIMULATOR ────────────────────────────────────────────────────────
export function WhatIfSimulator() {
  const { portfolio } = useStore()
  const [extraSip, setExtraSip]   = useState(0)
  const [returnAdj, setReturnAdj] = useState(0)
  const [years, setYears]         = useState(10)

  const base = portfolio.totalValue || 1200000
  const baseSip = 50000
  const baseReturn = 12

  const calc = (extraS: number, retAdj: number, yrs: number) => {
    const r = (baseReturn + retAdj) / 100 / 12
    const n = yrs * 12
    const monthly = baseSip + extraS
    return base * Math.pow(1 + r, n) + monthly * (Math.pow(1 + r, n) - 1) / r
  }

  const baseCorpus  = calc(0, 0, years)
  const newCorpus   = calc(extraSip, returnAdj, years)
  const difference  = newCorpus - baseCorpus
  const pctImprove  = ((difference / baseCorpus) * 100).toFixed(1)

  return (
    <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-4 space-y-3">
      <div className="flex items-center gap-2">
        <Sliders size={13} className="text-purple-400" />
        <p className="text-xs font-semibold text-gray-300">What-if simulator</p>
      </div>

      {[
        { label: `Extra monthly SIP: ₹${extraSip.toLocaleString('en-IN')}`, val: extraSip, set: setExtraSip, min: 0, max: 50000, step: 1000 },
        { label: `Return adjustment: ${returnAdj >= 0 ? '+' : ''}${returnAdj}%`, val: returnAdj, set: setReturnAdj, min: -5, max: 8, step: 0.5 },
        { label: `Years: ${years}`, val: years, set: setYears, min: 1, max: 30, step: 1 },
      ].map(s => (
        <div key={s.label}>
          <div className="flex justify-between mb-1">
            <span className="text-[10px] text-gray-400">{s.label}</span>
          </div>
          <input type="range" min={s.min} max={s.max} step={s.step} value={s.val}
            onChange={e => s.set(Number(e.target.value))}
            className="w-full accent-brand-500 h-1.5" />
        </div>
      ))}

      <div className="grid grid-cols-2 gap-2 pt-1">
        <div className="bg-surface-600/50 rounded-lg p-2.5 text-center">
          <p className="text-[9px] text-gray-500 mb-0.5">Current path</p>
          <p className="text-sm font-black font-mono text-gray-300">{formatINR(baseCorpus, true)}</p>
        </div>
        <div className={cn('rounded-lg p-2.5 text-center', difference >= 0 ? 'bg-neon-green/5 border border-neon-green/20' : 'bg-neon-red/5 border border-neon-red/20')}>
          <p className="text-[9px] text-gray-500 mb-0.5">With changes</p>
          <p className={cn('text-sm font-black font-mono', difference >= 0 ? 'text-neon-green' : 'text-neon-red')}>
            {formatINR(newCorpus, true)}
          </p>
        </div>
      </div>

      <div className={cn('text-center text-[11px] font-bold', difference >= 0 ? 'text-neon-green' : 'text-neon-red')}>
        {difference >= 0 ? '+' : ''}{formatINR(Math.abs(difference), true)} ({difference >= 0 ? '+' : ''}{pctImprove}% more) over {years} years
      </div>
    </div>
  )
}
