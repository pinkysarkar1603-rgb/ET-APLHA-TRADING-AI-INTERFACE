import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Mic, MicOff, TrendingUp, TrendingDown, FileText, Download,
  Users, Calculator, Newspaper, AlertTriangle, CheckCircle2,
  Loader2, Sparkles, Calendar, Star
} from 'lucide-react'
import { useStore } from '@/store'
import { groqChat, streamGroqResponse, formatINR, cn } from '@/lib/api'

// ─── 1. VOICE INPUT ──────────────────────────────────────────────────────────
export function VoiceInput({ onTranscript }: { onTranscript: (text: string) => void }) {
  const [listening, setListening] = useState(false)
  const [supported] = useState(() => 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window)
  const recRef = useRef<any>(null)

  const toggle = () => {
    if (!supported) return
    if (listening) {
      recRef.current?.stop()
      setListening(false)
      return
    }
    const SR = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition
    const rec = new SR()
    rec.continuous    = false
    rec.interimResults = false
    rec.lang          = 'en-IN'
    rec.onresult = (e: any) => {
      const text = e.results[0][0].transcript
      onTranscript(text)
      setListening(false)
    }
    rec.onerror = () => setListening(false)
    rec.onend   = () => setListening(false)
    rec.start()
    recRef.current = rec
    setListening(true)
  }

  if (!supported) return null

  return (
    <button onClick={toggle}
      className={cn('p-2 rounded-lg border transition-all flex-shrink-0',
        listening
          ? 'bg-neon-red/10 border-neon-red/30 text-neon-red animate-pulse'
          : 'bg-surface-600 border-surface-500 text-gray-400 hover:text-white hover:border-brand-500/30'
      )}
      title={listening ? 'Stop recording' : 'Speak to co-pilot (Hindi supported)'}>
      {listening ? <MicOff size={14} /> : <Mic size={14} />}
    </button>
  )
}

// ─── 2. IPO TRACKER ──────────────────────────────────────────────────────────
const IPOS = [
  { company: 'Ather Energy',       opens: 'Apr 28',  closes: 'Apr 30', price: '304-321', gmp: '+₹42',  gmpPct: '+13.1%', sub: '2.3x',  status: 'upcoming', category: 'EV'        },
  { company: 'Hyundai Motor India', opens: 'Open',   closes: 'Apr 22', price: '1865-1960',gmp:'+₹110', gmpPct: '+5.6%',  sub: '4.1x',  status: 'open',     category: 'Auto'      },
  { company: 'Bajaj Housing Fin',  opens: 'Listed',  closes: 'Listed', price: '70',       gmp: '+₹42',  gmpPct: '+60%',   sub: '67x',   status: 'listed',   category: 'NBFC'      },
  { company: 'Premier Energies',   opens: 'Listed',  closes: 'Listed', price: '427-450',  gmp: '+₹278', gmpPct: '+61.7%', sub: '74x',   status: 'listed',   category: 'Solar'     },
  { company: 'Garuda Construction', opens:'May 5',   closes: 'May 7',  price: '95-95',    gmp: '+₹8',   gmpPct: '+8.4%',  sub: '—',     status: 'upcoming', category: 'Infra'     },
]

export function IPOTracker() {
  const [selected, setSelected]   = useState<string | null>(null)
  const [analysis, setAnalysis]   = useState<Record<string, string>>({})
  const [loading, setLoading]     = useState<string | null>(null)

  const analyse = async (ipo: typeof IPOS[0]) => {
    if (analysis[ipo.company]) { setSelected(ipo.company); return }
    setLoading(ipo.company)
    const text = await groqChat(
      'You are an IPO analyst. Give specific, actionable advice. Under 80 words.',
      `IPO: ${ipo.company} (${ipo.category}), Price ₹${ipo.price}, GMP ${ipo.gmp} (${ipo.gmpPct}), Subscription ${ipo.sub}. Should retail investors apply? Give: 1) Subscribe/Avoid verdict 2) One key risk 3) GMP interpretation. Bold your verdict.`
    )
    setAnalysis(prev => ({ ...prev, [ipo.company]: text }))
    setSelected(ipo.company); setLoading(null)
  }

  const statusColor = (s: string) => s === 'open' ? 'text-neon-green bg-neon-green/10 border-neon-green/20' : s === 'upcoming' ? 'text-brand-400 bg-brand-500/10 border-brand-500/20' : 'text-gray-400 bg-surface-600 border-surface-500'

  return (
    <div className="bg-surface-700 border border-surface-500/50 rounded-xl overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-3 border-b border-surface-500/40">
        <Calendar size={14} className="text-brand-400" />
        <p className="text-xs font-semibold text-gray-300">IPO Tracker</p>
        <span className="ml-auto text-[10px] bg-neon-green/10 text-neon-green border border-neon-green/20 px-2 py-0.5 rounded-full font-medium">
          {IPOS.filter(i => i.status === 'open').length} open now
        </span>
      </div>
      <div className="p-3 space-y-2">
        {IPOS.map(ipo => (
          <div key={ipo.company} className="bg-surface-600/50 border border-surface-500/30 rounded-xl overflow-hidden">
            <div className="flex items-center gap-3 p-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <p className="text-[11px] font-semibold text-white">{ipo.company}</p>
                  <span className={cn('text-[9px] font-bold px-1.5 py-0.5 rounded-full border', statusColor(ipo.status))}>
                    {ipo.status.toUpperCase()}
                  </span>
                  <span className="text-[9px] text-gray-600">{ipo.category}</span>
                </div>
                <p className="text-[10px] text-gray-500">{ipo.opens} → {ipo.closes} · ₹{ipo.price}</p>
              </div>
              <div className="text-right flex-shrink-0">
                <p className="text-[11px] font-bold text-neon-green">{ipo.gmp} GMP</p>
                <p className="text-[10px] text-gray-400">Sub: {ipo.sub}</p>
              </div>
              <button onClick={() => analyse(ipo)} disabled={loading === ipo.company}
                className="flex items-center gap-1 text-[10px] bg-brand-500/10 border border-brand-500/20 text-brand-400 px-2.5 py-1.5 rounded-lg hover:bg-brand-500/20 transition-colors disabled:opacity-40 flex-shrink-0">
                {loading === ipo.company ? <Loader2 size={9} className="animate-spin" /> : <Sparkles size={9} />}
                AI
              </button>
            </div>
            <AnimatePresence>
              {selected === ipo.company && analysis[ipo.company] && (
                <motion.div initial={{ height:0,opacity:0 }} animate={{ height:'auto',opacity:1 }} exit={{ height:0,opacity:0 }}
                  className="border-t border-surface-500/30 bg-brand-500/3 px-3 py-2 overflow-hidden">
                  <p className="text-[10px] text-gray-300 leading-relaxed"
                    dangerouslySetInnerHTML={{ __html: analysis[ipo.company].replace(/\*\*(.*?)\*\*/g,'<strong class="text-white">$1</strong>').replace(/\n/g,'<br/>') }} />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </div>
  )
}

// ─── 3. SENTIMENT SCANNER ────────────────────────────────────────────────────
const HEADLINES = [
  'Reliance Industries posts record Q3 profit, JIO subscriber growth beats estimates',
  'HDFC Bank NIM compression concerns weigh on Q4 outlook, analysts cautious',
  'Tata Motors EV sales hit 50,000 milestone; Jaguar Land Rover orders at record high',
  'Infosys cuts revenue guidance for FY25 amid slowdown in BFSI vertical',
  'Zomato Blinkit turns EBITDA positive; quick commerce market share hits 46%',
  'RBI holds rates; governor signals no cut before August amid food inflation',
]

export function SentimentScanner() {
  const [scores, setScores]   = useState<{ headline: string; ticker: string; score: number; reason: string }[]>([])
  const [loading, setLoading] = useState(false)

  const scan = async () => {
    setLoading(true)
    const text = await groqChat(
      'You are a financial sentiment analyst. Return ONLY valid JSON, no markdown.',
      `Analyse these ET Markets headlines and score each stock's sentiment:
${HEADLINES.map((h,i) => `${i+1}. ${h}`).join('\n')}

Return ONLY this JSON array:
[{"headline":"first 50 chars","ticker":"NSE_SYMBOL","score":-100 to 100,"reason":"one sentence"}]`
    )
    try {
      const match = text.match(/\[[\s\S]*?\]/)
      if (match) setScores(JSON.parse(match[0]))
    } catch {}
    setLoading(false)
  }

  return (
    <div className="bg-surface-700 border border-surface-500/50 rounded-xl overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-3 border-b border-surface-500/40">
        <Newspaper size={14} className="text-teal-400" />
        <p className="text-xs font-semibold text-gray-300">Sentiment Scanner</p>
        <button onClick={scan} disabled={loading}
          className="ml-auto flex items-center gap-1.5 text-[10px] bg-teal-500/10 border border-teal-500/20 text-teal-400 px-2.5 py-1.5 rounded-lg hover:bg-teal-500/20 transition-colors disabled:opacity-40">
          {loading ? <Loader2 size={9} className="animate-spin" /> : <Newspaper size={9} />}
          {loading ? 'Groq scanning...' : 'Scan Headlines'}
        </button>
      </div>
      <div className="p-3 space-y-2">
        {scores.length === 0 ? (
          <div className="space-y-2">
            {HEADLINES.map((h, i) => (
              <p key={i} className="text-[10px] text-gray-500 bg-surface-600/30 rounded-lg px-3 py-2 leading-snug">{h}</p>
            ))}
            <p className="text-[10px] text-gray-600 text-center py-1">Click "Scan Headlines" to score each stock's sentiment with Groq</p>
          </div>
        ) : scores.map((s, i) => (
          <motion.div key={i} initial={{ opacity:0, x:-6 }} animate={{ opacity:1, x:0 }} transition={{ delay:i*0.06 }}
            className="flex items-center gap-3 bg-surface-600/40 rounded-lg px-3 py-2.5">
            <div className={cn('w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 text-[10px] font-black',
              s.score > 30 ? 'bg-neon-green/10 text-neon-green' : s.score < -30 ? 'bg-neon-red/10 text-neon-red' : 'bg-brand-500/10 text-brand-400')}>
              {s.score > 0 ? '+' : ''}{s.score}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold text-white">{s.ticker}</span>
                {s.score > 30 ? <TrendingUp size={10} className="text-neon-green" /> : s.score < -30 ? <TrendingDown size={10} className="text-neon-red" /> : null}
              </div>
              <p className="text-[10px] text-gray-500 truncate">{s.headline}</p>
              <p className="text-[10px] text-gray-400 mt-0.5">{s.reason}</p>
            </div>
            {/* Score bar */}
            <div className="w-16 h-1.5 bg-surface-600 rounded-full overflow-hidden flex-shrink-0">
              <div className="h-full rounded-full" style={{
                width: `${Math.abs(s.score)}%`,
                background: s.score > 0 ? '#00e676' : '#ff3d57',
                marginLeft: s.score < 0 ? `${100 - Math.abs(s.score)}%` : 0,
              }} />
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

// ─── 4. TAX LOSS HARVESTING ──────────────────────────────────────────────────
export function TaxLossHarvesting() {
  const { portfolio } = useStore()
  const [advice, setAdvice]   = useState('')
  const [loading, setLoading] = useState(false)

  const losers = portfolio.holdings.filter(h => h.pnl < 0)
  const totalLoss = losers.reduce((s, h) => s + Math.abs(h.pnl), 0)
  const taxSaving = totalLoss * 0.125 // 12.5% LTCG

  const getAdvice = async () => {
    setLoading(true)
    const loserList = losers.map(h => `${h.ticker}: bought ₹${h.avgCost}, now ₹${h.ltp}, loss ₹${Math.abs(h.pnl).toLocaleString('en-IN')}`).join('; ')
    const text = await groqChat(
      'You are a SEBI-registered tax advisor for Indian investors. Be specific about Section 112A.',
      `My holdings with unrealised losses: ${loserList || 'None currently'}. Total unrealised loss: ₹${totalLoss.toLocaleString('en-IN')}. Explain: 1) Which to sell before Mar 31 2) Wash sale rule (30 days) 3) Exact tax saving at 12.5% LTCG. Under 100 words.`
    )
    setAdvice(text); setLoading(false)
  }

  return (
    <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-4 space-y-3">
      <div className="flex items-center gap-2">
        <AlertTriangle size={14} className="text-orange-400" />
        <p className="text-xs font-semibold text-gray-300">Tax Loss Harvesting</p>
        <span className="ml-auto text-[10px] text-neon-green font-mono font-bold">
          Save ~{formatINR(taxSaving, true)} tax
        </span>
      </div>

      {losers.length === 0 ? (
        <p className="text-[11px] text-gray-500 text-center py-2">No unrealised losses in your portfolio currently</p>
      ) : (
        <div className="space-y-2">
          {losers.map(h => (
            <div key={h.ticker} className="flex items-center gap-3 bg-neon-red/5 border border-neon-red/10 rounded-lg px-3 py-2">
              <span className="text-xs font-bold text-white">{h.ticker}</span>
              <span className="text-[10px] text-neon-red font-mono">{formatINR(h.pnl, true)}</span>
              <span className="text-[10px] text-gray-500 ml-auto">Sell → rebuy after 30 days</span>
            </div>
          ))}
          <div className="flex items-center justify-between bg-surface-600/50 rounded-lg px-3 py-2">
            <span className="text-[11px] text-gray-400">Total loss to harvest</span>
            <span className="text-[11px] font-mono font-bold text-neon-red">{formatINR(totalLoss, true)}</span>
          </div>
          <div className="flex items-center justify-between bg-neon-green/5 border border-neon-green/20 rounded-lg px-3 py-2">
            <span className="text-[11px] text-gray-300">Estimated LTCG tax saved</span>
            <span className="text-[11px] font-mono font-bold text-neon-green">{formatINR(taxSaving, true)}</span>
          </div>
        </div>
      )}

      <button onClick={getAdvice} disabled={loading}
        className="w-full flex items-center justify-center gap-2 text-xs bg-orange-500/10 border border-orange-500/20 text-orange-400 py-2 rounded-lg hover:bg-orange-500/20 transition-colors disabled:opacity-40">
        {loading ? <Loader2 size={11} className="animate-spin" /> : <Sparkles size={11} />}
        {loading ? 'Groq analysing...' : 'Get Tax Harvesting Plan'}
      </button>

      {advice && (
        <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }}
          className="bg-orange-500/5 border border-orange-500/20 rounded-xl p-3">
          <p className="text-[11px] text-gray-300 leading-relaxed"
            dangerouslySetInnerHTML={{ __html: advice.replace(/\*\*(.*?)\*\*/g,'<strong class="text-white">$1</strong>').replace(/\n/g,'<br/>') }} />
        </motion.div>
      )}
    </div>
  )
}

// ─── 5. COUPLE MONEY PLANNER ─────────────────────────────────────────────────
export function CouplePlanner() {
  const [p1, setP1] = useState({ name:'Partner 1', income:1200000, hra:15000, nps:0, sip:10000 })
  const [p2, setP2] = useState({ name:'Partner 2', income:800000,  hra:12000, nps:0, sip:8000  })
  const [plan, setPlan]   = useState('')
  const [loading, setLoading] = useState(false)

  const totalIncome = p1.income + p2.income
  const totalSip    = p1.sip + p2.sip
  const totalNPS    = p1.nps + p2.nps

  const generate = async () => {
    setLoading(true)
    const text = await groqChat(
      'You are a financial advisor for Indian couples. Give specific optimisation advice. Under 120 words.',
      `Couple's finances: ${p1.name} earns ₹${(p1.income/1000).toFixed(0)}K/yr, HRA ₹${p1.hra}/mo, NPS ₹${p1.nps}/mo, SIP ₹${p1.sip}/mo. ${p2.name} earns ₹${(p2.income/1000).toFixed(0)}K/yr, HRA ₹${p2.hra}/mo, NPS ₹${p2.nps}/mo, SIP ₹${p2.sip}/mo. Optimise: 1) Who should claim higher HRA (provide numbers) 2) NPS split for max 80CCD deduction 3) SIP allocation by tax bracket 4) Joint net worth growth rate.`
    )
    setPlan(text); setLoading(false)
  }

  return (
    <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-4 space-y-4">
      <div className="flex items-center gap-2">
        <Users size={14} className="text-pink-400" />
        <p className="text-xs font-semibold text-gray-300">Couple Money Planner</p>
        <span className="ml-auto text-[10px] text-pink-400 bg-pink-500/10 border border-pink-500/20 px-2 py-0.5 rounded-full">India First</span>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {[
          { data: p1, set: setP1, label: 'Partner 1' },
          { data: p2, set: setP2, label: 'Partner 2' },
        ].map(({ data, set, label }) => (
          <div key={label} className="space-y-2">
            <p className="text-[10px] text-gray-400 font-semibold">{label}</p>
            {[
              { key:'income', label:'Annual income', prefix:'₹', mult:1 },
              { key:'hra',    label:'HRA/month',     prefix:'₹', mult:1 },
              { key:'nps',    label:'NPS/month',     prefix:'₹', mult:1 },
              { key:'sip',    label:'SIP/month',     prefix:'₹', mult:1 },
            ].map(f => (
              <div key={f.key}>
                <div className="flex justify-between mb-0.5">
                  <span className="text-[9px] text-gray-500">{f.label}</span>
                  <span className="text-[9px] font-mono text-gray-300">₹{(data[f.key as keyof typeof data] as number).toLocaleString('en-IN')}</span>
                </div>
                <input type="range"
                  min={f.key === 'income' ? 300000 : 0}
                  max={f.key === 'income' ? 3000000 : f.key === 'sip' ? 50000 : 30000}
                  step={f.key === 'income' ? 50000 : 500}
                  value={data[f.key as keyof typeof data] as number}
                  onChange={e => set(prev => ({ ...prev, [f.key]: Number(e.target.value) }))}
                  className="w-full accent-pink-400 h-1" />
              </div>
            ))}
          </div>
        ))}
      </div>

      {/* Combined stats */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { l:'Combined income', v:`₹${(totalIncome/1e5).toFixed(1)}L/yr` },
          { l:'Total SIP',       v:`₹${totalSip.toLocaleString('en-IN')}/mo` },
          { l:'10Y corpus est.', v:`₹${((totalSip*12*Math.pow(1.12,10)/0.12*(1.12-1))/1e7).toFixed(1)}Cr` },
        ].map(s => (
          <div key={s.l} className="bg-surface-600/50 rounded-lg p-2 text-center">
            <p className="text-[9px] text-gray-500">{s.l}</p>
            <p className="text-[11px] font-mono font-bold text-pink-400">{s.v}</p>
          </div>
        ))}
      </div>

      <button onClick={generate} disabled={loading}
        className="w-full flex items-center justify-center gap-2 text-xs bg-pink-500/10 border border-pink-500/20 text-pink-400 py-2.5 rounded-lg hover:bg-pink-500/20 transition-colors disabled:opacity-40">
        {loading ? <Loader2 size={11} className="animate-spin" /> : <Users size={11} />}
        {loading ? 'Optimising...' : 'Generate Joint Financial Plan'}
      </button>

      {plan && (
        <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }}
          className="bg-pink-500/5 border border-pink-500/20 rounded-xl p-3">
          <p className="text-[11px] text-gray-300 leading-relaxed"
            dangerouslySetInnerHTML={{ __html: plan.replace(/\*\*(.*?)\*\*/g,'<strong class="text-white">$1</strong>').replace(/\n/g,'<br/>') }} />
        </motion.div>
      )}
    </div>
  )
}

// ─── 6. SIP CALCULATOR V2 ────────────────────────────────────────────────────
export function SIPCalculatorV2() {
  const [monthly, setMonthly]     = useState(10000)
  const [stepUp, setStepUp]       = useState(10)
  const [years, setYears]         = useState(20)
  const [returns, setReturns]     = useState(12)
  const [inflation, setInflation] = useState(6)

  // Step-up SIP calculation
  const calc = () => {
    let corpus = 0; let invested = 0; let sip = monthly
    for (let y = 0; y < years; y++) {
      for (let m = 0; m < 12; m++) {
        corpus  = corpus * (1 + returns/100/12) + sip
        invested += sip
      }
      sip = sip * (1 + stepUp/100)
    }
    const realReturn = (1 + returns/100) / (1 + inflation/100) - 1
    const realCorpus = corpus / Math.pow(1 + inflation/100, years)
    return { corpus: Math.round(corpus), invested: Math.round(invested), realCorpus: Math.round(realCorpus), finalSip: Math.round(sip) }
  }

  const result = calc()

  return (
    <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-4 space-y-3">
      <div className="flex items-center gap-2">
        <Calculator size={14} className="text-brand-400" />
        <p className="text-xs font-semibold text-gray-300">SIP Calculator V2 — Step-up</p>
      </div>

      <div className="grid grid-cols-2 gap-x-4 gap-y-3">
        {[
          { label:`Monthly SIP: ₹${monthly.toLocaleString('en-IN')}`, val:monthly, set:setMonthly, min:500, max:100000, step:500 },
          { label:`Annual step-up: ${stepUp}%`,  val:stepUp,   set:setStepUp,   min:0, max:25, step:1 },
          { label:`Years: ${years}`,              val:years,    set:setYears,    min:1, max:40, step:1 },
          { label:`Expected return: ${returns}%`, val:returns,  set:setReturns,  min:6, max:20, step:0.5 },
          { label:`Inflation: ${inflation}%`,     val:inflation,set:setInflation,min:3, max:12, step:0.5 },
        ].map(s => (
          <div key={s.label}>
            <div className="flex justify-between mb-0.5">
              <span className="text-[10px] text-gray-400">{s.label}</span>
            </div>
            <input type="range" min={s.min} max={s.max} step={s.step} value={s.val}
              onChange={e => s.set(Number(e.target.value))}
              className="w-full accent-brand-500 h-1.5" />
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-2 pt-1">
        {[
          { l:'Corpus (nominal)',        v:formatINR(result.corpus, true),    c:'text-brand-400' },
          { l:'Corpus (real, today ₹)',  v:formatINR(result.realCorpus, true),c:'text-neon-green' },
          { l:'Total invested',          v:formatINR(result.invested, true),  c:'text-gray-300' },
          { l:`Final SIP (yr ${years})`, v:`₹${result.finalSip.toLocaleString('en-IN')}/mo`, c:'text-purple-400' },
        ].map(s => (
          <div key={s.l} className="bg-surface-600/50 rounded-lg p-2.5">
            <p className="text-[9px] text-gray-500 mb-0.5">{s.l}</p>
            <p className={cn('text-sm font-black font-mono', s.c)}>{s.v}</p>
          </div>
        ))}
      </div>

      <p className="text-[10px] text-gray-500 text-center">
        With {stepUp}% annual step-up, you invest {formatINR(result.invested, true)} total and build {formatINR(result.corpus, true)}
      </p>
    </div>
  )
}

// ─── 7. PDF EXPORT ───────────────────────────────────────────────────────────
export function PDFExport() {
  const { portfolio, signals } = useStore()
  const [generating, setGenerating] = useState(false)

  const generate = async () => {
    setGenerating(true)
    // Build HTML report
    const html = `
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>ET Alpha Portfolio Report</title>
<style>
  body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 40px; color: #1a1a2e; }
  h1 { color: #0055a5; border-bottom: 3px solid #0055a5; padding-bottom: 10px; }
  h2 { color: #003087; margin-top: 30px; }
  table { width: 100%; border-collapse: collapse; margin: 16px 0; font-size: 12px; }
  th { background: #003087; color: white; padding: 8px 12px; text-align: left; }
  td { padding: 7px 12px; border-bottom: 1px solid #ddd; }
  tr:nth-child(even) { background: #f5f5f5; }
  .green { color: #1a7a1a; font-weight: bold; }
  .red { color: #cc0000; font-weight: bold; }
  .stat { display: inline-block; background: #e8f0fe; border-radius: 8px; padding: 12px 20px; margin: 8px; text-align: center; }
  .stat-val { font-size: 24px; font-weight: bold; color: #003087; }
  .stat-lbl { font-size: 11px; color: #666; }
  .signal { background: #fff8e6; border-left: 4px solid #ffc61a; padding: 10px; margin: 8px 0; border-radius: 4px; }
  @media print { body { padding: 20px; } }
</style>
</head>
<body>
<h1>ET Alpha — Portfolio Report</h1>
<p style="color:#666;font-size:12px">Generated: ${new Date().toLocaleString('en-IN')} | AI-powered by Groq LLaMA-3.3-70B</p>

<h2>Portfolio Summary</h2>
<div>
  <div class="stat"><div class="stat-val">₹${(portfolio.totalValue/1e5).toFixed(2)}L</div><div class="stat-lbl">Total Value</div></div>
  <div class="stat"><div class="stat-val" style="color:#1a7a1a">+${portfolio.overallPnlPct}%</div><div class="stat-lbl">Overall P&L</div></div>
  <div class="stat"><div class="stat-val">${portfolio.overallXirr}%</div><div class="stat-lbl">XIRR</div></div>
  <div class="stat"><div class="stat-val">${portfolio.healthScore}/100</div><div class="stat-lbl">Health Score</div></div>
</div>

<h2>Direct Equity Holdings</h2>
<table>
<tr><th>Stock</th><th>Qty</th><th>Avg Cost</th><th>LTP</th><th>Value</th><th>P&L</th></tr>
${portfolio.holdings.map(h => `
<tr>
  <td><strong>${h.ticker}</strong><br><span style="font-size:10px;color:#666">${h.sector}</span></td>
  <td>${h.qty}</td>
  <td>₹${h.avgCost.toLocaleString('en-IN')}</td>
  <td>₹${h.ltp.toLocaleString('en-IN')}</td>
  <td>₹${h.currentValue.toLocaleString('en-IN')}</td>
  <td class="${h.pnlPct >= 0 ? 'green' : 'red'}">${h.pnlPct >= 0 ? '+' : ''}${h.pnlPct}%</td>
</tr>`).join('')}
</table>

<h2>Mutual Funds</h2>
<table>
<tr><th>Fund</th><th>Category</th><th>XIRR</th><th>Invested</th><th>Value</th><th>Overlap</th></tr>
${portfolio.funds.map(f => `
<tr>
  <td>${f.name}</td>
  <td>${f.category}</td>
  <td class="${f.xirr > 12 ? 'green' : ''}">${f.xirr}%</td>
  <td>₹${f.invested.toLocaleString('en-IN')}</td>
  <td>₹${f.currentValue.toLocaleString('en-IN')}</td>
  <td class="${(f.overlapPct ?? 0) > 60 ? 'red' : 'green'}">${f.overlapPct ?? 0}%</td>
</tr>`).join('')}
</table>

<h2>Top Signals Today</h2>
${signals.slice(0, 5).map(s => `
<div class="signal">
  <strong>${s.ticker}</strong> — ${s.headline}<br>
  <span style="font-size:11px;color:#666">${s.detail?.slice(0,120)}...</span>
</div>`).join('')}

<p style="margin-top:40px;font-size:10px;color:#999;text-align:center">
ET Alpha AI Market Co-Pilot | Generated by Groq LLaMA-3.3-70B | Not financial advice | SEBI guidelines apply
</p>
</body>
</html>`

    const blob   = new Blob([html], { type: 'text/html' })
    const url    = URL.createObjectURL(blob)
    const w      = window.open(url, '_blank')
    setTimeout(() => { w?.print(); setGenerating(false) }, 800)
  }

  return (
    <button onClick={generate} disabled={generating || !portfolio.loaded}
      className="w-full flex items-center justify-center gap-2 bg-surface-700 border border-surface-500/50 text-gray-300 hover:text-white hover:border-brand-500/30 py-3 rounded-xl text-sm font-medium transition-all disabled:opacity-40">
      {generating ? <Loader2 size={15} className="animate-spin" /> : <Download size={15} />}
      {generating ? 'Generating PDF...' : 'Export Portfolio as PDF'}
    </button>
  )
}
