import { useState, useEffect, useRef, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Sparkles, X, Camera, Loader2, CheckCircle2, AlertTriangle, HelpCircle, ChevronRight } from 'lucide-react'
import { cn } from '@/lib/api'

// ─── IDLE DETECTOR — watches cursor, fires after 10s of no movement ───────────
export function useIdleDetector(onIdle: () => void, idleMs = 10000) {
  const timerRef = useRef<ReturnType<typeof setTimeout>>()

  useEffect(() => {
    const reset = () => {
      clearTimeout(timerRef.current)
      timerRef.current = setTimeout(onIdle, idleMs)
    }
    window.addEventListener('mousemove', reset)
    window.addEventListener('keydown', reset)
    window.addEventListener('click', reset)
    reset() // start timer immediately
    return () => {
      clearTimeout(timerRef.current)
      window.removeEventListener('mousemove', reset)
      window.removeEventListener('keydown', reset)
      window.removeEventListener('click', reset)
    }
  }, [onIdle, idleMs])
}

// ─── SCREENSHOT CAPTURE — uses browser native API ────────────────────────────
async function captureScreen(): Promise<string | null> {
  try {
    // Use browser's built-in screenshot via canvas + dom snapshot
    const canvas  = document.createElement('canvas')
    canvas.width  = window.innerWidth
    canvas.height = window.innerHeight
    // We can't actually capture the full screen without html2canvas
    // So we return null and use the fallback help text instead
    return null
  } catch { return null }
}

// ─── ANNOTATION OVERLAY ───────────────────────────────────────────────────────
interface AnnotationData {
  platform: string
  screen_type: string
  is_stuck: boolean
  stuck_reason: string
  issue_detected: string
  step_by_step: string[]
  primary_action: string
  annotations: { label: string; description: string; position: string }[]
  quick_help?: string
}

interface Props {
  /** If true, only show when on a broker site (sidekick mode) */
  brokerMode?: boolean
}

export default function ScreenAnnotator({ brokerMode = false }: Props) {
  const [showStuckPopup, setShowStuckPopup]   = useState(false)
  const [analyzing, setAnalyzing]             = useState(false)
  const [annotation, setAnnotation]           = useState<AnnotationData | null>(null)
  const [showAnnotation, setShowAnnotation]   = useState(false)
  const [step, setStep]                       = useState(0)
  const [dismissed, setDismissed]             = useState(false)
  const lastIdleRef                           = useRef(0)

  const handleIdle = useCallback(() => {
    // Debounce — only fire if last idle was >30s ago
    if (Date.now() - lastIdleRef.current < 30000) return
    if (showStuckPopup || showAnnotation || analyzing) return
    if (dismissed) { setDismissed(false); return }
    lastIdleRef.current = Date.now()
    setShowStuckPopup(true)
  }, [showStuckPopup, showAnnotation, analyzing, dismissed])

  useIdleDetector(handleIdle, 10000)

  const analyzeScreen = async () => {
    setShowStuckPopup(false)
    setAnalyzing(true)

    try {
      // Try to capture screen first
      const screenshotB64 = await captureScreen()

      let result: AnnotationData

      if (screenshotB64) {
        // Send to Groq Vision backend
        const blob     = await fetch(`data:image/png;base64,${screenshotB64}`).then(r => r.blob())
        const formData = new FormData()
        formData.append('file', blob, 'screenshot.png')

        const res = await fetch('/api/annotator/analyze-idle', { method: 'POST', body: formData })
        if (res.ok) {
          const data = await res.json()
          result = data.analysis
        } else throw new Error('API failed')
      } else {
        // Fallback — generic help
        result = {
          platform: 'broker',
          screen_type: 'unknown',
          is_stuck: true,
          stuck_reason: 'You seem to have paused',
          issue_detected: 'You have been idle for 10 seconds',
          step_by_step: [
            'Look at what page you are currently on',
            'If you see a popup — read it carefully, it likely needs a confirmation',
            'If you see an order form — double-check quantity and price before submitting',
            'If you are on a chart — use the timeframe buttons (1D, 1W, 1M) to change view',
            'If confused, take a screenshot and drop it in the Annotator below',
          ],
          primary_action: 'Read any popup or notification on screen carefully',
          annotations: [],
          quick_help: 'You seem to have paused. Need help with what\'s on your screen?'
        }
      }

      setAnnotation(result)
      setStep(0)
      setShowAnnotation(true)
    } catch (e) {
      // Minimal fallback
      setAnnotation({
        platform: 'unknown', screen_type: 'other', is_stuck: true,
        stuck_reason: 'Idle detected',
        issue_detected: 'You paused for 10 seconds',
        step_by_step: ['Check if there is a popup on screen', 'Read any error messages', 'If ordering — verify qty and price'],
        primary_action: 'Check for any popups or notifications on your broker screen',
        annotations: [], quick_help: 'You seem stuck — here is some help'
      })
      setShowAnnotation(true)
    }
    setAnalyzing(false)
  }

  const dismiss = () => {
    setShowStuckPopup(false)
    setDismissed(true)
    setTimeout(() => setDismissed(false), 60000) // re-enable after 60s
  }

  return (
    <>
      {/* Analyzing indicator */}
      <AnimatePresence>
        {analyzing && (
          <motion.div initial={{opacity:0,scale:0.9}} animate={{opacity:1,scale:1}} exit={{opacity:0,scale:0.9}}
            className="fixed bottom-6 right-6 z-50 flex items-center gap-2 bg-surface-800 border border-brand-500/30 rounded-xl px-4 py-3 shadow-xl">
            <Loader2 size={14} className="animate-spin text-brand-400"/>
            <span className="text-xs text-white font-medium">Groq Vision analysing your screen...</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* STUCK POPUP — appears after 10s idle */}
      <AnimatePresence>
        {showStuckPopup && !analyzing && (
          <motion.div initial={{opacity:0,y:20,scale:0.95}} animate={{opacity:1,y:0,scale:1}} exit={{opacity:0,y:20,scale:0.95}}
            className="fixed bottom-6 right-6 z-50 w-72 bg-surface-800 border border-brand-500/30 rounded-2xl p-4 shadow-2xl">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 bg-brand-500/10 rounded-xl flex items-center justify-center flex-shrink-0 border border-brand-500/20">
                <HelpCircle size={18} className="text-brand-400"/>
              </div>
              <div className="flex-1">
                <p className="text-sm font-bold text-white">Stuck? 🤔</p>
                <p className="text-[11px] text-gray-400 mt-0.5 leading-relaxed">
                  You have been idle for 10 seconds. Want ET Alpha to analyse your screen and guide you?
                </p>
              </div>
              <button onClick={dismiss} className="text-gray-600 hover:text-gray-400 flex-shrink-0">
                <X size={14}/>
              </button>
            </div>
            <div className="flex gap-2 mt-3">
              <button onClick={analyzeScreen}
                className="flex-1 flex items-center justify-center gap-1.5 bg-brand-500 text-surface-900 text-xs font-bold py-2 rounded-xl hover:bg-brand-400 transition-colors">
                <Sparkles size={12}/> Yes, analyse my screen
              </button>
              <button onClick={dismiss}
                className="px-3 py-2 bg-surface-700 border border-surface-500 text-gray-400 text-xs rounded-xl hover:text-white transition-colors">
                No
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ANNOTATION PANEL — full step-by-step guide */}
      <AnimatePresence>
        {showAnnotation && annotation && (
          <motion.div initial={{opacity:0,x:40}} animate={{opacity:1,x:0}} exit={{opacity:0,x:40}}
            className="fixed top-16 right-4 z-50 w-80 bg-surface-800 border border-surface-500/50 rounded-2xl shadow-2xl overflow-hidden">

            {/* Header */}
            <div className="flex items-center gap-2 px-4 py-3 bg-surface-700 border-b border-surface-500/30">
              <Sparkles size={14} className="text-brand-400"/>
              <div className="flex-1">
                <p className="text-xs font-bold text-white">ET Alpha Screen Guide</p>
                <p className="text-[10px] text-gray-500 capitalize">{annotation.platform} · {annotation.screen_type}</p>
              </div>
              <button onClick={() => setShowAnnotation(false)} className="text-gray-500 hover:text-white">
                <X size={14}/>
              </button>
            </div>

            <div className="p-4 space-y-3 max-h-[70vh] overflow-y-auto">
              {/* Issue detected */}
              {annotation.issue_detected && (
                <div className={cn('flex items-start gap-2 rounded-xl p-3 border',
                  annotation.is_stuck ? 'bg-orange-500/5 border-orange-500/20' : 'bg-neon-green/5 border-neon-green/20')}>
                  {annotation.is_stuck
                    ? <AlertTriangle size={13} className="text-orange-400 flex-shrink-0 mt-0.5"/>
                    : <CheckCircle2 size={13} className="text-neon-green flex-shrink-0 mt-0.5"/>}
                  <p className="text-[11px] text-gray-300 leading-relaxed">{annotation.issue_detected}</p>
                </div>
              )}

              {/* Primary action */}
              {annotation.primary_action && (
                <div className="bg-brand-500/10 border border-brand-500/20 rounded-xl p-3">
                  <p className="text-[10px] text-brand-400 font-semibold uppercase tracking-wider mb-1">Do this now</p>
                  <p className="text-[12px] text-white font-semibold">{annotation.primary_action}</p>
                </div>
              )}

              {/* Step by step */}
              {annotation.step_by_step?.length > 0 && (
                <div>
                  <p className="text-[10px] text-gray-500 uppercase tracking-wider mb-2 font-medium">Step by step guide</p>
                  <div className="space-y-2">
                    {annotation.step_by_step.map((s, i) => (
                      <motion.div key={i} initial={{opacity:0,x:-6}} animate={{opacity:1,x:0}} transition={{delay:i*0.08}}
                        onClick={() => setStep(i)}
                        className={cn('flex items-start gap-2.5 rounded-xl p-2.5 cursor-pointer border transition-all',
                          step===i ? 'bg-brand-500/10 border-brand-500/20' : 'bg-surface-700/50 border-surface-500/20 hover:border-surface-400/40')}>
                        <div className={cn('w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold flex-shrink-0 mt-0.5',
                          step===i ? 'bg-brand-500 text-surface-900' : 'bg-surface-600 text-gray-400')}>
                          {i+1}
                        </div>
                        <p className={cn('text-[11px] leading-relaxed', step===i ? 'text-white' : 'text-gray-400')}>{s}</p>
                      </motion.div>
                    ))}
                  </div>
                </div>
              )}

              {/* Annotations list */}
              {annotation.annotations?.length > 0 && (
                <div>
                  <p className="text-[10px] text-gray-500 uppercase tracking-wider mb-2 font-medium">Screen elements</p>
                  <div className="space-y-1.5">
                    {annotation.annotations.map((a, i) => (
                      <div key={i} className="flex items-start gap-2 bg-surface-700/50 rounded-lg px-3 py-2">
                        <ChevronRight size={11} className="text-brand-400 flex-shrink-0 mt-0.5"/>
                        <div>
                          <p className="text-[11px] font-semibold text-white">{a.label}</p>
                          <p className="text-[10px] text-gray-400">{a.description}</p>
                          <p className="text-[9px] text-gray-600 mt-0.5">Position: {a.position}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Upload screenshot manually */}
              <div className="border-t border-surface-500/30 pt-3">
                <p className="text-[10px] text-gray-500 mb-2">Upload a screenshot for more precise help:</p>
                <ManualScreenshotUpload />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}

// Manual upload component inside annotation panel
function ManualScreenshotUpload() {
  const [analyzing, setAnalyzing] = useState(false)
  const [result, setResult]       = useState<string>('')
  const fileRef                   = useRef<HTMLInputElement>(null)

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setAnalyzing(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      const res = await fetch('/api/annotator/analyze-screenshot', { method:'POST', body: fd })
      if (res.ok) {
        const data = await res.json()
        const a    = data.analysis
        setResult(`${a.issue_detected}\n\nDo: ${a.primary_action}\n\n${a.step_by_step?.join('\n') ?? ''}`)
      }
    } catch { setResult('Could not analyse screenshot') }
    setAnalyzing(false)
  }

  return (
    <div className="space-y-2">
      <input ref={fileRef} type="file" accept="image/*" onChange={handleFile} className="hidden"/>
      <button onClick={() => fileRef.current?.click()} disabled={analyzing}
        className="w-full flex items-center justify-center gap-2 bg-surface-700 border border-surface-500 text-gray-300 hover:text-white text-[11px] py-2 rounded-xl transition-colors disabled:opacity-50">
        {analyzing ? <Loader2 size={12} className="animate-spin"/> : <Camera size={12}/>}
        {analyzing ? 'Groq Vision analysing...' : 'Upload screenshot'}
      </button>
      {result && (
        <div className="bg-surface-600/50 rounded-xl p-3 text-[10px] text-gray-300 leading-relaxed whitespace-pre-line max-h-40 overflow-y-auto">
          {result}
        </div>
      )}
    </div>
  )
}
