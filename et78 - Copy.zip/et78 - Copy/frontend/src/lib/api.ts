import axios from 'axios'

// ─── GROQ ─────────────────────────────────────────────────────────────────────
const META_ENV = ((import.meta as any).env ?? {}) as Record<string, string | undefined>
const GROQ_KEY  = META_ENV.VITE_GROQ_API_KEY || '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'
const GROQ_BASE = 'https://api.groq.com/openai/v1'
export const GROQ_MODEL = 'llama-3.3-70b-versatile'
export const GROQ_SEARCH_MODEL = 'groq/compound-mini'

export async function streamGroqResponse(
  system: string,
  messages: { role: string; content: string }[],
  onChunk: (t: string) => void,
  onDone?: () => void
): Promise<void> {
  const res = await fetch(`${GROQ_BASE}/chat/completions`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${GROQ_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: GROQ_MODEL, max_tokens: 1024, temperature: 0.7, stream: true, messages: [{ role: 'system', content: system }, ...messages] }),
  })
  if (!res.ok) throw new Error(`Groq ${res.status}: ${await res.text()}`)
  const reader = res.body!.getReader()
  const dec    = new TextDecoder()
  while (true) {
    const { done, value } = await reader.read()
    if (done) break
    for (const line of dec.decode(value).split('\n').filter(l => l.startsWith('data: '))) {
      const d = line.slice(6)
      if (d === '[DONE]') { onDone?.(); return }
      try { const t = JSON.parse(d).choices?.[0]?.delta?.content || ''; if (t) onChunk(t) } catch {}
    }
  }
  onDone?.()
}

export async function groqChat(system: string, user: string): Promise<string> {
  const res = await fetch(`${GROQ_BASE}/chat/completions`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${GROQ_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: GROQ_MODEL, max_tokens: 700, temperature: 0.4, stream: false, messages: [{ role: 'system', content: system }, { role: 'user', content: user }] }),
  })
  const d = await res.json()
  if (!res.ok) throw new Error(`Groq ${res.status}: ${JSON.stringify(d)}`)
  return d.choices?.[0]?.message?.content ?? ''
}

export interface GroqSearchResult {
  title: string
  url: string
  content: string
  score?: number
}

export interface GroqSearchResponse {
  content: string
  citations: GroqSearchResult[]
  reasoning?: string
}

export async function groqSearchChat(
  system: string,
  user: string,
  searchSettings?: { include_domains?: string[]; exclude_domains?: string[]; country?: string }
): Promise<GroqSearchResponse> {
  const res = await fetch(`${GROQ_BASE}/chat/completions`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${GROQ_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: GROQ_SEARCH_MODEL,
      temperature: 0.2,
      max_tokens: 900,
      stream: false,
      search_settings: searchSettings,
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: user },
      ],
    }),
  })
  const data = await res.json()
  if (!res.ok) throw new Error(`Groq ${res.status}: ${JSON.stringify(data)}`)
  const message = data.choices?.[0]?.message ?? {}
  const searchResults = message.executed_tools?.[0]?.search_results?.results ?? []
  return {
    content: message.content ?? '',
    citations: searchResults,
    reasoning: message.reasoning,
  }
}

// ─── Re-export market data functions ──────────────────────────────────────────
export { fetchLiveQuote, fetchMultipleQuotes, SEED_PRICES, type LiveQuote } from './marketData'

// ─── NSE TICKERS ──────────────────────────────────────────────────────────────
export const NSE_TICKERS = [
  { sym: 'NIFTY 50',   yf: '^NSEI'         },
  { sym: 'SENSEX',     yf: '^BSESN'        },
  { sym: 'BANKNIFTY',  yf: '^NSEBANK'      },
  { sym: 'RELIANCE',   yf: 'RELIANCE.NS'   },
  { sym: 'TCS',        yf: 'TCS.NS'        },
  { sym: 'INFY',       yf: 'INFY.NS'       },
  { sym: 'HDFCBANK',   yf: 'HDFCBANK.NS'   },
  { sym: 'ICICIBANK',  yf: 'ICICIBANK.NS'  },
  { sym: 'TATAMOT',    yf: 'TATAMOTORS.NS' },
  { sym: 'WIPRO',      yf: 'WIPRO.NS'      },
  { sym: 'ZOMATO',     yf: 'ZOMATO.NS'     },
  { sym: 'BAJFINANCE', yf: 'BAJFINANCE.NS' },
  { sym: 'ADANIPORTS', yf: 'ADANIPORTS.NS' },
  { sym: 'HINDUNILVR', yf: 'HINDUNILVR.NS' },
  { sym: 'MARUTI',     yf: 'MARUTI.NS'     },
  { sym: 'AXISBANK',   yf: 'AXISBANK.NS'   },
  { sym: 'SUNPHARMA',  yf: 'SUNPHARMA.NS'  },
  { sym: 'LTIM',       yf: 'LTIM.NS'       },
]

// ─── GROQ SIGNAL GENERATION FROM REAL PRICES ──────────────────────────────────
export async function generateLiveSignals(quotes: Record<string, any>): Promise<any[]> {
  const movers = Object.entries(quotes)
    .filter(([, q]: any) => Math.abs(q.chgPct) > 0.1)
    .sort((a: any, b: any) => Math.abs(b[1].chgPct) - Math.abs(a[1].chgPct))
    .slice(0, 10)
    .map(([sym, q]: any) => {
      const label = NSE_TICKERS.find(t => t.yf === sym)?.sym ?? sym
      return `${label}: ₹${q.price.toFixed(2)} (${q.chgPct >= 0 ? '+' : ''}${q.chgPct}%, Vol:${(q.volume/1e5).toFixed(1)}L)`
    }).join('\n')

  if (!movers) return []

  try {
    const text = await groqChat(
      'You are a real-time NSE market signal engine. Return ONLY valid compact JSON, no markdown.',
      `Real NSE data:\n${movers}\n\nGenerate 5 specific signals. Return ONLY this JSON array:\n[{"ticker":"SYMBOL","company":"Company Name","type":"pattern|fundamental|alert|bulk_deal","headline":"Headline with real price","detail":"2-3 sentences with actual numbers","sentiment":"bullish|bearish|neutral","strength":50-92,"actionable":true,"source":"NSE Live","timestamp":${Date.now()}}]`
    )
    const match = text.match(/\[[\s\S]*?\]/)
    if (!match) return []
    return JSON.parse(match[0]).map((s: any, i: number) => ({ ...s, id: `live-${Date.now()}-${i}` }))
  } catch { return [] }
}

// ─── PORTFOLIO BASE ────────────────────────────────────────────────────────────
export const PORTFOLIO_TICKERS = [
  { ticker: 'RELIANCE', yfSym: 'RELIANCE.NS',  name: 'Reliance Industries', qty: 45,  avgCost: 1880, sector: 'Energy'   },
  { ticker: 'INFY',     yfSym: 'INFY.NS',      name: 'Infosys Ltd',         qty: 120, avgCost: 1420, sector: 'IT'       },
  { ticker: 'HDFCBANK', yfSym: 'HDFCBANK.NS',  name: 'HDFC Bank',           qty: 200, avgCost: 1510, sector: 'Banking'  },
  { ticker: 'TATAMOT',  yfSym: 'TATAMOTORS.NS',name: 'Tata Motors',         qty: 300, avgCost: 610,  sector: 'Auto'     },
  { ticker: 'ZOMATO',   yfSym: 'ZOMATO.NS',    name: 'Zomato',              qty: 800, avgCost: 142,  sector: 'Consumer' },
]

export async function fetchLivePortfolio() {
  const { fetchMultipleQuotes } = await import('./marketData')
  const quotes = await fetchMultipleQuotes(PORTFOLIO_TICKERS.map(t => t.yfSym))
  const rows = PORTFOLIO_TICKERS.map(t => {
    const q = quotes[t.yfSym]
    const ltp = q?.price ?? t.avgCost * 1.1
    const cv  = +(ltp * t.qty).toFixed(0)
    const inv = t.avgCost * t.qty
    return { ...t, ltp: +ltp.toFixed(2), currentValue: cv, pnl: +(cv - inv).toFixed(0), pnlPct: +((cv - inv) / inv * 100).toFixed(2), weight: 0 }
  })
  const total = rows.reduce((s, r) => s + r.currentValue, 0)
  return rows.map(r => ({ ...r, weight: +((r.currentValue / total) * 100).toFixed(1) }))
}

// ─── SEED funds (shown instantly, replaced by live NAVs) ──────────────────────
const FUND_SEEDS = [
  { code:'120503', name:'Mirae Asset Large Cap',  amc:'Mirae', category:'Large Cap', units:2099, invested:180000, overlapPct:68, expenseRatio:0.54, benchmarkReturn:12.8, seedNav:112.4, xirr:14.2 },
  { code:'120465', name:'Axis Bluechip Fund',     amc:'Axis',  category:'Large Cap', units:2610, invested:120000, overlapPct:71, expenseRatio:0.41, benchmarkReturn:12.8, seedNav:56.7,  xirr:12.1 },
  { code:'122639', name:'Parag Parikh Flexi Cap', amc:'PPFAS', category:'Flexi Cap', units:3954, invested:200000, overlapPct:22, expenseRatio:0.63, benchmarkReturn:15.1, seedNav:78.9,  xirr:18.4 },
  { code:'125497', name:'SBI Small Cap Fund',     amc:'SBI',   category:'Small Cap', units:1447, invested:150000, overlapPct:8,  expenseRatio:0.71, benchmarkReturn:18.2, seedNav:198.3, xirr:22.1 },
]

export const MOCK_FUNDS = FUND_SEEDS.map(f => ({
  ...f, nav: f.seedNav, currentValue: Math.round(f.units * f.seedNav),
}))

export async function fetchLiveFunds() {
  const results = await Promise.allSettled(
    FUND_SEEDS.map(async (f) => {
      try {
        const r = await axios.get(`https://api.mfapi.in/mf/${f.code}`, { timeout: 6000 })
        const nav = parseFloat(r.data?.data?.[0]?.nav ?? f.seedNav)
        const xirr = (() => {
          // Simple XIRR approximation: ((currentValue/invested)^(1/years) - 1) * 100
          const cv = nav * f.units
          const years = 3
          return +((Math.pow(cv / f.invested, 1 / years) - 1) * 100).toFixed(1)
        })()
        return { ...f, nav, currentValue: Math.round(nav * f.units), xirr }
      } catch {
        return { ...f, nav: f.seedNav, currentValue: Math.round(f.units * f.seedNav) }
      }
    })
  )
  return results.map((r, i) =>
    r.status === 'fulfilled' ? r.value : { ...FUND_SEEDS[i], nav: FUND_SEEDS[i].seedNav, currentValue: Math.round(FUND_SEEDS[i].units * FUND_SEEDS[i].seedNav) }
  )
}

// ─── BROWSER DETECTION ────────────────────────────────────────────────────────
export function detectCurrentPlatform(url: string): string | null {
  const u = url.toLowerCase()
  if (u.includes('sharekhan'))     return 'sharekhan'
  if (u.includes('kite.zerodha')) return 'zerodha'
  if (u.includes('groww.in'))     return 'groww'
  if (u.includes('angelone'))     return 'angel'
  if (u.includes('upstox'))       return 'upstox'
  if (u.includes('nseindia'))     return 'nse'
  if (u.includes('moneycontrol')) return 'moneycontrol'
  if (u.includes('screener.in'))  return 'screener'
  if (u.includes('tickertape'))   return 'tickertape'
  return null
}

// ─── UTILS ────────────────────────────────────────────────────────────────────
export const api = axios.create({ baseURL: '/api', timeout: 60_000 })

export interface MarketIndicator {
  symbol: string
  ticker: string
  company: string
  sector: string
  price: number
  previousClose: number
  change: number
  changePct: number
  open: number
  high: number
  low: number
  volume: number
  avgVolume: number
  rsi: number
  sma20: number
  sma50: number
  ema12: number
  ema26: number
  macd: number
  macdSignal: number
  macdHistogram: number
  atr: number
  atr_pct: number
  support: number
  resistance: number
  volumeSpike: number
  momentum5d: number
  momentum20d: number
  high52w: number
  low52w: number
  distanceTo52wHighPct: number
  distanceTo52wLowPct: number
  trend: 'bullish' | 'bearish' | 'neutral'
  setup: string
  bullishScore: number
  bearishScore: number
  conviction: number
  riskFlags: string[]
  timestamp: number
}

export interface MarketOverview {
  tracked: number
  advancers: number
  decliners: number
  bullishSetups: number
  bearishSetups: number
  avgRsi: number
  topSetup: string | null
  timestamp: number
}

export interface MarketDashboardResponse {
  overview: MarketOverview
  indicators: MarketIndicator[]
  source: string
}

export interface SignalAnalysisResponse {
  ticker: string
  company: string
  analysis: string
  verdict: string
  confidence: number
  bullCase?: string
  bearCase?: string
  nextTrigger?: string
  riskFlags: string[]
  timestamp: number
}

export async function fetchMarketDashboard(symbols?: string[]) {
  const params = symbols?.length ? { symbols: symbols.join(',') } : undefined
  const { data } = await api.get<MarketDashboardResponse>('/signals/indicators', { params })
  return data
}

export async function fetchRadarSignals(params?: { limit?: number; type?: string; sentiment?: string }) {
  const { data } = await api.get<{ signals: any[]; total: number; source: string }>('/signals', { params })
  return data
}

export async function analyzeTickerWithAI(ticker: string) {
  const { data } = await api.post<SignalAnalysisResponse>(`/signals/analyze/${ticker}`)
  return data
}

export function formatINR(n: number, compact = false): string {
  if (compact) {
    if (Math.abs(n) >= 1e7) return `₹${(n/1e7).toFixed(2)}Cr`
    if (Math.abs(n) >= 1e5) return `₹${(n/1e5).toFixed(2)}L`
  }
  return `₹${n.toLocaleString('en-IN')}`
}
export function formatPct(n: number) { return `${n >= 0 ? '+' : ''}${n.toFixed(2)}%` }
export function timeAgo(ts: number): string {
  const d = Date.now() - ts
  if (d < 60000)    return 'just now'
  if (d < 3600000)  return `${Math.floor(d/60000)}m ago`
  if (d < 86400000) return `${Math.floor(d/3600000)}h ago`
  return `${Math.floor(d/86400000)}d ago`
}
export function cn(...cls: (string|undefined|null|false)[]) { return cls.filter(Boolean).join(' ') }
export function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)) }
