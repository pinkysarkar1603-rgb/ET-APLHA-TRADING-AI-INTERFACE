import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Shield, Play, Square, RefreshCw, Bell, Trash2, CheckCheck, Zap, TrendingDown, TrendingUp, Newspaper, Receipt, Activity, Loader2, BrainCircuit } from 'lucide-react'
import { useStore } from '@/store'
import { cn, formatINR } from '@/lib/api'

interface GuardianAlert {
  id: string; agent: string; type: string; severity: 'high'|'medium'|'low'
  title: string; body: string; ts: number; read: boolean
}

const TYPE_ICON: Record<string, any> = {
  price_move: TrendingUp, news: Newspaper, tax: Receipt, sip: Activity,
}
const SEV_COLOR: Record<string, string> = {
  high:   'border-neon-red/30 bg-neon-red/5',
  medium: 'border-brand-500/30 bg-brand-500/5',
  low:    'border-neon-green/30 bg-neon-green/5',
}
const SEV_DOT: Record<string, string> = {
  high: 'bg-neon-red', medium: 'bg-brand-400', low: 'bg-neon-green',
}

const AGENT_NAMES = ['Price Watch', 'News Sentinel', 'Tax Guardian', 'SIP Health'] as const
type GuardianAgentName = typeof AGENT_NAMES[number]

function timeAgo(ts: number) {
  const d = Date.now() - ts * 1000
  if (d < 60000)    return 'just now'
  if (d < 3600000)  return `${Math.floor(d/60000)}m ago`
  if (d < 86400000) return `${Math.floor(d/3600000)}h ago`
  return `${Math.floor(d/86400000)}d ago`
}

export default function GuardianPage() {
  const { addNotification, addAuditEntry } = useStore()
  const [alerts, setAlerts]         = useState<GuardianAlert[]>([])
  const [status, setStatus]         = useState<any>({running:false, run_count:0, last_run:null, next_run:null})
  const [loading, setLoading]       = useState(false)
  const [scanning, setScanning]     = useState(false)
  const [notifPerm, setNotifPerm]   = useState(Notification.permission)
  const [lastAlertCount, setLastAlertCount] = useState(0)
  const pollRef = useRef<ReturnType<typeof setInterval>>()

  // Poll backend every 15s for new alerts + status
  useEffect(() => {
    fetchAll()
    pollRef.current = setInterval(fetchAll, 15000)
    return () => clearInterval(pollRef.current)
  }, [])

  // Fire desktop notification when new alerts arrive
  useEffect(() => {
    if (alerts.length > lastAlertCount && lastAlertCount > 0) {
      const newAlerts = alerts.slice(0, alerts.length - lastAlertCount)
      newAlerts.forEach(a => {
        // Bell notification
        addNotification({ type:'agent', title:a.title, body:a.body })
        // Desktop notification
        if (Notification.permission === 'granted') {
          new Notification(`🛡️ ET Alpha Guardian: ${a.agent}`, {
            body: a.title,
            icon: '/vite.svg',
            tag: a.id,
          })
        }
      })
    }
    setLastAlertCount(alerts.length)
  }, [alerts.length])

  const fetchAll = async () => {
    try {
      const [aRes, sRes] = await Promise.all([
        fetch('/api/guardian/alerts?limit=50'),
        fetch('/api/guardian/status'),
      ])
      if (aRes.ok) { const d = await aRes.json(); setAlerts(d.alerts || []) }
      if (sRes.ok) { const d = await sRes.json(); setStatus(d) }
    } catch {}
  }

  const startGuardian = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/guardian/start', { method:'POST' })
      if (res.ok) {
        addAuditEntry({ agentName:'Guardian', step:'Guardian started — monitoring every 5 minutes', input:'4 sub-agents', output:'', status:'running' })
        addNotification({ type:'agent', title:'🛡️ Guardian activated', body:'Price Watch, News Sentinel, Tax Guardian, SIP Health — all running' })
        await fetchAll()
      }
    } catch {}
    setLoading(false)
  }

  const stopGuardian = async () => {
    await fetch('/api/guardian/stop', { method:'POST' })
    addAuditEntry({ agentName:'Guardian', step:'Guardian stopped by user', input:'', output:'', status:'done' })
    await fetchAll()
  }

  const runNow = async () => {
    setScanning(true)
    try {
      await fetch('/api/guardian/run-now', { method:'POST' })
      addAuditEntry({ agentName:'Guardian', step:'Manual scan triggered — all 4 agents running', input:'', output:'', status:'running' })
      // Wait 8s then refresh
      setTimeout(fetchAll, 8000)
      setTimeout(fetchAll, 15000)
    } catch {}
    setTimeout(() => setScanning(false), 8000)
  }

  const markAllRead = async () => {
    await fetch('/api/guardian/mark-read', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({id:'all'}) })
    setAlerts(prev => prev.map(a => ({...a, read:true})))
  }

  const clearAll = async () => {
    await fetch('/api/guardian/alerts', { method:'DELETE' })
    setAlerts([])
  }

  const requestNotif = async () => {
    const perm = await Notification.requestPermission()
    setNotifPerm(perm)
    if (perm === 'granted') {
      new Notification('🛡️ ET Alpha Guardian', { body:'Desktop notifications enabled! You\'ll be alerted even when the tab is in background.', icon:'/vite.svg' })
      addNotification({ type:'agent', title:'Desktop notifications enabled', body:'Guardian will alert you even when tab is in background' })
    }
  }

  const unread = alerts.filter(a => !a.read).length
  const byAgent: Record<GuardianAgentName, number> = {
    'Price Watch':   alerts.filter(a => a.agent === 'Price Watch').length,
    'News Sentinel': alerts.filter(a => a.agent === 'News Sentinel').length,
    'Tax Guardian':  alerts.filter(a => a.agent === 'Tax Guardian').length,
    'SIP Health':    alerts.filter(a => a.agent === 'SIP Health').length,
  }

  return (
    <div className="space-y-4 pb-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 bg-brand-500/10 rounded-xl flex items-center justify-center border border-brand-500/30">
          <Shield size={18} className="text-brand-400" />
        </div>
        <div>
          <h2 className="text-sm font-bold text-white">AUERON Guardian</h2>
          <p className="text-[11px] text-gray-400">Autonomous 24/7 portfolio monitor · 4 agents · Zero hardcoded data</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          {unread > 0 && (
            <span className="bg-neon-red text-white text-[10px] font-bold px-2 py-0.5 rounded-full animate-pulse">
              {unread} new
            </span>
          )}
          <div className={cn('flex items-center gap-1.5 text-[11px] px-3 py-1.5 rounded-full border font-medium',
            status.running ? 'bg-neon-green/10 border-neon-green/30 text-neon-green' : 'bg-surface-700 border-surface-500 text-gray-400')}>
            <div className={cn('w-1.5 h-1.5 rounded-full', status.running ? 'bg-neon-green animate-pulse' : 'bg-gray-500')} />
            {status.running ? 'Active' : 'Inactive'}
          </div>
        </div>
      </div>

      {/* Desktop notification banner */}
      {notifPerm !== 'granted' && (
        <motion.div initial={{opacity:0,y:-8}} animate={{opacity:1,y:0}}
          className="flex items-center gap-3 bg-brand-500/5 border border-brand-500/20 rounded-xl px-4 py-3">
          <Bell size={15} className="text-brand-400 flex-shrink-0" />
          <div className="flex-1">
            <p className="text-xs font-semibold text-white">Enable desktop notifications</p>
            <p className="text-[11px] text-gray-400">Get alerted like WhatsApp — even when this tab is in the background</p>
          </div>
          <button onClick={requestNotif}
            className="flex items-center gap-1.5 bg-brand-500 text-surface-900 text-xs font-bold px-4 py-2 rounded-lg hover:bg-brand-400 transition-colors flex-shrink-0">
            <Bell size={12} /> Enable Now
          </button>
        </motion.div>
      )}
      {notifPerm === 'granted' && (
        <div className="flex items-center gap-2 bg-neon-green/5 border border-neon-green/20 rounded-xl px-4 py-2">
          <Bell size={13} className="text-neon-green" />
          <p className="text-[11px] text-neon-green font-medium">Desktop notifications active — Guardian will alert you in the background</p>
        </div>
      )}

      {/* Agent status cards */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { name:'Price Watch', icon:TrendingDown, desc:'Monitors stock moves >2.5%', color:'text-neon-red' },
          { name:'News Sentinel', icon:Newspaper, desc:'Scans Google News for holdings', color:'text-blue-400' },
          { name:'Tax Guardian', icon:Receipt, desc:'Tracks P&L for harvest ops', color:'text-brand-400' },
          { name:'SIP Health', icon:Activity, desc:'Watches Nifty for SIP signals', color:'text-purple-400' },
        ].map((a, i) => (
          <motion.div key={a.name} initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} transition={{delay:i*0.06}}
            className="bg-surface-700 border border-surface-500/50 rounded-xl p-3">
            <div className="flex items-center gap-2 mb-2">
              <a.icon size={13} className={a.color} />
              <p className="text-[11px] font-semibold text-white">{a.name}</p>
            </div>
            <p className="text-[10px] text-gray-500 mb-2">{a.desc}</p>
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-gray-400">{byAgent[a.name as GuardianAgentName] || 0} alerts</span>
              <div className={cn('w-2 h-2 rounded-full', status.running ? 'bg-neon-green animate-pulse' : 'bg-gray-600')} />
            </div>
          </motion.div>
        ))}
      </div>

      {/* Controls */}
      <div className="flex items-center gap-3">
        {!status.running ? (
          <button onClick={startGuardian} disabled={loading}
            className="flex items-center gap-2 bg-brand-500 text-surface-900 font-bold px-5 py-2.5 rounded-xl hover:bg-brand-400 transition-colors text-sm disabled:opacity-50">
            {loading ? <Loader2 size={15} className="animate-spin" /> : <Play size={15} />}
            {loading ? 'Starting...' : 'Start Guardian'}
          </button>
        ) : (
          <button onClick={stopGuardian}
            className="flex items-center gap-2 bg-neon-red/10 border border-neon-red/20 text-neon-red px-5 py-2.5 rounded-xl hover:bg-neon-red/20 transition-colors text-sm font-semibold">
            <Square size={15} /> Stop Guardian
          </button>
        )}

        <button onClick={runNow} disabled={scanning}
          className="flex items-center gap-2 bg-surface-700 border border-surface-500 text-gray-300 hover:text-white px-4 py-2.5 rounded-xl transition-colors text-sm font-medium disabled:opacity-50">
          {scanning ? <Loader2 size={14} className="animate-spin text-brand-400" /> : <Zap size={14} className="text-brand-400" />}
          {scanning ? 'Scanning all 4 agents...' : 'Run Scan Now'}
        </button>

        {status.last_run && (
          <span className="text-[11px] text-gray-500">
            Last scan: {timeAgo(status.last_run)} · Run #{status.run_count}
          </span>
        )}

        {alerts.length > 0 && (
          <div className="ml-auto flex items-center gap-2">
            <button onClick={markAllRead} className="flex items-center gap-1.5 text-[11px] text-gray-400 hover:text-white px-3 py-1.5 bg-surface-700 border border-surface-500 rounded-lg transition-colors">
              <CheckCheck size={12} /> Mark all read
            </button>
            <button onClick={clearAll} className="flex items-center gap-1.5 text-[11px] text-gray-400 hover:text-neon-red px-3 py-1.5 bg-surface-700 border border-surface-500 rounded-lg transition-colors">
              <Trash2 size={12} /> Clear all
            </button>
          </div>
        )}
      </div>

      {/* Alert feed */}
      <div className="space-y-2">
        {alerts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-gray-500 bg-surface-700 border border-surface-500/30 rounded-xl">
            <Shield size={32} className="mb-3 opacity-30" />
            <p className="text-sm font-medium">No alerts yet</p>
            <p className="text-[11px] mt-1">Start Guardian and click "Run Scan Now" to see your first alerts</p>
          </div>
        ) : (
          <AnimatePresence>
            {alerts.map((alert, i) => {
              const Icon = TYPE_ICON[alert.type] || BrainCircuit
              return (
                <motion.div key={alert.id}
                  initial={{opacity:0,x:-8}} animate={{opacity:1,x:0}} exit={{opacity:0,x:8}}
                  transition={{delay:i*0.03}}
                  className={cn('border rounded-xl p-4 transition-all', SEV_COLOR[alert.severity] ?? SEV_COLOR.low, !alert.read && 'ring-1 ring-brand-500/20')}
                  onClick={async () => {
                    await fetch('/api/guardian/mark-read', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:alert.id})})
                    setAlerts(prev => prev.map(a => a.id===alert.id?{...a,read:true}:a))
                  }}>
                  <div className="flex items-start gap-3">
                    <div className={cn('w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 bg-surface-700')}>
                      <Icon size={14} className={alert.severity==='high'?'text-neon-red':alert.severity==='medium'?'text-brand-400':'text-neon-green'} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[10px] font-semibold text-gray-400">{alert.agent}</span>
                        <div className={cn('w-1.5 h-1.5 rounded-full flex-shrink-0', SEV_DOT[alert.severity])} />
                        <span className="text-[10px] text-gray-500">{timeAgo(alert.ts)}</span>
                        {!alert.read && <span className="text-[9px] bg-brand-500/20 text-brand-400 px-1.5 py-0.5 rounded font-bold ml-auto">NEW</span>}
                      </div>
                      <p className="text-sm font-semibold text-white leading-snug">{alert.title}</p>
                      <p className="text-[11px] text-gray-400 mt-1 leading-relaxed">{alert.body}</p>
                    </div>
                  </div>
                </motion.div>
              )
            })}
          </AnimatePresence>
        )}
      </div>
    </div>
  )
}
