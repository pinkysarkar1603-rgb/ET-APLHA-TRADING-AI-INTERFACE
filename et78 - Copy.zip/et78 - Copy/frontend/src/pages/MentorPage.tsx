import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  GraduationCap, Heart, Baby, Gift, Home, Car,
  FileText, Calculator, Users, Shield, TrendingUp,
  AlertCircle, CheckCircle2, ChevronRight, Sparkles
} from 'lucide-react'
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid
} from 'recharts'
import { cn, formatINR } from '@/lib/api'

const HEALTH_DIMS = [
  { label: 'Emergency fund',    val: 45, icon: Shield,     issue: 'Only 2 months of expenses covered. Target: 6 months.' },
  { label: 'Insurance',         val: 60, icon: Shield,     issue: 'Term cover adequate. Health cover: ₹5L — consider ₹15L+.' },
  { label: 'Diversification',   val: 68, icon: TrendingUp, issue: '2 large cap funds with 70% overlap detected.' },
  { label: 'Debt health',       val: 82, icon: CheckCircle2, issue: 'No high-interest debt. Good.' },
  { label: 'Tax efficiency',    val: 54, icon: Calculator,  issue: 'Missing ₹1.5L 80C + NPS ₹50K deduction.' },
  { label: 'Retirement ready',  val: 72, icon: Gift,        issue: 'On track but SIP needs ₹8K/mo increase.' },
]

const LIFE_EVENTS = [
  { id: 'bonus',     label: 'Got a Bonus',         icon: Gift,      color: 'text-neon-green' },
  { id: 'marriage',  label: 'Getting Married',     icon: Heart,     color: 'text-pink-400' },
  { id: 'baby',      label: 'Having a Baby',       icon: Baby,      color: 'text-blue-400' },
  { id: 'home',      label: 'Buying a Home',       icon: Home,      color: 'text-orange-400' },
  { id: 'car',       label: 'Buying a Car',        icon: Car,       color: 'text-purple-400' },
  { id: 'inherit',   label: 'Received Inheritance', icon: FileText,  color: 'text-brand-400' },
]

const LIFE_ADVICE: Record<string, string[]> = {
  bonus: [
    'Allocate 50% to top up emergency fund to 6 months.',
    'Put 30% into SIP top-up (avoid lump sum in a bull market — use STP over 6 months).',
    'Use 15% for 80C/NPS tax saving to maximise deduction.',
    'Keep 5% liquid for near-term goals.',
  ],
  marriage: [
    'Combine household budgets — split HRA claims optimally between spouses.',
    'Review life insurance: add spouse as nominee, double term cover.',
    'Open a joint emergency fund targeting ₹6L (6 months combined expenses).',
    'Start a joint SIP for a home down payment goal.',
    'Add spouse to NPS — both get separate ₹50K deduction.',
  ],
  baby: [
    'Start a Sukanya Samriddhi or children\'s fund SIP from day 1 (₹5K/mo for 18 years → ~₹45L).',
    'Increase term life cover to replace 15 years of income.',
    'Add child to health insurance rider — cheaper than new policy.',
    'Review will and nomination across all investments.',
  ],
  home: [
    'Ensure EMI stays below 40% of take-home pay.',
    'Keep minimum 20% down to avoid high LTV interest rates.',
    'Claim Section 24 interest deduction (up to ₹2L/yr) + 80EEA first-home benefit.',
    'Don\'t liquidate equity SIPs — maintain investment continuity.',
  ],
  car: [
    'Cars are depreciating assets — minimize loan tenure, max down payment.',
    'Avoid car loans above 3 years.',
    'Factor in true ownership cost: insurance ₹18-25K/yr, fuel ₹8K+/mo, maintenance.',
    'Opportunity cost: ₹8L car loan at 9% = ₹14L in 7 years if invested instead.',
  ],
  inherit: [
    'Don\'t rush — park in liquid fund for 90 days while you plan.',
    'Split: 60% equity (diversified SIPs), 20% debt, 10% gold, 10% liquid reserve.',
    'If amount > ₹50L, consult a SEBI-registered fee-only advisor.',
    'Check inheritance tax implications if received from outside India.',
  ],
}

const TAX_BREAKDOWN = [
  { regime: 'Old Regime', tax: 112400, deductions: 210000, effective: 14.1 },
  { regime: 'New Regime', tax: 82500,  deductions: 0,       effective: 10.3 },
]

const MISSING_DEDUCTIONS = [
  { section: '80C',    desc: 'ELSS / PPF / LIC',     limit: 150000, used: 120000, saving: 9360 },
  { section: '80D',    desc: 'Health insurance',      limit: 25000,  used: 0,      saving: 7800 },
  { section: '80CCD(1B)', desc: 'NPS additional',    limit: 50000,  used: 0,      saving: 15600 },
  { section: '24(b)',  desc: 'Home loan interest',    limit: 200000, used: 0,      saving: 62400 },
]

function HealthScoreCard() {
  const overall = Math.round(HEALTH_DIMS.reduce((s, d) => s + d.val, 0) / HEALTH_DIMS.length)
  const color = overall >= 75 ? '#00e676' : overall >= 55 ? '#ffc61a' : '#ff3d57'

  return (
    <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <p className="text-xs font-semibold text-gray-300">Money Health Score</p>
          <p className="text-[10px] text-gray-500">Across 6 financial dimensions</p>
        </div>
        <div className="text-right">
          <p className="text-3xl font-black font-mono" style={{ color }}>{overall}</p>
          <p className="text-xs font-medium" style={{ color }}>{overall >= 75 ? 'Good' : overall >= 55 ? 'Needs Work' : 'Poor'}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <ResponsiveContainer width="100%" height={160}>
          <RadarChart data={HEALTH_DIMS} margin={{ top: 0, right: 10, bottom: 0, left: 10 }}>
            <PolarGrid stroke="#243354" />
            <PolarAngleAxis dataKey="label" tick={{ fontSize: 8, fill: '#64748b' }} />
            <PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false} />
            <Radar dataKey="val" stroke={color} fill={color} fillOpacity={0.15} strokeWidth={1.5} />
          </RadarChart>
        </ResponsiveContainer>
        <div className="space-y-2 py-2">
          {HEALTH_DIMS.map(d => {
            const Icon = d.icon
            return (
              <div key={d.label} className="flex items-center gap-2">
                <div className="w-12 h-1.5 bg-surface-600 rounded-full overflow-hidden flex-shrink-0">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{ width: `${d.val}%`, background: d.val >= 70 ? '#00e676' : d.val >= 50 ? '#ffc61a' : '#ff3d57' }}
                  />
                </div>
                <span className="text-[9px] text-gray-500 truncate">{d.label}</span>
                <span className="text-[9px] font-mono text-gray-400 ml-auto">{d.val}</span>
              </div>
            )
          })}
        </div>
      </div>

      {/* Issues */}
      <div className="mt-4 space-y-1.5">
        {HEALTH_DIMS.filter(d => d.val < 70).map(d => (
          <div key={d.label} className="flex items-start gap-2 bg-surface-800/50 rounded-lg px-2.5 py-2">
            <AlertCircle size={11} className="text-orange-400 mt-0.5 flex-shrink-0" />
            <p className="text-[10px] text-gray-400">{d.issue}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

function TaxWizard() {
  const [salary, setSalary] = useState(800000)
  const missing = MISSING_DEDUCTIONS.filter(d => d.used < d.limit)
  const totalSaving = missing.reduce((s, d) => s + d.saving, 0)

  return (
    <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-5 space-y-4">
      <div className="flex items-center gap-2">
        <Calculator size={15} className="text-brand-400" />
        <p className="text-xs font-semibold text-gray-300">Tax Wizard</p>
        <span className="ml-auto text-[10px] bg-neon-green/10 border border-neon-green/20 text-neon-green px-2 py-0.5 rounded-full font-medium">
          Save ₹{totalSaving.toLocaleString('en-IN')} more
        </span>
      </div>

      <div>
        <div className="flex items-center justify-between mb-1.5">
          <label className="text-[11px] text-gray-400">Annual salary</label>
          <span className="text-[11px] font-mono text-brand-400">₹{salary.toLocaleString('en-IN')}</span>
        </div>
        <input type="range" min={300000} max={5000000} step={50000} value={salary}
          onChange={e => setSalary(Number(e.target.value))}
          className="w-full accent-brand-500" />
      </div>

      {/* Old vs New regime */}
      <div className="grid grid-cols-2 gap-3">
        {TAX_BREAKDOWN.map((t, i) => (
          <div key={t.regime} className={cn(
            'rounded-lg p-3 border',
            i === 1 ? 'border-neon-green/20 bg-neon-green/5' : 'border-surface-500/50 bg-surface-800/50'
          )}>
            <p className="text-[10px] text-gray-400 mb-1">{t.regime}</p>
            <p className={cn('text-lg font-black font-mono', i === 1 ? 'text-neon-green' : 'text-gray-300')}>
              ₹{t.tax.toLocaleString('en-IN')}
            </p>
            <p className="text-[10px] text-gray-500">{t.effective}% effective</p>
            {i === 1 && <p className="text-[10px] text-neon-green mt-1 font-medium">Recommended ✓</p>}
          </div>
        ))}
      </div>

      {/* Missing deductions */}
      <div className="space-y-2">
        <p className="text-[10px] text-gray-500 font-medium uppercase tracking-wider">Missing deductions</p>
        {missing.map(d => (
          <div key={d.section} className="flex items-center justify-between bg-surface-800/50 rounded-lg px-3 py-2">
            <div>
              <span className="text-[10px] font-bold text-brand-400 mr-2">{d.section}</span>
              <span className="text-[10px] text-gray-400">{d.desc}</span>
            </div>
            <div className="text-right">
              <p className="text-[10px] font-mono text-neon-green font-semibold">
                Save ₹{d.saving.toLocaleString('en-IN')}
              </p>
              <p className="text-[9px] text-gray-600">
                Used {Math.round(d.used / d.limit * 100)}% of ₹{(d.limit / 1000)}K limit
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function LifeEventAdvisor() {
  const [selected, setSelected] = useState<string | null>(null)

  return (
    <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-5 space-y-4">
      <div className="flex items-center gap-2">
        <Sparkles size={15} className="text-purple-400" />
        <p className="text-xs font-semibold text-gray-300">Life Event Advisor</p>
      </div>
      <p className="text-[11px] text-gray-400">What's happening in your life? Get personalised financial guidance.</p>

      <div className="grid grid-cols-3 gap-2">
        {LIFE_EVENTS.map(ev => {
          const Icon = ev.icon
          return (
            <button
              key={ev.id}
              onClick={() => setSelected(s => s === ev.id ? null : ev.id)}
              className={cn(
                'flex flex-col items-center gap-1.5 p-3 rounded-xl border text-center transition-all',
                selected === ev.id
                  ? 'bg-brand-500/10 border-brand-500/30'
                  : 'bg-surface-800/50 border-surface-500/40 hover:border-surface-400'
              )}
            >
              <Icon size={18} className={selected === ev.id ? 'text-brand-400' : ev.color} />
              <span className="text-[10px] text-gray-300 leading-tight">{ev.label}</span>
            </button>
          )
        })}
      </div>

      <AnimatePresence mode="wait">
        {selected && LIFE_ADVICE[selected] && (
          <motion.div
            key={selected}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="bg-brand-500/5 border border-brand-500/20 rounded-xl p-4 space-y-2"
          >
            <div className="flex items-center gap-2 mb-2">
              <Sparkles size={12} className="text-brand-400" />
              <p className="text-xs font-semibold text-brand-400">AI-personalised advice</p>
            </div>
            {LIFE_ADVICE[selected].map((tip, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.08 }}
                className="flex items-start gap-2"
              >
                <ChevronRight size={12} className="text-brand-400 mt-0.5 flex-shrink-0" />
                <p className="text-[11px] text-gray-300 leading-relaxed">{tip}</p>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

const MENTOR_TABS = ['Health Score', 'Tax Wizard', 'Life Events'] as const
type MTab = typeof MENTOR_TABS[number]

export default function MentorPage() {
  const [tab, setTab] = useState<MTab>('Health Score')

  return (
    <div className="space-y-4 pb-4">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 bg-purple-500/10 rounded-lg flex items-center justify-center">
          <GraduationCap size={16} className="text-purple-400" />
        </div>
        <div>
          <h2 className="text-sm font-bold text-white">AI Money Mentor</h2>
          <p className="text-[11px] text-gray-400">Financial planning intelligence — personalised to your situation</p>
        </div>
      </div>

      <div className="flex gap-2">
        {MENTOR_TABS.map(t => (
          <button key={t} onClick={() => setTab(t)} className={cn(
            'px-4 py-2 rounded-lg text-xs font-semibold border transition-all',
            tab === t ? 'bg-brand-500/10 border-brand-500/30 text-brand-400' : 'bg-surface-700 border-surface-500 text-gray-400 hover:text-white'
          )}>{t}</button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={tab}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.15 }}
        >
          {tab === 'Health Score' && <HealthScoreCard />}
          {tab === 'Tax Wizard'   && <TaxWizard />}
          {tab === 'Life Events'  && <LifeEventAdvisor />}
        </motion.div>
      </AnimatePresence>
    </div>
  )
}
