import { useState, useMemo } from 'react'
import { motion } from 'framer-motion'
import { Target, TrendingUp, Calendar, IndianRupee, Flame, CheckCircle, Circle } from 'lucide-react'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, ReferenceLine
} from 'recharts'
import { cn, formatINR } from '@/lib/api'

function calcFire(
  currentAge: number,
  retireAge: number,
  monthlyExpenses: number,
  currentCorpus: number,
  monthlyInvestment: number,
  expectedReturn: number,
  inflation: number
) {
  const years = retireAge - currentAge
  const realReturn = (1 + expectedReturn / 100) / (1 + inflation / 100) - 1
  // Corpus needed: 25x annual expenses (4% SWR), inflation-adjusted
  const futureExpenses = monthlyExpenses * 12 * Math.pow(1 + inflation / 100, years)
  const targetCorpus = futureExpenses * 25

  // Project corpus year by year
  const milestones = []
  let corpus = currentCorpus
  const monthlyRate = expectedReturn / 100 / 12
  for (let y = 0; y <= years; y++) {
    milestones.push({ year: currentAge + y, corpus: Math.round(corpus), target: targetCorpus, age: currentAge + y })
    for (let m = 0; m < 12; m++) {
      corpus = corpus * (1 + monthlyRate) + monthlyInvestment
    }
  }

  // Monthly SIP needed to reach target
  // FV = PV*(1+r)^n + PMT*[((1+r)^n - 1)/r]
  const n = years * 12
  const r = monthlyRate
  const fvExisting = currentCorpus * Math.pow(1 + r, n)
  const remaining = Math.max(0, targetCorpus - fvExisting)
  const monthlyNeeded = remaining > 0
    ? remaining * r / (Math.pow(1 + r, n) - 1)
    : 0

  return { targetCorpus, milestones, monthlyNeeded: Math.round(monthlyNeeded), years }
}

const SIP_RECS = [
  { fundName: 'Parag Parikh Flexi Cap',  amount: 0.35, category: 'Flexi Cap',  rationale: 'Low overlap, global diversification, 18.4% 5Y XIRR' },
  { fundName: 'SBI Small Cap Fund',      amount: 0.20, category: 'Small Cap',  rationale: 'High growth potential for long FIRE horizons, 22% 5Y' },
  { fundName: 'HDFC Nifty 50 Index',     amount: 0.25, category: 'Index',      rationale: 'Low cost (0.2% TER), market returns guaranteed' },
  { fundName: 'Nippon India Gilt Fund',  amount: 0.10, category: 'Debt',       rationale: 'Stability buffer as target approaches' },
  { fundName: 'Sovereign Gold Bond',     amount: 0.10, category: 'Gold',       rationale: 'Inflation hedge, tax-free on maturity' },
]

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null
  return (
    <div className="bg-surface-700 border border-surface-500 rounded-lg p-2.5 text-xs">
      <p className="text-gray-400 mb-1">Age {label}</p>
      <p className="text-brand-400 font-mono">Corpus: {formatINR(payload[0]?.value, true)}</p>
      <p className="text-gray-500 font-mono">Target: {formatINR(payload[1]?.value, true)}</p>
    </div>
  )
}

export default function PlannerPage() {
  const [age, setAge] = useState(28)
  const [retireAge, setRetireAge] = useState(45)
  const [expenses, setExpenses] = useState(80000)
  const [corpus, setCorpus] = useState(1200000)
  const [sip, setSip] = useState(50000)
  const [returns, setReturns] = useState(12)
  const [inflation, setInflation] = useState(6)

  const plan = useMemo(() =>
    calcFire(age, retireAge, expenses, corpus, sip, returns, inflation),
    [age, retireAge, expenses, corpus, sip, returns, inflation]
  )

  const shortfall = plan.monthlyNeeded - sip
  const onTrack = shortfall <= 0

  const milestones = [
    { label: '25% of target', pct: 25 },
    { label: '50% of target', pct: 50 },
    { label: '75% of target', pct: 75 },
    { label: 'FIRE achieved!', pct: 100 },
  ].map(m => {
    const goal = plan.targetCorpus * m.pct / 100
    const hit = plan.milestones.find(ms => ms.corpus >= goal)
    return { ...m, age: hit?.age ?? null }
  })

  return (
    <div className="space-y-4 pb-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 bg-brand-500/10 rounded-lg flex items-center justify-center">
          <Flame size={16} className="text-brand-400" />
        </div>
        <div>
          <h2 className="text-sm font-bold text-white">FIRE Path Planner</h2>
          <p className="text-[11px] text-gray-400">Financial Independence, Retire Early — your month-by-month roadmap</p>
        </div>
        <div className={cn(
          'ml-auto px-3 py-1.5 rounded-lg text-xs font-bold border',
          onTrack ? 'bg-neon-green/10 border-neon-green/20 text-neon-green' : 'bg-orange-500/10 border-orange-500/20 text-orange-400'
        )}>
          {onTrack ? '✓ On Track' : `↑ Need ₹${Math.abs(shortfall).toLocaleString('en-IN')}/mo more`}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {/* Left: Inputs */}
        <div className="space-y-4">
          <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-4 space-y-4">
            <p className="text-xs font-semibold text-gray-300">Your numbers</p>

            {[
              { label: 'Current age',           val: age,        set: setAge,        min: 18, max: 55, unit: 'yrs' },
              { label: 'Target retire age',     val: retireAge,  set: setRetireAge,  min: age+1, max: 65, unit: 'yrs' },
              { label: 'Monthly expenses',      val: expenses,   set: setExpenses,   min: 10000, max: 500000, step: 5000, unit: '₹' },
              { label: 'Current corpus',        val: corpus,     set: setCorpus,     min: 0, max: 50000000, step: 100000, unit: '₹' },
              { label: 'Current monthly SIP',   val: sip,        set: setSip,        min: 1000, max: 500000, step: 1000, unit: '₹' },
              { label: 'Expected return',       val: returns,    set: setReturns,    min: 6, max: 20, unit: '%' },
              { label: 'Inflation rate',        val: inflation,  set: setInflation,  min: 3, max: 12, unit: '%' },
            ].map(({ label, val, set, min, max, step = 1, unit }) => (
              <div key={label}>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-[11px] text-gray-400">{label}</label>
                  <span className="text-[11px] font-mono text-brand-400 font-medium">
                    {unit === '₹' ? `₹${val.toLocaleString('en-IN')}` : `${val}${unit}`}
                  </span>
                </div>
                <input
                  type="range"
                  min={min} max={max} step={step}
                  value={val}
                  onChange={e => set(Number(e.target.value))}
                  className="w-full h-1.5 bg-surface-600 rounded-full appearance-none cursor-pointer accent-brand-500"
                />
              </div>
            ))}
          </div>

          {/* Key numbers */}
          <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-4 space-y-3">
            <p className="text-xs font-semibold text-gray-300">Target summary</p>
            {[
              { label: 'FIRE corpus needed',  val: formatINR(plan.targetCorpus, true),       color: 'text-white' },
              { label: 'Years to FIRE',        val: `${plan.years} years`,                    color: 'text-brand-400' },
              { label: 'Monthly SIP required', val: `₹${plan.monthlyNeeded.toLocaleString('en-IN')}`, color: onTrack ? 'text-neon-green' : 'text-orange-400' },
              { label: 'Monthly expenses today', val: `₹${expenses.toLocaleString('en-IN')}`, color: 'text-gray-300' },
              { label: 'Inflation-adj. at retire', val: `₹${Math.round(expenses * Math.pow(1 + inflation / 100, plan.years)).toLocaleString('en-IN')}/mo`, color: 'text-gray-300' },
            ].map(r => (
              <div key={r.label} className="flex items-start justify-between gap-2">
                <span className="text-[11px] text-gray-500 leading-relaxed">{r.label}</span>
                <span className={cn('text-[11px] font-mono font-semibold text-right', r.color)}>{r.val}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Center: Chart */}
        <div className="col-span-2 space-y-4">
          {/* Corpus growth chart */}
          <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-4">
            <p className="text-xs font-semibold text-gray-300 mb-4">Corpus growth projection</p>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={plan.milestones} margin={{ top: 4, right: 8, bottom: 0, left: 0 }}>
                <defs>
                  <linearGradient id="corpusGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#ffc61a" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#ffc61a" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="targetGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#ff3d57" stopOpacity={0.1} />
                    <stop offset="95%" stopColor="#ff3d57" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1a2640" />
                <XAxis dataKey="age" tick={{ fontSize: 9, fill: '#64748b' }} axisLine={false} tickLine={false} label={{ value: 'Age', position: 'insideBottom', offset: -2, fontSize: 9, fill: '#64748b' }} />
                <YAxis tick={{ fontSize: 9, fill: '#64748b' }} axisLine={false} tickLine={false} tickFormatter={v => `₹${(v/1e7).toFixed(1)}Cr`} width={52} />
                <Tooltip content={<CustomTooltip />} />
                <ReferenceLine y={plan.targetCorpus} stroke="#ff3d57" strokeDasharray="4 4" strokeWidth={1} label={{ value: 'FIRE target', position: 'insideTopLeft', fontSize: 9, fill: '#ff3d57' }} />
                <Area type="monotone" dataKey="corpus" stroke="#ffc61a" strokeWidth={2} fill="url(#corpusGrad)" dot={false} name="Projected corpus" />
                <Area type="monotone" dataKey="target" stroke="#ff3d57" strokeWidth={1} strokeDasharray="4 4" fill="url(#targetGrad)" dot={false} name="Target" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Milestones */}
          <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-4">
            <p className="text-xs font-semibold text-gray-300 mb-3">Journey milestones</p>
            <div className="flex items-start gap-0">
              {milestones.map((m, i) => (
                <div key={m.label} className="flex-1 relative">
                  {/* connector */}
                  {i < milestones.length - 1 && (
                    <div className={cn(
                      'absolute top-3 left-1/2 right-0 h-0.5',
                      m.age ? 'bg-brand-500/60' : 'bg-surface-500/40'
                    )} />
                  )}
                  <div className="flex flex-col items-center text-center px-1">
                    <div className={cn(
                      'w-6 h-6 rounded-full border-2 flex items-center justify-center z-10 bg-surface-700',
                      m.age ? 'border-brand-500' : 'border-surface-500'
                    )}>
                      {m.age
                        ? <CheckCircle size={12} className="text-brand-400" />
                        : <Circle size={10} className="text-gray-600" />
                      }
                    </div>
                    <p className="text-[10px] font-semibold text-gray-300 mt-1.5">{m.label}</p>
                    <p className={cn('text-[10px] font-mono mt-0.5', m.age ? 'text-brand-400' : 'text-gray-600')}>
                      {m.age ? `Age ${m.age}` : '—'}
                    </p>
                    <p className="text-[9px] text-gray-600">{m.pct}% complete</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* SIP recommendations */}
          <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <p className="text-xs font-semibold text-gray-300">Recommended SIP allocation</p>
              <span className="text-[11px] font-mono text-brand-400">
                Total: ₹{plan.monthlyNeeded.toLocaleString('en-IN')}/mo
              </span>
            </div>
            <div className="space-y-2">
              {SIP_RECS.map((r, i) => (
                <motion.div
                  key={r.fundName}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.06 }}
                  className="flex items-center gap-3 bg-surface-800/50 rounded-lg p-2.5"
                >
                  <div className="w-1.5 h-8 rounded-full bg-brand-500/60 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] font-semibold text-gray-200">{r.fundName}</p>
                    <p className="text-[10px] text-gray-500">{r.rationale}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-xs font-mono font-bold text-brand-400">
                      ₹{Math.round(plan.monthlyNeeded * r.amount).toLocaleString('en-IN')}
                    </p>
                    <p className="text-[10px] text-gray-500">{Math.round(r.amount * 100)}%</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
