import { useState, useRef } from 'react'
import { motion } from 'framer-motion'
import {
  ExternalLink, RefreshCw, ChevronLeft, ChevronRight,
  Globe, Zap, TrendingUp, BarChart2, AlertTriangle, Maximize2
} from 'lucide-react'
import { useStore } from '@/store'
import { groqChat, formatINR, cn } from '@/lib/api'
import { fetchLiveQuote } from '@/lib/marketData'

const BROKERS = [
  { name: 'Sharekhan', url: 'https://www.sharekhan.com',         color: 'text-orange-400' },
  { name: 'Zerodha',   url: 'https://kite.zerodha.com',          color: 'text-blue-400'   },
  { name: 'Groww',     url: 'https://groww.in',                  color: 'text-neon-green' },
  { name: 'Angel One', url: 'https://www.angelone.in',           color: 'text-red-400'    },
  { name: 'Upstox',    url: 'https://upstox.com',                color: 'text-purple-400' },
  { name: 'NSE India', url: 'https://www.nseindia.com',          color: 'text-brand-400'  },
  { name: 'Screener',  url: 'https://www.screener.in',           color: 'text-teal-400'   },
  { name: 'TradingView','url': 'https://www.tradingview.com/chart/?symbol=NSE:RELIANCE', color: 'text-blue-400' },
]

function StockAnalysisCard({ ticker, onClose }: { ticker: string; onClose: () => void }) {
  const [analysis, setAnalysis] = useState('')
  const [quote, setQuote]       = useState<any>(null)
  const [loading, setLoading]   = useState(true)

  useState(() => {
    (async () => {
      const q = await fetchLiveQuote(`${ticker}.NS`)
      setQuote(q)
      const text = await groqChat(
        'You are ET Alpha, an elite NSE market analyst. Be specific, cite real numbers. Under 120 words.',
        `Analyse ${ticker} right now: price ₹${q?.price ?? 'N/A'}, change ${q?.chgPct ?? 0}% today. Give: 1) What this move means 2) Key risk 3) One action. Use **bold** for key numbers.`
      )
      setAnalysis(text)
      setLoading(false)
    })()
  })

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-surface-700 border border-brand-500/30 rounded-xl p-4 space-y-3"
    >
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-black text-white">{ticker}</p>
          {quote && (
            <div className="flex items-center gap-2 mt-0.5">
              <span className="text-lg font-mono font-bold text-white">₹{quote.price.toFixed(2)}</span>
              <span className={cn('text-xs font-mono font-semibold', quote.chgPct >= 0 ? 'text-neon-green' : 'text-neon-red')}>
                {quote.chgPct >= 0 ? '+' : ''}{quote.chgPct}%
              </span>
            </div>
          )}
        </div>
        <button onClick={onClose} className="text-gray-500 hover:text-white text-xs px-2 py-1 bg-surface-600 rounded">✕</button>
      </div>

      {loading ? (
        <div className="flex items-center gap-2 text-xs text-gray-500">
          <RefreshCw size={11} className="animate-spin" /> Groq analysing...
        </div>
      ) : (
        <p className="text-[11px] text-gray-300 leading-relaxed"
          dangerouslySetInnerHTML={{ __html: analysis.replace(/\*\*(.*?)\*\*/g, '<strong class="text-white">$1</strong>').replace(/\n/g, '<br/>') }}
        />
      )}

      {quote && (
        <div className="grid grid-cols-3 gap-2">
          {[
            { l: 'High',   v: `₹${quote.high.toFixed(0)}`   },
            { l: 'Low',    v: `₹${quote.low.toFixed(0)}`    },
            { l: 'Volume', v: `${(quote.volume/1e5).toFixed(1)}L` },
          ].map(s => (
            <div key={s.l} className="bg-surface-600/50 rounded-lg p-2 text-center">
              <p className="text-[9px] text-gray-500">{s.l}</p>
              <p className="text-[11px] font-mono font-bold text-gray-200">{s.v}</p>
            </div>
          ))}
        </div>
      )}
    </motion.div>
  )
}

export default function SidekickPage() {
  const { sidekickUrl, setSidekickUrl } = useStore()
  const [selectedBroker, setSelectedBroker] = useState(BROKERS[0])
  const [searchTicker, setSearchTicker]     = useState('')
  const [analysedTicker, setAnalysedTicker] = useState<string | null>(null)
  const [leftWidth, setLeftWidth]           = useState(60)
  const iframeRef = useRef<HTMLIFrameElement>(null)

  const launch = (broker: typeof BROKERS[0]) => {
    setSelectedBroker(broker)
    setSidekickUrl(broker.url)
  }

  const analyse = () => {
    const t = searchTicker.trim().toUpperCase()
    if (t) { setAnalysedTicker(t); setSearchTicker('') }
  }

  const openInNewTab = () => window.open(sidekickUrl, '_blank', 'width=1200,height=800')

  return (
    <div className="h-full flex flex-col gap-3">
      {/* Header */}
      <div className="flex items-center gap-3 flex-shrink-0">
        <div className="w-8 h-8 bg-brand-500/10 rounded-lg flex items-center justify-center border border-brand-500/20">
          <Globe size={16} className="text-brand-400" />
        </div>
        <div>
          <h2 className="text-sm font-bold text-white">Sidekick Mode</h2>
          <p className="text-[11px] text-gray-400">Your broker + ET Alpha intelligence, side by side</p>
        </div>
        <button
          onClick={openInNewTab}
          className="ml-auto flex items-center gap-1.5 text-xs bg-brand-500/10 border border-brand-500/20 text-brand-400 px-3 py-1.5 rounded-lg hover:bg-brand-500/20 transition-colors"
        >
          <ExternalLink size={12} /> Open Broker in New Window
        </button>
      </div>

      {/* Broker selector */}
      <div className="flex items-center gap-2 flex-wrap flex-shrink-0">
        {BROKERS.map(b => (
          <button
            key={b.name}
            onClick={() => launch(b)}
            className={cn(
              'text-[11px] px-3 py-1.5 rounded-lg border transition-all font-medium',
              selectedBroker.name === b.name
                ? 'bg-brand-500/10 border-brand-500/30 text-brand-400'
                : 'bg-surface-700 border-surface-500 text-gray-400 hover:text-white'
            )}
          >
            {b.name}
          </button>
        ))}
      </div>

      {/* Main split layout */}
      <div className="flex-1 flex gap-3 min-h-0">
        {/* Left: broker iframe */}
        <div className="flex-1 min-w-0 flex flex-col gap-2">
          <div className="flex items-center gap-2 bg-surface-700 border border-surface-500/50 rounded-lg px-3 py-1.5">
            <Globe size={11} className="text-gray-500" />
            <span className="text-[11px] text-gray-400 truncate flex-1">{sidekickUrl}</span>
            <button onClick={() => iframeRef.current && (iframeRef.current.src = sidekickUrl)} className="text-gray-500 hover:text-white">
              <RefreshCw size={11} />
            </button>
          </div>

          <div className="flex-1 bg-surface-700 border border-surface-500/50 rounded-xl overflow-hidden relative">
            {/* Note: Most broker sites block iframes with X-Frame-Options */}
            {/* We show the site in a new window and connect via postMessage */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-8 bg-surface-800">
              <Globe size={40} className="text-brand-400/40 mb-4" />
              <p className="text-sm font-semibold text-white mb-2">{selectedBroker.name} — Sidekick Ready</p>
              <p className="text-xs text-gray-400 mb-6 leading-relaxed max-w-xs">
                Broker sites block direct embedding for security. Click below to open {selectedBroker.name} in a side window — ET Alpha will automatically detect stocks you view.
              </p>
              <button
                onClick={openInNewTab}
                className="flex items-center gap-2 bg-brand-500 text-surface-900 font-bold px-6 py-3 rounded-xl hover:bg-brand-400 transition-colors text-sm"
              >
                <ExternalLink size={16} />
                Launch {selectedBroker.name} Sidekick
              </button>
              <p className="text-[10px] text-gray-600 mt-4">Opens {selectedBroker.name} in a companion window · ET Alpha stays here</p>
            </div>
          </div>
        </div>

        {/* Right: ET Alpha intelligence panel */}
        <div className="w-72 flex-shrink-0 flex flex-col gap-3 overflow-y-auto">
          {/* Search any stock */}
          <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-3">
            <p className="text-[10px] text-gray-500 uppercase tracking-wider mb-2">Instant stock analysis</p>
            <div className="flex gap-2">
              <input
                value={searchTicker}
                onChange={e => setSearchTicker(e.target.value.toUpperCase())}
                onKeyDown={e => e.key === 'Enter' && analyse()}
                placeholder="RELIANCE, TCS..."
                className="flex-1 bg-surface-600 border border-surface-500 text-xs text-white px-2.5 py-2 rounded-lg outline-none focus:border-brand-500/50"
              />
              <button
                onClick={analyse}
                disabled={!searchTicker.trim()}
                className="bg-brand-500 text-surface-900 font-bold px-3 py-2 rounded-lg text-xs hover:bg-brand-400 transition-colors disabled:opacity-40"
              >
                <Zap size={12} />
              </button>
            </div>
          </div>

          {/* Analysed stock card */}
          {analysedTicker && (
            <StockAnalysisCard
              ticker={analysedTicker}
              onClose={() => setAnalysedTicker(null)}
            />
          )}

          {/* Quick analyse popular stocks */}
          <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-3">
            <p className="text-[10px] text-gray-500 uppercase tracking-wider mb-2">Quick analyse</p>
            <div className="flex flex-wrap gap-1.5">
              {['RELIANCE','TCS','INFY','HDFCBANK','TATAMOT','ZOMATO','BAJFINANCE','WIPRO'].map(t => (
                <button
                  key={t}
                  onClick={() => setAnalysedTicker(t)}
                  className="text-[10px] bg-surface-600 border border-surface-500 text-gray-300 hover:text-white hover:border-brand-500/30 px-2 py-1 rounded transition-all"
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Live market pulse */}
          <div className="bg-surface-700 border border-surface-500/50 rounded-xl p-3">
            <p className="text-[10px] text-gray-500 uppercase tracking-wider mb-2">How to use sidekick</p>
            <div className="space-y-2">
              {[
                { n: '1', text: 'Click "Launch Broker Sidekick" above' },
                { n: '2', text: 'Browse stocks on your broker as usual' },
                { n: '3', text: 'Type any ticker here for instant AI analysis' },
                { n: '4', text: 'ET Alpha reads signals alongside your trades' },
              ].map(s => (
                <div key={s.n} className="flex items-start gap-2">
                  <span className="w-4 h-4 bg-brand-500/20 text-brand-400 text-[9px] font-black rounded flex items-center justify-center flex-shrink-0 mt-0.5">{s.n}</span>
                  <p className="text-[10px] text-gray-400 leading-relaxed">{s.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
