/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // ET Alpha brand — deep navy + electric amber
        brand: {
          50:  '#fff8e6',
          100: '#ffedb3',
          200: '#ffe080',
          300: '#ffd44d',
          400: '#ffc61a',
          500: '#e6ad00',  // primary amber
          600: '#b38600',
          700: '#805f00',
          800: '#4d3900',
          900: '#1a1300',
        },
        surface: {
          900: '#0a0d14',   // deepest bg
          800: '#0f1520',   // sidebar
          700: '#141d2e',   // cards
          600: '#1a2640',   // elevated cards
          500: '#243354',   // borders
          400: '#2e4068',   // hover borders
        },
        neon: {
          green:  '#00e676',
          red:    '#ff3d57',
          amber:  '#ffc61a',
          blue:   '#4fc3f7',
          purple: '#b388ff',
        },
      },
      fontFamily: {
        sans: ['Inter var', 'Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
        display: ['Cal Sans', 'Inter var', 'sans-serif'],
      },
      backgroundImage: {
        'grid-surface': "url(\"data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23243354' fill-opacity='0.4'%3E%3Cpath d='M0 40L40 0H20L0 20M40 40V20L20 40'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")",
        'scanline': "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,230,118,0.01) 2px, rgba(0,230,118,0.01) 4px)",
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'ticker': 'ticker 20s linear infinite',
        'fade-in': 'fadeIn 0.4s ease-out',
        'slide-up': 'slideUp 0.3s ease-out',
        'glow': 'glow 2s ease-in-out infinite alternate',
        'spin-slow': 'spin 8s linear infinite',
        'bounce-x': 'bounceX 1s ease-in-out infinite',
      },
      keyframes: {
        ticker: {
          '0%': { transform: 'translateX(0)' },
          '100%': { transform: 'translateX(-50%)' },
        },
        fadeIn: {
          '0%': { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(16px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        glow: {
          '0%': { boxShadow: '0 0 4px rgba(255,198,26,0.3)' },
          '100%': { boxShadow: '0 0 20px rgba(255,198,26,0.6), 0 0 40px rgba(255,198,26,0.2)' },
        },
        bounceX: {
          '0%, 100%': { transform: 'translateX(-4px)' },
          '50%': { transform: 'translateX(4px)' },
        },
      },
      boxShadow: {
        'glow-amber': '0 0 20px rgba(255,198,26,0.4)',
        'glow-green': '0 0 20px rgba(0,230,118,0.4)',
        'glow-red':   '0 0 20px rgba(255,61,87,0.4)',
        'card': '0 4px 24px rgba(0,0,0,0.4)',
        'panel': '0 2px 12px rgba(0,0,0,0.6)',
      },
      borderRadius: {
        'xl2': '16px',
        'xl3': '20px',
      },
    },
  },
  plugins: [],
}
