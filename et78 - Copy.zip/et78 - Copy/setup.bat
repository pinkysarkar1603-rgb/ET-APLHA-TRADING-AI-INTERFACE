@echo off
echo =============================================
echo  ET Alpha - Setup Script
echo =============================================
echo.

echo [1/4] Installing frontend dependencies...
cd frontend
call npm install
cd ..

echo.
echo [2/4] Installing backend dependencies...
cd backend
pip install -r requirements.txt
echo.

echo [3/4] Installing Playwright browser...
playwright install chromium
cd ..

echo.
echo [4/4] Setup complete!
echo.
echo =============================================
echo  HOW TO RUN:
echo =============================================
echo.
echo  Terminal 1 - Frontend:
echo    cd frontend
echo    npm run dev
echo    Open: http://localhost:5173
echo.
echo  Terminal 2 - Backend (optional for full features):
echo    cd backend
echo    uvicorn api.main:app --reload --port 8000
echo.
echo  Terminal 3 - Import your real holdings (optional):
echo    python backend/tools/browser_agent.py zerodha
echo    (or: sharekhan / groww / angel)
echo.
pause
