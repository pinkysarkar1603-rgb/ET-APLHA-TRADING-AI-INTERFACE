"""
AUERON Guardian — Autonomous Portfolio Guardian Agent
4 sub-agents running in a background loop every 5 minutes.
Zero hardcoded data. Everything live.
"""
from fastapi import APIRouter
import asyncio, json, os, time, requests, threading
from groq import Groq

router     = APIRouter()
GROQ_KEY   = os.getenv("GROQ_API_KEY", "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")
groq_client = Groq(api_key=GROQ_KEY)

ALERTS_FILE = os.path.join(os.path.dirname(__file__), "..", "..", "guardian_alerts.json")

# ─── Portfolio config (mirrors frontend defaults) ─────────────────────────────
PORTFOLIO_TICKERS = [
    {"ticker":"RELIANCE",  "yfSym":"RELIANCE.NS",   "qty":45,  "avgCost":1880},
    {"ticker":"INFY",      "yfSym":"INFY.NS",        "qty":120, "avgCost":1420},
    {"ticker":"HDFCBANK",  "yfSym":"HDFCBANK.NS",    "qty":200, "avgCost":1510},
    {"ticker":"TATAMOT",   "yfSym":"TATAMOTORS.NS",  "qty":300, "avgCost":610},
    {"ticker":"ZOMATO",    "yfSym":"ZOMATO.NS",      "qty":800, "avgCost":142},
]
NIFTY_SYM = "^NSEI"

def load_alerts():
    try:
        with open(ALERTS_FILE) as f: return json.load(f)
    except: return []

def save_alert(alert: dict):
    alerts = load_alerts()
    alerts.insert(0, alert)
    alerts = alerts[:100]  # keep last 100
    with open(ALERTS_FILE, "w") as f: json.dump(alerts, f)

def fetch_price(sym: str) -> dict | None:
    try:
        r = requests.get(
            f"https://query1.finance.yahoo.com/v8/finance/chart/{sym}?interval=1d&range=2d",
            headers={"User-Agent": "Mozilla/5.0"}, timeout=6)
        meta  = r.json()["chart"]["result"][0]["meta"]
        price = meta["regularMarketPrice"]
        prev  = meta.get("previousClose", price)
        return {"price": price, "prev": prev, "chgPct": round((price-prev)/prev*100,2) if prev else 0,
                "volume": meta.get("regularMarketVolume",0)}
    except: return None

def groq_chat(system: str, user: str, max_tokens=200) -> str:
    try:
        r = groq_client.chat.completions.create(
            model="llama-3.3-70b-versatile", max_tokens=max_tokens, temperature=0.3,
            messages=[{"role":"system","content":system},{"role":"user","content":user}])
        return r.choices[0].message.content
    except: return ""

# ─── Agent 1: Price Watch ─────────────────────────────────────────────────────
def run_price_watch():
    moved = []
    for t in PORTFOLIO_TICKERS:
        q = fetch_price(t["yfSym"])
        if not q: continue
        if abs(q["chgPct"]) >= 2.5:
            moved.append({"ticker": t["ticker"], "price": q["price"], "chgPct": q["chgPct"], "qty": t["qty"]})

    if not moved: return
    summary = ", ".join([f"{m['ticker']} {m['chgPct']:+.1f}%" for m in moved])
    analysis = groq_chat(
        "You are an NSE market analyst. Be specific and brief.",
        f"These stocks moved significantly today: {summary}. In 2 sentences explain likely cause and if investor should act."
    )
    for m in moved:
        direction = "📈" if m["chgPct"] > 0 else "📉"
        save_alert({
            "id": f"pw-{int(time.time()*1000)}-{m['ticker']}",
            "agent": "Price Watch",
            "type": "price_move",
            "severity": "high" if abs(m["chgPct"]) > 4 else "medium",
            "title": f"{direction} {m['ticker']} moved {m['chgPct']:+.1f}% — ₹{m['price']:.2f}",
            "body": analysis or f"{m['ticker']} has moved significantly. Review your position ({m['qty']} shares).",
            "ts": time.time(), "read": False
        })

# ─── Agent 2: News Sentinel ───────────────────────────────────────────────────
def run_news_sentinel():
    companies = [t["ticker"] for t in PORTFOLIO_TICKERS]
    for company in companies[:3]:  # limit to avoid rate limits
        try:
            r = requests.get(
                f"https://news.google.com/rss/search?q={company}+NSE+stock&hl=en-IN&gl=IN&ceid=IN:en",
                headers={"User-Agent":"Mozilla/5.0"}, timeout=8)
            import re
            titles = re.findall(r'<title>(.*?)</title>', r.text)[2:6]  # skip feed title
            if not titles: continue
            headlines = "\n".join(titles)
            sentiment = groq_chat(
                "You are a financial news analyst. Reply with ONLY: POSITIVE, NEGATIVE, or NEUTRAL, then one sentence.",
                f"News about {company} stock:\n{headlines}\nSentiment?"
            )
            if not sentiment: continue
            is_negative = sentiment.upper().startswith("NEGATIVE")
            if is_negative:
                save_alert({
                    "id": f"ns-{int(time.time()*1000)}-{company}",
                    "agent": "News Sentinel",
                    "type": "news",
                    "severity": "medium",
                    "title": f"⚠️ Negative news detected for {company}",
                    "body": sentiment.split("\n")[-1] if "\n" in sentiment else sentiment,
                    "ts": time.time(), "read": False
                })
        except: continue

# ─── Agent 3: Tax Guardian ────────────────────────────────────────────────────
def run_tax_guardian():
    harvest_candidates = []
    for t in PORTFOLIO_TICKERS:
        q = fetch_price(t["yfSym"])
        if not q: continue
        current_value = q["price"] * t["qty"]
        cost_value    = t["avgCost"] * t["qty"]
        pnl           = current_value - cost_value
        pnl_pct       = (pnl / cost_value) * 100
        if pnl < -5000:  # meaningful loss worth harvesting
            tax_saved = abs(pnl) * 0.15  # 15% STCG rate
            harvest_candidates.append({
                "ticker": t["ticker"], "pnl": pnl, "pnl_pct": pnl_pct,
                "tax_saved": tax_saved, "qty": t["qty"]
            })

    if not harvest_candidates: return
    total_tax_saved = sum(c["tax_saved"] for c in harvest_candidates)
    tickers = ", ".join([f"{c['ticker']} (₹{abs(c['pnl']):,.0f} loss)" for c in harvest_candidates])

    # Check if near financial year end (Jan-Mar)
    month = time.localtime().tm_mon
    urgency = "🚨 URGENT — Financial year ends 31 March!" if month >= 1 and month <= 3 else "📋 Tax harvest opportunity"

    save_alert({
        "id": f"tg-{int(time.time()*1000)}",
        "agent": "Tax Guardian",
        "type": "tax",
        "severity": "high" if month >= 3 else "medium",
        "title": f"{urgency} Save ₹{total_tax_saved:,.0f} in taxes",
        "body": f"Harvest losses in: {tickers}. Sell and rebuy after 30 days to reset cost basis.",
        "ts": time.time(), "read": False
    })

# ─── Agent 4: SIP Health ──────────────────────────────────────────────────────
def run_sip_health():
    q = fetch_price(NIFTY_SYM)
    if not q: return
    nifty_chg = q["chgPct"]
    price     = q["price"]

    if nifty_chg <= -2.0:
        analysis = groq_chat(
            "You are a SIP investment advisor. Be direct.",
            f"Nifty 50 is down {abs(nifty_chg):.1f}% today at {price:.0f}. Should investor pause their SIP or continue? 1 sentence."
        )
        save_alert({
            "id": f"sip-{int(time.time()*1000)}",
            "agent": "SIP Health",
            "type": "sip",
            "severity": "medium",
            "title": f"📉 Nifty down {abs(nifty_chg):.1f}% — SIP review needed",
            "body": analysis or "Market correction detected. Consider if you want to pause or top-up your SIPs.",
            "ts": time.time(), "read": False
        })
    elif nifty_chg >= 1.5:
        save_alert({
            "id": f"sip-{int(time.time()*1000)}",
            "agent": "SIP Health",
            "type": "sip",
            "severity": "low",
            "title": f"📈 Nifty up {nifty_chg:.1f}% — Market momentum strong",
            "body": f"Nifty at {price:.0f}. Good time to review if SIP amount needs increasing for higher allocation.",
            "ts": time.time(), "read": False
        })

# ─── Main Guardian Loop ───────────────────────────────────────────────────────
_guardian_running = False
_guardian_status  = {"running": False, "last_run": None, "next_run": None, "run_count": 0, "errors": []}

def guardian_loop():
    global _guardian_status
    _guardian_status["running"] = True
    while _guardian_running:
        try:
            _guardian_status["last_run"] = time.time()
            _guardian_status["run_count"] += 1
            print(f"\n[Guardian] Run #{_guardian_status['run_count']} at {time.strftime('%H:%M:%S')}")

            print("[Guardian] Agent 1: Price Watch...")
            run_price_watch()

            print("[Guardian] Agent 2: News Sentinel...")
            run_news_sentinel()

            print("[Guardian] Agent 3: Tax Guardian...")
            run_tax_guardian()

            print("[Guardian] Agent 4: SIP Health...")
            run_sip_health()

            _guardian_status["next_run"] = time.time() + 300
            print(f"[Guardian] Cycle complete. Next run in 5 minutes.")
        except Exception as e:
            err = str(e)[:100]
            _guardian_status["errors"].append({"ts": time.time(), "error": err})
            print(f"[Guardian] Error: {err}")

        # Sleep 5 minutes in 10s chunks so we can stop cleanly
        for _ in range(30):
            if not _guardian_running: break
            time.sleep(10)

    _guardian_status["running"] = False

# ─── API Routes ───────────────────────────────────────────────────────────────
@router.post("/start")
async def start_guardian():
    global _guardian_running
    if _guardian_status["running"]:
        return {"status": "already_running", "message": "Guardian is already active"}
    _guardian_running = True
    t = threading.Thread(target=guardian_loop, daemon=True)
    t.start()
    return {"status": "started", "message": "AUERON Guardian started — monitoring every 5 minutes"}

@router.post("/stop")
async def stop_guardian():
    global _guardian_running
    _guardian_running = False
    return {"status": "stopped"}

@router.get("/status")
async def get_status():
    return {**_guardian_status, "alert_count": len(load_alerts())}

@router.get("/alerts")
async def get_alerts(limit: int = 50, unread_only: bool = False):
    alerts = load_alerts()
    if unread_only: alerts = [a for a in alerts if not a.get("read")]
    return {"alerts": alerts[:limit], "total": len(alerts), "unread": len([a for a in alerts if not a.get("read")])}

@router.post("/mark-read")
async def mark_read(body: dict):
    alert_id = body.get("id")
    alerts   = load_alerts()
    for a in alerts:
        if alert_id == "all" or a.get("id") == alert_id:
            a["read"] = True
    with open(ALERTS_FILE, "w") as f: json.dump(alerts, f)
    return {"status": "ok"}

@router.delete("/alerts")
async def clear_alerts():
    with open(ALERTS_FILE, "w") as f: json.dump([], f)
    return {"status": "cleared"}

@router.post("/run-now")
async def run_now():
    """Force an immediate scan — useful for demo."""
    def _run():
        try: run_price_watch()
        except Exception as e: print(f"Price watch error: {e}")
        try: run_news_sentinel()
        except Exception as e: print(f"News sentinel error: {e}")
        try: run_tax_guardian()
        except Exception as e: print(f"Tax guardian error: {e}")
        try: run_sip_health()
        except Exception as e: print(f"SIP health error: {e}")
    t = threading.Thread(target=_run, daemon=True)
    t.start()
    return {"status": "scanning", "message": "All 4 agents scanning now..."}
