"""
Portfolio route — CAMS/KFintech statement parser + overlap analysis agent.
Powered by Groq LLaMA-3.3-70B — fast, free, no extra API key needed.
"""
from fastapi import APIRouter, UploadFile, File
from pydantic import BaseModel
import os, json, re, requests

router = APIRouter()

GROQ_KEY   = os.getenv("GROQ_API_KEY", "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")
GROQ_URL   = "https://api.groq.com/openai/v1/chat/completions"
GROQ_MODEL = "llama-3.3-70b-versatile"

def groq_call(system: str, user: str, max_tokens: int = 1500) -> str:
    """Synchronous Groq call — used inside FastAPI routes."""
    resp = requests.post(
        GROQ_URL,
        headers={"Authorization": f"Bearer {GROQ_KEY}", "Content-Type": "application/json"},
        json={"model": GROQ_MODEL, "max_tokens": max_tokens, "temperature": 0.2,
              "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]},
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()["choices"][0]["message"]["content"]


@router.post("/upload-cams")
async def upload_cams(file: UploadFile = File(...)):
    """
    Accepts CAMS / KFintech statement (CSV or PDF text).
    Uses Groq LLaMA-3.3-70B to extract holdings.
    """
    content = await file.read()
    text = content.decode("utf-8", errors="ignore")

    prompt = f"""You are a CAMS mutual fund statement parser. Extract ALL mutual fund holdings from the statement below.

Return ONLY valid JSON, no markdown, no explanation:
{{
  "funds": [
    {{
      "name": "Full fund name",
      "amc": "AMC name",
      "category": "Large Cap|Mid Cap|Small Cap|ELSS|Flexi Cap|Hybrid|Debt|Index",
      "units": 1234.56,
      "nav": 123.45,
      "invested": 100000,
      "currentValue": 150000,
      "xirr": 18.5,
      "expenseRatio": 0.5,
      "benchmarkReturn": 14.0
    }}
  ],
  "totalInvested": 500000,
  "totalValue": 750000
}}

Statement:
{text[:5000]}"""

    try:
        raw = groq_call(
            "You are a financial data extraction expert. Return only valid compact JSON, no markdown backticks.",
            prompt, max_tokens=2000
        )
        # Strip markdown if present
        raw = re.sub(r'```json|```', '', raw).strip()
        match = re.search(r'\{[\s\S]*\}', raw)
        if match:
            data = json.loads(match.group())
            # Compute currentValue if missing
            for f in data.get("funds", []):
                if not f.get("currentValue") and f.get("units") and f.get("nav"):
                    f["currentValue"] = round(f["units"] * f["nav"], 0)
            return {"status": "success", "data": data, "filename": file.filename, "parser": "Groq LLaMA-3.3-70B"}
        else:
            return {"status": "error", "message": "Groq could not parse the statement — check CSV format"}
    except Exception as e:
        return {"status": "error", "message": str(e)}


@router.post("/analyze-overlap")
async def analyze_overlap(holdings: dict):
    """
    Overlap analysis powered by Groq LLaMA-3.3-70B.
    """
    funds_list = holdings.get("funds", [])
    fund_details = [
        f"{f.get('name','')} ({f.get('category','')}, TER {f.get('expenseRatio',0)}%, XIRR {f.get('xirr',0)}%)"
        for f in funds_list
    ]

    prompt = f"""These are an Indian investor's mutual funds:
{chr(10).join(f'- {d}' for d in fund_details)}

Identify pairs with likely high overlap (>50%) based on category and strategy similarity.
For each overlap pair give: which to keep, why, and the exact rebalancing action.
Be specific with fund names. Max 80 words total."""

    try:
        analysis = groq_call(
            "You are an Indian mutual fund overlap expert. Be specific and concise.",
            prompt, max_tokens=300
        )
        return {"analysis": analysis, "fund_count": len(funds_list), "agent": "Groq OverlapAgent LLaMA-3.3"}
    except Exception as e:
        return {"analysis": f"Overlap analysis failed: {str(e)}", "fund_count": 0}


@router.get("/health-score")
async def compute_health_score(
    emergency_months: float = 2,
    term_cover_cr: float = 1,
    equity_pct: float = 70,
    debt_ratio: float = 0.1,
    section80c_used: float = 120000
):
    """Computes the 6-dimension money health score."""
    scores = {
        "emergency_fund": min(100, (emergency_months / 6) * 100),
        "insurance": min(100, (term_cover_cr / 1.5) * 100),
        "diversification": min(100, 100 - abs(equity_pct - 70)),
        "debt_health": min(100, 100 - (debt_ratio * 200)),
        "tax_efficiency": min(100, (section80c_used / 150000) * 100),
        "retirement_readiness": 72,  # computed from FIRE agent
    }
    overall = round(sum(scores.values()) / len(scores))
    return {"scores": scores, "overall": overall}
