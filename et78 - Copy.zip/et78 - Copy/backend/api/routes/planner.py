"""
Planner route — FIRE calculation engine + AI SIP recommendations.
"""
from fastapi import APIRouter
from pydantic import BaseModel
import os
import math

try:
    import anthropic
except ImportError:
    anthropic = None

router = APIRouter()
client = anthropic.AsyncAnthropic(api_key=os.getenv("ANTHROPIC_API_KEY", "")) if anthropic else None


class FireInput(BaseModel):
    current_age: int = 28
    retire_age: int = 45
    monthly_expenses: float = 80000
    current_corpus: float = 1200000
    monthly_sip: float = 50000
    expected_return_pct: float = 12.0
    inflation_pct: float = 6.0


@router.post("/fire-plan")
async def compute_fire_plan(data: FireInput):
    years = data.retire_age - data.current_age
    monthly_rate = data.expected_return_pct / 100 / 12

    # Target corpus = 25x inflation-adjusted annual expenses (4% SWR)
    future_expenses_annual = data.monthly_expenses * 12 * math.pow(1 + data.inflation_pct / 100, years)
    target_corpus = future_expenses_annual * 25

    # FV of existing corpus
    n = years * 12
    fv_existing = data.current_corpus * math.pow(1 + monthly_rate, n)

    # Monthly SIP needed
    remaining = max(0, target_corpus - fv_existing)
    if remaining > 0 and monthly_rate > 0:
        monthly_needed = remaining * monthly_rate / (math.pow(1 + monthly_rate, n) - 1)
    else:
        monthly_needed = 0

    # Year-by-year projection
    milestones = []
    corpus = data.current_corpus
    for year in range(years + 1):
        milestones.append({
            "year": year,
            "age": data.current_age + year,
            "corpus": round(corpus),
            "target": round(target_corpus),
            "pct_achieved": round(min(100, corpus / target_corpus * 100), 1)
        })
        for _ in range(12):
            corpus = corpus * (1 + monthly_rate) + data.monthly_sip

    on_track = data.monthly_sip >= monthly_needed * 0.9

    return {
        "target_corpus": round(target_corpus),
        "monthly_needed": round(monthly_needed),
        "monthly_shortfall": round(max(0, monthly_needed - data.monthly_sip)),
        "on_track": on_track,
        "years_to_fire": years,
        "projected_at_current_sip": round(corpus),
        "milestones": milestones,
        "inflation_adjusted_monthly_expenses_at_retire": round(future_expenses_annual / 12),
    }


@router.post("/sip-recommendations")
async def sip_recommendations(monthly_amount: float, risk_profile: str = "moderate", years: int = 17):
    """AI-generated SIP allocation for a given monthly amount."""
    prompt = f"""Generate a specific mutual fund SIP allocation plan for an Indian investor:
- Monthly SIP amount: ₹{monthly_amount:,.0f}
- Risk profile: {risk_profile}
- Investment horizon: {years} years
- Goal: FIRE (Financial Independence, Retire Early)

Recommend 4-5 specific fund names with:
1. Exact monthly allocation amount
2. % of total
3. One-line rationale (include 5Y returns and TER)

    Format as JSON array: [{{"fund": "", "amount": 0, "pct": 0, "rationale": ""}}]"""

    try:
        if not client:
            return {"recommendations": [], "error": "Anthropic SDK not installed"}
        response = await client.messages.create(
            model="claude-haiku-4-5-20251001",
            max_tokens=512,
            messages=[{"role": "user", "content": prompt}]
        )
        import json, re
        text = response.content[0].text
        json_match = re.search(r'\[.*\]', text, re.DOTALL)
        recs = json.loads(json_match.group()) if json_match else []
        return {"recommendations": recs, "total": monthly_amount}
    except Exception as e:
        return {"recommendations": [], "error": str(e)}
