"""
Agent API — WebSocket + REST endpoints
Streams agent state updates to the frontend in real time.
"""
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import asyncio, json, time, uuid, os
from typing import Optional

router = APIRouter()

# In-memory session store (use Redis in production)
sessions: dict = {}


class AgentRequest(BaseModel):
    user_goal:    str
    broker:       str = "demo"
    budget:       float = 50000
    risk_profile: str = "moderate"


class ConfirmRequest(BaseModel):
    session_id: str
    confirmed:  bool


@router.post("/start")
async def start_agent(req: AgentRequest):
    """Start the agent pipeline. Returns session_id immediately, pipeline runs in background."""
    session_id = str(uuid.uuid4())
    sessions[session_id] = {
        "status":    "starting",
        "state":     None,
        "updates":   [],
        "started_at": time.time(),
    }
    asyncio.create_task(run_pipeline_background(session_id, req))
    return {"session_id": session_id, "status": "started"}


@router.get("/status/{session_id}")
async def get_status(session_id: str):
    """Poll for current agent state."""
    if session_id not in sessions:
        return JSONResponse({"error": "Session not found"}, status_code=404)
    return sessions[session_id]


@router.post("/confirm")
async def confirm_trade(req: ConfirmRequest):
    """User confirms or rejects the pending trades."""
    if req.session_id not in sessions:
        return JSONResponse({"error": "Session not found"}, status_code=404)

    session = sessions[req.session_id]
    state   = session.get("state", {})

    if not state:
        return JSONResponse({"error": "No pending state"}, status_code=400)

    if req.confirmed:
        # Use asyncio.create_task so Playwright runs properly in the existing event loop
        asyncio.create_task(run_execution_background(req.session_id, state))
        return {"status": "executing", "message": "Executing trades on broker..."}
    else:
        session["status"] = "cancelled"
        session["updates"].append({"step": "User rejected trades", "ts": time.time()})
        return {"status": "cancelled"}


@router.delete("/session/{session_id}")
async def end_session(session_id: str):
    sessions.pop(session_id, None)
    return {"status": "deleted"}


@router.websocket("/ws/{session_id}")
async def agent_websocket(websocket: WebSocket, session_id: str):
    """Real-time WebSocket stream of agent updates."""
    await websocket.accept()
    last_sent = 0
    try:
        while True:
            session = sessions.get(session_id, {})
            updates = session.get("updates", [])
            new_updates = updates[last_sent:]
            if new_updates:
                await websocket.send_json({"updates": new_updates, "status": session.get("status")})
                last_sent = len(updates)
            if session.get("status") in ("completed", "cancelled", "error"):
                await websocket.send_json({"final_state": session.get("state"), "status": session.get("status")})
                break
            await asyncio.sleep(0.5)
    except WebSocketDisconnect:
        pass


async def run_pipeline_background(session_id: str, req: AgentRequest):
    """Runs the LangGraph pipeline, streaming updates to session."""
    import requests as req_lib

    def push(step: str, status: str = "running"):
        sessions[session_id]["updates"].append({"step": step, "status": status, "ts": time.time()})
        sessions[session_id]["status"] = status

    try:
        # ── Research Agent (sync, run in thread) ──
        push("Research Agent: Fetching live NSE prices...", "running")

        TICKERS = [
            "RELIANCE.NS","TCS.NS","INFY.NS","HDFCBANK.NS","TATAMOTORS.NS",
            "ICICIBANK.NS","WIPRO.NS","ZOMATO.NS","BAJFINANCE.NS","ADANIPORTS.NS",
            "HINDUNILVR.NS","MARUTI.NS","AXISBANK.NS","SUNPHARMA.NS","LTIM.NS",
        ]
        SEEDS = {"RELIANCE.NS":2890,"TCS.NS":3980,"INFY.NS":1780,"HDFCBANK.NS":1640,"TATAMOTORS.NS":890}

        def fetch_prices():
            live = {}
            for sym in TICKERS:
                try:
                    r = req_lib.get(
                        f"https://query1.finance.yahoo.com/v8/finance/chart/{sym}?interval=1d&range=2d",
                        headers={"User-Agent": "Mozilla/5.0"}, timeout=6)
                    meta  = r.json()["chart"]["result"][0]["meta"]
                    price = meta["regularMarketPrice"]
                    prev  = meta.get("previousClose", price)
                    live[sym] = {"price": price, "chg": round(price-prev,2),
                                 "chgPct": round((price-prev)/prev*100,2) if prev else 0,
                                 "volume": meta.get("regularMarketVolume",0)}
                except:
                    p = SEEDS.get(sym, 1000)
                    live[sym] = {"price":p,"chg":0,"chgPct":0,"volume":0}
            return live

        live_prices = await asyncio.get_event_loop().run_in_executor(None, fetch_prices)
        push(f"Research Agent: {len(live_prices)} stocks loaded", "running")

        # ── Analysis Agent (Groq call in thread) ──
        push("Analysis Agent: Groq LLaMA-3.3 scoring opportunities...", "running")

        prices_summary = "\n".join([
            f"{s.replace('.NS','')}: ₹{d['price']} ({d['chgPct']:+.2f}%)"
            for s, d in live_prices.items()
        ])
        prompt = f"""User goal: {req.user_goal}
Budget: ₹{req.budget:,.0f}
Risk profile: {req.risk_profile}

Live NSE prices:
{prices_summary}

Pick TOP 3 stocks. Return ONLY valid JSON array, no markdown:
[{{"ticker":"SYMBOL","company":"Full Name","action":"BUY","qty":5,"price":1780.0,"total_value":8900.0,"score":87,"reason":"Specific reason","risk":"Key risk"}}]"""

        def groq_call():
            import json as json_lib, re
            from groq import Groq
            client = Groq(api_key=os.getenv("GROQ_API_KEY","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"))
            resp = client.chat.completions.create(
                model="llama-3.3-70b-versatile", max_tokens=600, temperature=0.3,
                messages=[
                    {"role":"system","content":"You are an NSE stock analyst. Return only valid compact JSON arrays, no markdown."},
                    {"role":"user","content":prompt}
                ])
            raw = resp.choices[0].message.content
            match = re.search(r'\[[\s\S]*?\]', raw)
            if not match:
                return []
            picks = json_lib.loads(match.group())
            for p in picks:
                sym = p["ticker"] + ".NS"
                if sym in live_prices:
                    p["price"] = live_prices[sym]["price"]
                    p["total_value"] = round(p["price"] * p["qty"], 2)
            return picks

        top_picks = await asyncio.get_event_loop().run_in_executor(None, groq_call)
        push(f"Analysis Agent: {len(top_picks)} picks — {', '.join(p['ticker'] for p in top_picks)}", "running")

        # ── Browser Agent (only if not demo) ──
        browser_connected = False
        portfolio_on_broker = []
        if req.broker != "demo":
            push(f"Browser Agent: Launching {req.broker} in browser — please log in...", "running")
            from agents.orchestrator import browser_agent_async
            broker_state = {
                "broker": req.broker, "top_picks": top_picks,
                "audit_log": [], "current_step": "",
                "browser_connected": False, "portfolio_on_broker": [],
                "broker_session_id": None, "error": None,
            }
            broker_state = await browser_agent_async(broker_state)
            browser_connected   = broker_state.get("browser_connected", False)
            portfolio_on_broker = broker_state.get("portfolio_on_broker", [])
            push(f"Browser Agent: {'Connected — portfolio read' if browser_connected else 'Login timeout — continuing'}", "running")
        else:
            push("Browser Agent: Demo mode — skipping broker launch", "running")

        # ── Trade Agent ──
        push("Trade Agent: Calculating exact order quantities...", "running")
        pending_trades = []
        for pick in top_picks:
            sym = pick["ticker"] + ".NS"
            price = live_prices.get(sym, {}).get("price", pick.get("price", 0))
            if price <= 0:
                continue
            budget_per = req.budget / max(len(top_picks), 1)
            qty = max(1, int(budget_per / price))
            pending_trades.append({
                "ticker": pick["ticker"], "company": pick.get("company", pick["ticker"]),
                "action": pick.get("action","BUY"), "qty": qty,
                "price": round(price, 2), "total_value": round(qty * price, 2),
                "reason": pick.get("reason",""), "risk": pick.get("risk","Market risk"),
                "score": pick.get("score", 75), "broker": req.broker,
            })
        push(f"Trade Agent: {len(pending_trades)} orders prepared — total ₹{sum(t['total_value'] for t in pending_trades):,.0f}", "running")

        # ── Risk Agent ──
        push("Risk Agent: Running validation checks...", "running")
        warnings = []
        for t in pending_trades:
            if t["total_value"] > req.budget:
                warnings.append(f"{t['ticker']}: value exceeds budget")
            if t["total_value"] > req.budget * 0.4:
                warnings.append(f"{t['ticker']}: >40% concentration risk")
            chg = live_prices.get(t['ticker']+".NS", {}).get("chgPct", 0)
            if abs(chg) > 5:
                warnings.append(f"{t['ticker']}: high volatility today ({chg:+.1f}%)")
        push(f"Risk Agent: {len(warnings)} warnings — HUMAN APPROVAL REQUIRED", "done")

        sessions[session_id]["state"] = {
            "pending_trades": pending_trades,
            "risk_warnings": warnings,
            "live_prices": live_prices,
            "broker": req.broker,
            "audit_log": [],
        }
        sessions[session_id]["status"] = "awaiting_confirmation"

    except Exception as e:
        sessions[session_id]["status"] = "error"
        sessions[session_id]["updates"].append({"step": f"Pipeline error: {str(e)[:200]}", "status": "error", "ts": time.time()})


async def run_execution_background(session_id: str, state: dict):
    """Runs Playwright in a separate thread — reliable on Windows."""
    import traceback

    sessions[session_id]["status"] = "executing"
    sessions[session_id]["updates"].append({
        "step": "Execution Agent: Starting order placement...", "status": "running", "ts": time.time()
    })

    broker  = state.get("broker", "demo")
    trades  = state.get("pending_trades", [])

    def push(msg, status="running"):
        sessions[session_id]["updates"].append({"step": msg, "status": status, "ts": time.time()})

    def run_playwright_sync():
        """Runs in a dedicated thread with its own event loop."""
        import asyncio as _asyncio
        from playwright.sync_api import sync_playwright

        executed = []
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=False, args=["--no-sandbox"])
                context = browser.new_context(
                    viewport={"width": 1280, "height": 800},
                    user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
                )
                page = context.new_page()

                for trade in trades:
                    ticker = trade["ticker"]
                    push(f"Execution Agent: Opening {ticker} on {broker}...")

                    try:
                        if broker == "groww":
                            page.goto(f"https://groww.in/stocks/{ticker.lower()}", timeout=25000)
                            page.wait_for_timeout(2000)
                            # Try to click Buy button
                            try:
                                page.click(f"button:has-text('Buy')", timeout=5000)
                                page.wait_for_timeout(1000)
                                qty = page.query_selector("input[placeholder*='Qty'], input[placeholder*='quantity'], input[name='quantity']")
                                if qty:
                                    qty.fill(str(trade["qty"]))
                                push(f"Execution Agent: ✅ {ticker} — BUY form filled. {trade['qty']} shares @ ₹{trade['price']}. Press Buy on screen to finalise.", "done")
                            except:
                                push(f"Execution Agent: ✅ {ticker} page loaded — manually place {trade['action']} for {trade['qty']} shares @ ₹{trade['price']}", "done")

                        elif broker == "zerodha":
                            page.goto("https://kite.zerodha.com", timeout=25000)
                            page.wait_for_timeout(2000)
                            push(f"Execution Agent: ✅ Zerodha open — search {ticker}, place {trade['action']} {trade['qty']} shares @ ₹{trade['price']}", "done")

                        elif broker == "sharekhan":
                            page.goto(f"https://www.sharekhan.com/StockDetails/{ticker}/NSE", timeout=25000)
                            page.wait_for_timeout(2000)
                            push(f"Execution Agent: ✅ Sharekhan {ticker} page open — place {trade['action']} {trade['qty']} shares @ ₹{trade['price']}", "done")

                        elif broker == "demo":
                            page.goto(f"https://www.nseindia.com/get-quotes/equity?symbol={ticker}", timeout=25000)
                            page.wait_for_timeout(1500)
                            push(f"Execution Agent: ✅ NSE page for {ticker} — Demo mode, no order placed", "done")

                        executed.append({**trade, "status": "order_staged", "staged_at": time.time()})

                    except Exception as e:
                        err = traceback.format_exc()
                        push(f"Execution Agent: ❌ {ticker} error — {str(e)[:120]}", "error")
                        executed.append({**trade, "status": "failed", "error": str(e)})

                # Keep browser open for 60s so user can interact
                push(f"Execution Agent: Browser open — complete your orders. Closing in 60s...", "done")
                import time as _time
                _time.sleep(60)
                browser.close()

        except Exception as e:
            err = traceback.format_exc()
            push(f"Execution Agent: Browser launch failed — {str(e)} | {err[-300:]}", "error")
            return []

        return executed

    try:
        # Run Playwright in a thread executor — only reliable way on Windows
        loop = asyncio.get_event_loop()
        executed = await loop.run_in_executor(None, run_playwright_sync)

        sessions[session_id]["state"]  = {**state, "executed_trades": executed or []}
        sessions[session_id]["status"] = "completed"
        sessions[session_id]["updates"].append({
            "step": f"Execution complete: {len(executed or [])} orders staged — finalise on your broker",
            "status": "done", "ts": time.time()
        })

    except Exception as e:
        sessions[session_id]["status"] = "error"
        sessions[session_id]["updates"].append({
            "step": f"Execution error: {traceback.format_exc()[-300:]}", "status": "error", "ts": time.time()
        })
