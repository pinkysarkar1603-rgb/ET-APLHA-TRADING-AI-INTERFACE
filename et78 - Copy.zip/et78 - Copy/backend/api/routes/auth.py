"""
Authentication — SQLite-backed user accounts with JWT tokens.
All data persisted in et78/data/etAlpha.db — survives restarts forever.
"""
from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
import sqlite3, hashlib, hmac, secrets, time, json, os, re

router  = APIRouter()
bearer  = HTTPBearer(auto_error=False)

# ─── Database path — stored in data/ folder next to backend ──────────────────
DB_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "..", "data", "etAlpha.db")
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

SECRET  = os.getenv("JWT_SECRET", "etAlphaSecret2026XyZ")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c    = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS users (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        username      TEXT UNIQUE NOT NULL,
        email         TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        created_at    REAL DEFAULT (unixepoch()),
        reset_token   TEXT,
        reset_expiry  REAL
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS user_data (
        user_id   INTEGER NOT NULL,
        key       TEXT NOT NULL,
        value     TEXT NOT NULL,
        updated   REAL DEFAULT (unixepoch()),
        PRIMARY KEY (user_id, key),
        FOREIGN KEY (user_id) REFERENCES users(id)
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS price_alerts (
        id          TEXT PRIMARY KEY,
        user_id     INTEGER NOT NULL,
        ticker      TEXT NOT NULL,
        target      REAL NOT NULL,
        direction   TEXT NOT NULL,
        triggered   INTEGER DEFAULT 0,
        created_at  REAL DEFAULT (unixepoch()),
        FOREIGN KEY (user_id) REFERENCES users(id)
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS guardian_alerts (
        id          TEXT PRIMARY KEY,
        user_id     INTEGER NOT NULL,
        agent       TEXT,
        type        TEXT,
        severity    TEXT,
        title       TEXT,
        body        TEXT,
        read        INTEGER DEFAULT 0,
        ts          REAL DEFAULT (unixepoch()),
        FOREIGN KEY (user_id) REFERENCES users(id)
    )""")
    conn.commit(); conn.close()

init_db()

# ─── JWT (simple HMAC — no extra deps needed) ────────────────────────────────
def make_token(user_id: int, username: str) -> str:
    payload = f"{user_id}:{username}:{int(time.time()) + 86400*30}"  # 30 day expiry
    sig     = hmac.new(SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
    import base64
    return base64.urlsafe_b64encode(f"{payload}|{sig}".encode()).decode()

def verify_token(token: str) -> dict | None:
    try:
        import base64
        decoded = base64.urlsafe_b64decode(token.encode()).decode()
        payload, sig = decoded.rsplit("|", 1)
        expected = hmac.new(SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, expected): return None
        user_id, username, expiry = payload.split(":")
        if int(expiry) < time.time(): return None
        return {"user_id": int(user_id), "username": username}
    except: return None

def hash_password(password: str) -> str:
    return hashlib.sha256((password + SECRET).encode()).hexdigest()

def get_current_user(creds: HTTPAuthorizationCredentials = Depends(bearer)):
    if not creds: raise HTTPException(401, "Not authenticated")
    user = verify_token(creds.credentials)
    if not user: raise HTTPException(401, "Invalid or expired token")
    return user

# ─── Models ──────────────────────────────────────────────────────────────────
class RegisterRequest(BaseModel):
    username: str
    email:    str
    password: str

class LoginRequest(BaseModel):
    username: str  # can be username or email
    password: str

class ForgotRequest(BaseModel):
    email: str

class ResetRequest(BaseModel):
    token:    str
    password: str

class SaveDataRequest(BaseModel):
    key:   str
    value: dict | list | str | float | int

# ─── Routes ──────────────────────────────────────────────────────────────────
@router.post("/register")
def register(req: RegisterRequest):
    if len(req.username) < 3:
        raise HTTPException(400, "Username must be at least 3 characters")
    if len(req.password) < 6:
        raise HTTPException(400, "Password must be at least 6 characters")
    if not re.match(r"[^@]+@[^@]+\.[^@]+", req.email):
        raise HTTPException(400, "Invalid email address")

    conn = get_db()
    try:
        conn.execute(
            "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)",
            (req.username.lower().strip(), req.email.lower().strip(), hash_password(req.password))
        )
        conn.commit()
        user_id = conn.execute("SELECT id FROM users WHERE username=?", (req.username.lower(),)).fetchone()["id"]
        token   = make_token(user_id, req.username.lower())
        return {"status": "success", "token": token, "username": req.username.lower(), "user_id": user_id}
    except sqlite3.IntegrityError as e:
        if "username" in str(e): raise HTTPException(400, "Username already taken")
        if "email"    in str(e): raise HTTPException(400, "Email already registered")
        raise HTTPException(400, str(e))
    finally:
        conn.close()

@router.post("/login")
def login(req: LoginRequest):
    conn = get_db()
    try:
        user = conn.execute(
            "SELECT * FROM users WHERE username=? OR email=?",
            (req.username.lower(), req.username.lower())
        ).fetchone()
        if not user or user["password_hash"] != hash_password(req.password):
            raise HTTPException(401, "Invalid username/email or password")
        token = make_token(user["id"], user["username"])
        return {"status": "success", "token": token, "username": user["username"], "user_id": user["id"]}
    finally:
        conn.close()

@router.post("/forgot-password")
def forgot_password(req: ForgotRequest):
    conn = get_db()
    try:
        user = conn.execute("SELECT * FROM users WHERE email=?", (req.email.lower(),)).fetchone()
        if not user:
            # Don't reveal if email exists
            return {"status": "success", "message": "If that email exists, a reset code has been sent"}
        token  = secrets.token_hex(6).upper()  # 6-char code
        expiry = time.time() + 3600  # 1 hour
        conn.execute("UPDATE users SET reset_token=?, reset_expiry=? WHERE id=?", (token, expiry, user["id"]))
        conn.commit()
        # In production send email — for now print to console
        print(f"\n{'='*50}")
        print(f"PASSWORD RESET CODE for {req.email}: {token}")
        print(f"{'='*50}\n")
        return {"status": "success", "message": f"Reset code printed to backend console. Code: {token}"}
    finally:
        conn.close()

@router.post("/reset-password")
def reset_password(req: ResetRequest):
    conn = get_db()
    try:
        user = conn.execute(
            "SELECT * FROM users WHERE reset_token=? AND reset_expiry>?",
            (req.token.upper(), time.time())
        ).fetchone()
        if not user: raise HTTPException(400, "Invalid or expired reset code")
        if len(req.password) < 6: raise HTTPException(400, "Password must be at least 6 characters")
        conn.execute(
            "UPDATE users SET password_hash=?, reset_token=NULL, reset_expiry=NULL WHERE id=?",
            (hash_password(req.password), user["id"])
        )
        conn.commit()
        return {"status": "success", "message": "Password reset successfully. Please login."}
    finally:
        conn.close()

@router.get("/me")
def get_me(user=Depends(get_current_user)):
    conn = get_db()
    try:
        u = conn.execute("SELECT id, username, email, created_at FROM users WHERE id=?", (user["user_id"],)).fetchone()
        if not u: raise HTTPException(404, "User not found")
        return {"user_id": u["id"], "username": u["username"], "email": u["email"], "created_at": u["created_at"]}
    finally:
        conn.close()

# ─── Per-user data persistence ───────────────────────────────────────────────
@router.post("/data/save")
def save_data(req: SaveDataRequest, user=Depends(get_current_user)):
    conn = get_db()
    try:
        conn.execute(
            "INSERT OR REPLACE INTO user_data (user_id, key, value, updated) VALUES (?, ?, ?, ?)",
            (user["user_id"], req.key, json.dumps(req.value), time.time())
        )
        conn.commit()
        return {"status": "saved", "key": req.key}
    finally:
        conn.close()

@router.get("/data/{key}")
def load_data(key: str, user=Depends(get_current_user)):
    conn = get_db()
    try:
        row = conn.execute(
            "SELECT value FROM user_data WHERE user_id=? AND key=?",
            (user["user_id"], key)
        ).fetchone()
        if not row: return {"status": "not_found", "value": None}
        return {"status": "ok", "value": json.loads(row["value"])}
    finally:
        conn.close()

@router.get("/data")
def load_all_data(user=Depends(get_current_user)):
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT key, value, updated FROM user_data WHERE user_id=?",
            (user["user_id"],)
        ).fetchall()
        return {"data": {r["key"]: json.loads(r["value"]) for r in rows}}
    finally:
        conn.close()

# ─── Per-user price alerts ────────────────────────────────────────────────────
@router.get("/alerts/price")
def get_price_alerts(user=Depends(get_current_user)):
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM price_alerts WHERE user_id=? ORDER BY created_at DESC",
            (user["user_id"],)
        ).fetchall()
        return {"alerts": [dict(r) for r in rows]}
    finally:
        conn.close()

@router.post("/alerts/price")
def save_price_alert(body: dict, user=Depends(get_current_user)):
    conn = get_db()
    try:
        import uuid
        alert_id = body.get("id") or f"alert-{int(time.time()*1000)}"
        conn.execute(
            "INSERT OR REPLACE INTO price_alerts (id, user_id, ticker, target, direction, triggered) VALUES (?,?,?,?,?,?)",
            (alert_id, user["user_id"], body["ticker"], body["targetPrice"], body["direction"], int(body.get("triggered", False)))
        )
        conn.commit()
        return {"status": "saved", "id": alert_id}
    finally:
        conn.close()

@router.delete("/alerts/price/{alert_id}")
def delete_price_alert(alert_id: str, user=Depends(get_current_user)):
    conn = get_db()
    try:
        conn.execute("DELETE FROM price_alerts WHERE id=? AND user_id=?", (alert_id, user["user_id"]))
        conn.commit()
        return {"status": "deleted"}
    finally:
        conn.close()
