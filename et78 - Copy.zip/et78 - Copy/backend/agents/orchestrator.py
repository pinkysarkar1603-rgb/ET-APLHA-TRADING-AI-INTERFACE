"""
ET Alpha — LangGraph Multi-Agent Orchestrator
=============================================
6 specialized agents in a directed graph:
  1. ResearchAgent    — fetches live NSE prices + signals
  2. AnalysisAgent    — scores stocks, identifies best opportunities
  3. BrowserAgent     — controls Playwright to navigate broker site
  4. TradeAgent       — prepares trade actions (buy/sell + qty)
  5. RiskAgent        — validates against risk rules before execution
  6. ExecutionAgent   — presents confirmation, executes if approved

Human-in-the-loop: RiskAgent always pauses for user confirmation
before any order is placed. Agent cannot execute without approval.

Error recovery: Every agent has retry logic + escalation path.
Audit trail: Every state transition is logged with timestamp.
"""
from __future__ import annotations
import asyncio, json, time, os
from typing import TypedDict, Literal, Optional, List, Dict, Any
from langgraph.graph import StateGraph, END
from groq import Groq

GROQ_KEY = os.getenv("GROQ_API_KEY", "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")
groq_client = Groq(api_key=GROQ_KEY)

# ─── Shared State ─────────────────────────────────────────────────────────────
class AgentState(TypedDict):
    # Input
    user_goal: str                    # "Find me the best 2 stocks to buy today"
    broker: str                       # "sharekhan" | "groww" | "zerodha"
    budget: float                     # Available capital
    risk_profile: str                 # "conservative" | "moderate" | "aggressive"

    # Research phase
    live_prices: Dict[str, Any]       # ticker -> {price, chg, volume}
    signals: List[Dict]               # Groq-generated signals from live data

    # Analysis phase
    top_picks: List[Dict]             # [{ticker, score, reason, action, qty, price}]
    analysis_reasoning: str

    # Browser phase
    browser_connected: bool
    portfolio_on_broker: List[Dict]   # Holdings read from broker
    broker_session_id: Optional[str]

    # Trade phase
    pending_trades: List[Dict]        # [{ticker, action, qty, price, value, reason}]
    risk_check_passed: bool
    risk_warnings: List[str]

    # Execution phase
    awaiting_confirmation: bool
    user_confirmed: bool
    executed_trades: List[Dict]
    execution_result: str

    # Audit
    audit_log: List[Dict]             # [{step, agent, input, output, ts, status}]
    current_step: str
    error: Optional[str]
    retry_count: int
    next_node: str


def log_step(state: AgentState, agent: str, step: str, output: str, status: str = "done") -> AgentState:
    """Append to audit trail — every decision logged."""
    entry = {
        "id":     f"audit-{int(time.time()*1000)}",
        "agent":  agent,
        "step":   step,
        "output": output,
        "status": status,
        "ts":     time.time(),
    }
    state["audit_log"] = state.get("audit_log", []) + [entry]
    state["current_step"] = step
    return state


def groq_call(system: str, user: str, json_mode: bool = False) -> str:
    """Groq LLaMA-3.3-70B call — fast, free, reliable."""
    resp = groq_client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        max_tokens=800,
        temperature=0.3,
        messages=[
            {"role": "system", "content": system},
            {"role": "user",   "content": user},
        ],
    )
    return resp.choices[0].message.content


# ─── Agent 1: Research Agent ──────────────────────────────────────────────────
def research_agent(state: AgentState) -> AgentState:
    """
    Fetches live NSE prices for top 15 stocks.
    Uses Yahoo Finance via requests (no browser needed).
    Error recovery: falls back to cached prices if API fails.
    """
    state = log_step(state, "ResearchAgent", "Fetching live NSE prices", "", "running")

    import requests
    TICKERS = [
        "RELIANCE.NS","TCS.NS","INFY.NS","HDFCBANK.NS","TATAMOTORS.NS",
        "ICICIBANK.NS","WIPRO.NS","ZOMATO.NS","BAJFINANCE.NS","ADANIPORTS.NS",
        "HINDUNILVR.NS","MARUTI.NS","AXISBANK.NS","SUNPHARMA.NS","LTIM.NS",
    ]

    live_prices = {}
    failed = []
    for sym in TICKERS:
        try:
            url  = f"https://query1.finance.yahoo.com/v8/finance/chart/{sym}?interval=1d&range=2d"
            r    = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=6)
            data = r.json()
            meta = data["chart"]["result"][0]["meta"]
            price = meta["regularMarketPrice"]
            prev  = meta.get("previousClose", price)
            live_prices[sym] = {
                "price":    price,
                "chg":      round(price - prev, 2),
                "chgPct":   round((price - prev) / prev * 100, 2) if prev else 0,
                "volume":   meta.get("regularMarketVolume", 0),
                "high":     meta.get("regularMarketDayHigh", price),
                "low":      meta.get("regularMarketDayLow",  price),
            }
        except Exception as e:
            failed.append(sym)
            # Fallback: seed price so pipeline doesn't break
            SEEDS = {"RELIANCE.NS":2890,"TCS.NS":3980,"INFY.NS":1780,"HDFCBANK.NS":1640,"TATAMOTORS.NS":890}
            p = SEEDS.get(sym, 1000)
            live_prices[sym] = {"price":p,"chg":0,"chgPct":0,"volume":0,"high":p,"low":p}

    state["live_prices"] = live_prices
    output = f"Loaded {len(live_prices)} stocks. {len(failed)} used fallback: {', '.join(failed[:3])}"

    # Error recovery: if >50% failed, mark for retry
    if len(failed) > len(TICKERS) * 0.5 and state.get("retry_count", 0) < 2:
        state["retry_count"] = state.get("retry_count", 0) + 1
        state["error"] = f"Too many price fetch failures ({len(failed)}), retrying..."
        state = log_step(state, "ResearchAgent", "Price fetch partial failure — retrying", output, "error")
        state["next_node"] = "research_agent"  # self-retry
        return state

    state = log_step(state, "ResearchAgent", "Live prices fetched", output, "done")
    state["next_node"] = "analysis_agent"
    state["error"] = None
    return state


# ─── Agent 2: Analysis Agent ──────────────────────────────────────────────────
def analysis_agent(state: AgentState) -> AgentState:
    """
    Groq analyses live prices against user goal + risk profile.
    Returns ranked picks with specific quantities and reasoning.
    """
    state = log_step(state, "AnalysisAgent", "Scoring stocks with Groq LLaMA-3.3", "", "running")

    prices_summary = "\n".join([
        f"{sym.replace('.NS','')}: ₹{d['price']} ({d['chgPct']:+.2f}%, vol {d['volume']//1000}K)"
        for sym, d in state["live_prices"].items()
    ])

    prompt = f"""User goal: {state['user_goal']}
Budget: ₹{state['budget']:,.0f}
Risk profile: {state['risk_profile']}

Live NSE prices right now:
{prices_summary}

Analyse and pick the TOP 3 stocks that best match the goal. For each, calculate:
- Exact quantity to buy given the budget (split budget across picks)
- Clear buy/sell/hold action
- One-sentence reasoning citing actual price movement

Return ONLY valid JSON, no markdown:
[
  {{
    "ticker": "SYMBOL",
    "company": "Full Name",
    "action": "BUY",
    "qty": 5,
    "price": 2890.50,
    "value": 14452.50,
    "score": 87,
    "reason": "Specific reason citing today's price movement and volume",
    "risk": "Key risk to watch"
  }}
]"""

    try:
        raw  = groq_call("You are an NSE stock analyst. Return only valid compact JSON arrays.", prompt)
        import re
        match = re.search(r'\[[\s\S]*?\]', raw)
        picks = json.loads(match.group()) if match else []

        # Validate picks
        for pick in picks:
            sym = pick["ticker"] + ".NS"
            if sym in state["live_prices"]:
                # Use real live price
                pick["price"] = state["live_prices"][sym]["price"]
                pick["value"] = round(pick["price"] * pick["qty"], 2)

        state["top_picks"] = picks
        state["analysis_reasoning"] = f"Groq identified {len(picks)} opportunities from {len(state['live_prices'])} stocks"
        state = log_step(state, "AnalysisAgent", "Stock scoring complete", f"{len(picks)} picks: {', '.join(p['ticker'] for p in picks)}", "done")
    except Exception as e:
        state["error"] = f"Analysis failed: {str(e)}"
        state["top_picks"] = []
        state = log_step(state, "AnalysisAgent", "Analysis failed — using fallback", str(e), "error")

    state["next_node"] = "browser_agent"
    return state


# ─── Agent 3: Browser Agent ──────────────────────────────────────────────────
async def browser_agent_async(state: AgentState) -> AgentState:
    """
    Playwright controls the broker browser:
    1. Opens broker URL
    2. Waits for user login (polls for auth cookies)
    3. Navigates to portfolio/watchlist
    4. Reads current holdings via DOM selectors
    5. Navigates to order placement page for each pick
    """
    state = log_step(state, "BrowserAgent", f"Launching {state['broker']} browser session", "", "running")

    BROKER_CONFIGS = {
        "sharekhan": {
            "url":         "https://www.sharekhan.com",
            "login_check": ".user-name,.profile-name,#username-display,[data-user]",
            "portfolio":   "https://www.sharekhan.com/online-share-trading/portfolio",
            "order_url":   "https://www.sharekhan.com/online-share-trading/equities/buy-sell",
        },
        "groww": {
            "url":         "https://groww.in",
            "login_check": ".userAvatar,.header-user,[data-testid='user-avatar']",
            "portfolio":   "https://groww.in/dashboard/portfolio/stocks",
            "order_url":   "https://groww.in/stocks",
        },
        "zerodha": {
            "url":         "https://kite.zerodha.com",
            "login_check": ".user-name,.profile,[data-user-name]",
            "portfolio":   "https://kite.zerodha.com/holdings",
            "order_url":   "https://kite.zerodha.com",
        },
        "demo": {
            "url":         "https://www.nseindia.com",
            "login_check": "body",
            "portfolio":   "https://www.nseindia.com/market-data/top-gainers-and-losers",
            "order_url":   "https://www.nseindia.com",
        },
    }

    broker_cfg = BROKER_CONFIGS.get(state["broker"], BROKER_CONFIGS["demo"])

    try:
        from playwright.async_api import async_playwright
        async with async_playwright() as p:
            browser = await p.chromium.launch(
                headless=False,              # Visible browser — user can see it working
                args=["--no-sandbox", "--disable-dev-shm-usage"],
            )
            context = await browser.new_context(
                viewport={"width": 1280, "height": 800},
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            )
            page = await context.new_page()

            # Step 1: Navigate to broker
            state = log_step(state, "BrowserAgent", f"Opening {broker_cfg['url']}", "", "running")
            await page.goto(broker_cfg["url"], wait_until="domcontentloaded", timeout=30000)
            await asyncio.sleep(2)

            # Step 2: Wait for user login (max 120 seconds)
            state = log_step(state, "BrowserAgent", "Waiting for user login...", "User must log in within 120s", "running")
            logged_in = False
            for attempt in range(24):  # 24 × 5s = 120s
                try:
                    elem = await page.query_selector(broker_cfg["login_check"])
                    if elem:
                        logged_in = True
                        break
                except:
                    pass
                await asyncio.sleep(5)

            if not logged_in:
                # Error recovery: continue with demo mode
                state = log_step(state, "BrowserAgent", "Login timeout — switching to demo mode", "Proceeding with simulated broker data", "error")
                state["browser_connected"] = False
                state["portfolio_on_broker"] = []
                state["next_node"] = "trade_agent"
                await browser.close()
                return state

            state = log_step(state, "BrowserAgent", "User logged in successfully", f"Session active on {state['broker']}", "done")
            state["browser_connected"] = True

            # Step 3: Read portfolio
            state = log_step(state, "BrowserAgent", "Reading portfolio holdings", "", "running")
            await page.goto(broker_cfg["portfolio"], timeout=30000)
            await asyncio.sleep(3)

            # Extract holdings from DOM
            holdings_js = """
            () => {
                const rows = document.querySelectorAll('table tr, .holding-row, .portfolio-row, [class*="holding"], [class*="stock-row"]');
                const holdings = [];
                rows.forEach(row => {
                    const text = row.innerText;
                    const match = text.match(/([A-Z]{2,15})\\s+([\\d,]+)\\s+[\\d.]+/);
                    if (match) holdings.push({ ticker: match[1], qty: parseInt(match[2].replace(',','')) });
                });
                return holdings.slice(0, 20);
            }
            """
            try:
                raw_holdings = await page.evaluate(holdings_js)
                state["portfolio_on_broker"] = raw_holdings if raw_holdings else []
            except:
                state["portfolio_on_broker"] = []

            state = log_step(state, "BrowserAgent", "Portfolio read complete",
                           f"Found {len(state['portfolio_on_broker'])} holdings on {state['broker']}", "done")

            # Step 4: Navigate to order pages for each pick
            for pick in state.get("top_picks", [])[:3]:
                ticker = pick["ticker"]
                state = log_step(state, "BrowserAgent", f"Navigating to {ticker} order page", f"Action: {pick['action']}", "running")

                if state["broker"] == "groww":
                    await page.goto(f"https://groww.in/stocks/{ticker.lower()}", timeout=20000)
                elif state["broker"] == "zerodha":
                    await page.goto(f"https://kite.zerodha.com/chart/ext/ciq/NSE/{ticker}/1D", timeout=20000)
                elif state["broker"] == "sharekhan":
                    await page.goto(f"https://www.sharekhan.com/StockDetails/{ticker}/NSE", timeout=20000)

                await asyncio.sleep(2)
                state = log_step(state, "BrowserAgent", f"{ticker} order page loaded", f"Ready to place {pick['action']} order for {pick['qty']} shares", "done")

            await asyncio.sleep(1)
            await browser.close()

    except Exception as e:
        state["error"] = f"Browser agent error: {str(e)[:100]}"
        state["browser_connected"] = False
        state = log_step(state, "BrowserAgent", "Browser error — graceful degradation", str(e)[:80], "error")

    state["next_node"] = "trade_agent"
    return state


def browser_agent(state: AgentState) -> AgentState:
    """Sync wrapper for async browser agent."""
    try:
        return asyncio.get_event_loop().run_until_complete(browser_agent_async(state))
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        return loop.run_until_complete(browser_agent_async(state))


# ─── Agent 4: Trade Agent ─────────────────────────────────────────────────────
def trade_agent(state: AgentState) -> AgentState:
    """
    Prepares the exact trade orders:
    - Calculates final quantities
    - Sets order type (market/limit)
    - Computes total value + portfolio impact
    """
    state = log_step(state, "TradeAgent", "Preparing trade orders", "", "running")

    picks  = state.get("top_picks", [])
    prices = state.get("live_prices", {})
    pending = []

    for pick in picks:
        sym = pick["ticker"] + ".NS"
        current_price = prices.get(sym, {}).get("price", pick.get("price", 0))

        if current_price <= 0:
            continue

        # Recalculate qty with latest price
        budget_per_pick = state["budget"] / max(len(picks), 1)
        qty = max(1, int(budget_per_pick / current_price))

        trade = {
            "ticker":        pick["ticker"],
            "company":       pick.get("company", pick["ticker"]),
            "action":        pick.get("action", "BUY"),
            "qty":           qty,
            "price":         round(current_price, 2),
            "total_value":   round(qty * current_price, 2),
            "order_type":    "MARKET",
            "reason":        pick.get("reason", ""),
            "risk":          pick.get("risk", "Market risk applies"),
            "score":         pick.get("score", 75),
            "broker":        state["broker"],
        }
        pending.append(trade)

    state["pending_trades"] = pending
    total_value = sum(t["total_value"] for t in pending)
    state = log_step(state, "TradeAgent", "Trade orders prepared",
                    f"{len(pending)} orders, total ₹{total_value:,.0f}", "done")
    state["next_node"] = "risk_agent"
    return state


# ─── Agent 5: Risk Agent ──────────────────────────────────────────────────────
def risk_agent(state: AgentState) -> AgentState:
    """
    Validates all trades against risk rules:
    - Single stock concentration (<30% of portfolio)
    - Budget overflow check
    - Volatility check (avoid >5% movers without confirmation)
    - Always sets awaiting_confirmation = True (human-in-the-loop)

    This agent NEVER executes automatically.
    Human approval is ALWAYS required.
    """
    state = log_step(state, "RiskAgent", "Running risk validation", "", "running")

    warnings = []
    trades   = state.get("pending_trades", [])
    budget   = state["budget"]
    prices   = state.get("live_prices", {})

    for trade in trades:
        # Budget check
        if trade["total_value"] > budget:
            warnings.append(f"{trade['ticker']}: Order value ₹{trade['total_value']:,.0f} exceeds budget ₹{budget:,.0f}")

        # Concentration check
        if trade["total_value"] > budget * 0.4:
            warnings.append(f"{trade['ticker']}: Single stock >40% of budget — concentration risk")

        # Volatility check
        sym    = trade["ticker"] + ".NS"
        chgPct = prices.get(sym, {}).get("chgPct", 0)
        if abs(chgPct) > 5:
            warnings.append(f"{trade['ticker']}: High volatility today ({chgPct:+.1f}%) — review carefully")

    # Risk profile check
    if state["risk_profile"] == "conservative":
        for trade in trades:
            sym = trade["ticker"] + ".NS"
            if prices.get(sym, {}).get("volume", 0) < 100000:
                warnings.append(f"{trade['ticker']}: Low volume stock — not suitable for conservative profile")

    state["risk_check_passed"] = len([w for w in warnings if "exceeds budget" in w]) == 0
    state["risk_warnings"]     = warnings

    # ALWAYS require human confirmation — this is the human-in-the-loop gate
    state["awaiting_confirmation"] = True
    state["user_confirmed"]        = False

    state = log_step(state, "RiskAgent", "Risk check complete — awaiting user confirmation",
                    f"{len(warnings)} warnings. Human approval required before execution.", "done")
    state["next_node"] = "await_confirmation"
    return state


# ─── Agent 6: Execution Agent ─────────────────────────────────────────────────
async def execution_agent_async(state: AgentState) -> AgentState:
    """
    ONLY runs if user_confirmed = True.
    Launches Playwright, navigates to broker, fills in order form,
    and submits. Shows real-time progress.
    """
    if not state.get("user_confirmed", False):
        state = log_step(state, "ExecutionAgent", "Execution cancelled — user did not confirm", "", "done")
        state["execution_result"] = "cancelled"
        return state

    state = log_step(state, "ExecutionAgent", "User confirmed — executing trades", "", "running")

    executed = []
    for trade in state.get("pending_trades", []):
        state = log_step(state, "ExecutionAgent",
                        f"Placing {trade['action']} order: {trade['qty']} × {trade['ticker']} @ ₹{trade['price']}",
                        f"Order value: ₹{trade['total_value']:,.0f}", "running")
        try:
            from playwright.async_api import async_playwright
            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=False)
                context = await browser.new_context()
                page    = await context.new_page()

                if trade["broker"] == "groww":
                    await page.goto(f"https://groww.in/stocks/{trade['ticker'].lower()}", timeout=20000)
                    await asyncio.sleep(2)
                    # Click Buy/Sell button
                    btn_sel = f"button:has-text('{trade['action'].capitalize()}')"
                    btn = await page.query_selector(btn_sel)
                    if btn:
                        await btn.click()
                        await asyncio.sleep(1)
                        # Fill quantity
                        qty_input = await page.query_selector("input[placeholder*='Qty'], input[placeholder*='quantity'], #quantity")
                        if qty_input:
                            await qty_input.fill(str(trade["qty"]))
                        state = log_step(state, "ExecutionAgent",
                                        f"Order form filled for {trade['ticker']}",
                                        f"QTY: {trade['qty']}, awaiting final submit (NOT auto-submitted)", "done")
                    else:
                        state = log_step(state, "ExecutionAgent",
                                        f"Buy/Sell button not found for {trade['ticker']}",
                                        "Page loaded but could not locate order button — manual action needed", "error")

                elif trade["broker"] == "zerodha":
                    await page.goto("https://kite.zerodha.com", timeout=20000)
                    await asyncio.sleep(2)
                    state = log_step(state, "ExecutionAgent",
                                    f"Zerodha kite loaded for {trade['ticker']}",
                                    f"Use search to find {trade['ticker']} and place {trade['action']} order", "done")

                await asyncio.sleep(2)
                await browser.close()

            executed.append({**trade, "status": "order_staged", "staged_at": time.time()})
            state = log_step(state, "ExecutionAgent",
                            f"Order staged: {trade['ticker']} {trade['action']} {trade['qty']} shares",
                            f"₹{trade['total_value']:,.0f} — confirm on broker screen to finalise", "done")

        except Exception as e:
            state = log_step(state, "ExecutionAgent", f"Execution error for {trade['ticker']}", str(e)[:80], "error")
            executed.append({**trade, "status": "failed", "error": str(e)})

    state["executed_trades"]  = executed
    state["execution_result"] = "staged"
    state = log_step(state, "ExecutionAgent",
                    "All orders staged on broker",
                    f"{len(executed)} orders staged. Broker confirmation required to finalise.", "done")
    return state


def execution_agent(state: AgentState) -> AgentState:
    try:
        return asyncio.get_event_loop().run_until_complete(execution_agent_async(state))
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        return loop.run_until_complete(execution_agent_async(state))


# ─── Router ──────────────────────────────────────────────────────────────────
def route_after_research(state: AgentState) -> str:
    if state.get("next_node") == "research_agent":
        return "research_agent"  # self-retry
    return "analysis_agent"


def route_after_risk(state: AgentState) -> str:
    # Always pause for human confirmation
    return END  # Frontend polls for awaiting_confirmation=True then sends confirm


# ─── Build Graph ──────────────────────────────────────────────────────────────
def build_agent_graph():
    graph = StateGraph(AgentState)

    graph.add_node("research_agent",  research_agent)
    graph.add_node("analysis_agent",  analysis_agent)
    graph.add_node("browser_agent",   browser_agent)
    graph.add_node("trade_agent",     trade_agent)
    graph.add_node("risk_agent",      risk_agent)
    graph.add_node("execution_agent", execution_agent)

    graph.set_entry_point("research_agent")

    graph.add_conditional_edges("research_agent", route_after_research, {
        "research_agent": "research_agent",
        "analysis_agent": "analysis_agent",
    })
    graph.add_edge("analysis_agent",  "browser_agent")
    graph.add_edge("browser_agent",   "trade_agent")
    graph.add_edge("trade_agent",     "risk_agent")
    graph.add_conditional_edges("risk_agent", route_after_risk, {END: END})

    return graph.compile()


# The compiled graph — import this in the API
agent_graph = build_agent_graph()


async def run_agent_pipeline(
    user_goal: str,
    broker: str,
    budget: float,
    risk_profile: str,
) -> AgentState:
    """Run the full pipeline, stopping before execution for human confirmation."""
    initial_state: AgentState = {
        "user_goal":            user_goal,
        "broker":               broker,
        "budget":               budget,
        "risk_profile":         risk_profile,
        "live_prices":          {},
        "signals":              [],
        "top_picks":            [],
        "analysis_reasoning":   "",
        "browser_connected":    False,
        "portfolio_on_broker":  [],
        "broker_session_id":    None,
        "pending_trades":       [],
        "risk_check_passed":    False,
        "risk_warnings":        [],
        "awaiting_confirmation": False,
        "user_confirmed":       False,
        "executed_trades":      [],
        "execution_result":     "",
        "audit_log":            [],
        "current_step":         "init",
        "error":                None,
        "retry_count":          0,
        "next_node":            "research_agent",
    }
    result = await asyncio.get_event_loop().run_in_executor(None, agent_graph.invoke, initial_state)
    return result


async def confirm_and_execute(state: AgentState) -> AgentState:
    """Call this after user clicks 'Confirm' in the UI."""
    state["user_confirmed"] = True
    return execution_agent(state)
