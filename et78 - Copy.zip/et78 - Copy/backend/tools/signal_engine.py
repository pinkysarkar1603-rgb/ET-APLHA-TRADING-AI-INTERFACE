"""
Real market signal and indicator engine for ET Alpha.

This module only works from fetched market data. If a source is unavailable,
the caller gets fewer rows or an explicit error instead of fabricated values.
"""

from __future__ import annotations

import json
import math
import os
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from statistics import mean
from typing import Any

import requests
from dotenv import load_dotenv

from nse_scraper import get_bulk_deals, get_insider_trades

load_dotenv()

GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
GROQ_MODEL = "llama-3.3-70b-versatile"
YAHOO_HEADERS = {"User-Agent": "Mozilla/5.0"}

WATCHLIST = [
    {"symbol": "RELIANCE.NS", "ticker": "RELIANCE", "company": "Reliance Industries", "sector": "Energy"},
    {"symbol": "TCS.NS", "ticker": "TCS", "company": "Tata Consultancy Services", "sector": "IT"},
    {"symbol": "INFY.NS", "ticker": "INFY", "company": "Infosys", "sector": "IT"},
    {"symbol": "HDFCBANK.NS", "ticker": "HDFCBANK", "company": "HDFC Bank", "sector": "Banking"},
    {"symbol": "ICICIBANK.NS", "ticker": "ICICIBANK", "company": "ICICI Bank", "sector": "Banking"},
    {"symbol": "TATAMOTORS.NS", "ticker": "TATAMOT", "company": "Tata Motors", "sector": "Auto"},
    {"symbol": "WIPRO.NS", "ticker": "WIPRO", "company": "Wipro", "sector": "IT"},
    {"symbol": "ZOMATO.NS", "ticker": "ZOMATO", "company": "Zomato", "sector": "Consumer"},
    {"symbol": "BAJFINANCE.NS", "ticker": "BAJFINANCE", "company": "Bajaj Finance", "sector": "Finance"},
    {"symbol": "ADANIPORTS.NS", "ticker": "ADANIPORTS", "company": "Adani Ports", "sector": "Logistics"},
    {"symbol": "HINDUNILVR.NS", "ticker": "HINDUNILVR", "company": "Hindustan Unilever", "sector": "Consumer"},
    {"symbol": "MARUTI.NS", "ticker": "MARUTI", "company": "Maruti Suzuki", "sector": "Auto"},
    {"symbol": "AXISBANK.NS", "ticker": "AXISBANK", "company": "Axis Bank", "sector": "Banking"},
    {"symbol": "SUNPHARMA.NS", "ticker": "SUNPHARMA", "company": "Sun Pharma", "sector": "Pharma"},
    {"symbol": "LTIM.NS", "ticker": "LTIM", "company": "LTIMindtree", "sector": "IT"},
]

DASHBOARD_CACHE: dict[str, tuple[float, dict[str, Any]]] = {}


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def _round(value: float, digits: int = 2) -> float:
    return round(_safe_float(value), digits)


def _ema(values: list[float], period: int) -> float:
    if len(values) < period:
        return values[-1] if values else 0.0
    multiplier = 2 / (period + 1)
    ema = mean(values[:period])
    for value in values[period:]:
        ema = ((value - ema) * multiplier) + ema
    return ema


def _sma(values: list[float], period: int) -> float:
    if len(values) < period:
        return mean(values) if values else 0.0
    return mean(values[-period:])


def compute_rsi(closes: list[float], period: int = 14) -> float:
    if len(closes) < period + 1:
        return 50.0
    gains: list[float] = []
    losses: list[float] = []
    for idx in range(1, len(closes)):
        diff = closes[idx] - closes[idx - 1]
        gains.append(max(diff, 0))
        losses.append(max(-diff, 0))
    avg_gain = mean(gains[-period:])
    avg_loss = mean(losses[-period:])
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return _round(100 - (100 / (1 + rs)), 1)


def compute_macd(closes: list[float]) -> dict[str, float]:
    if len(closes) < 35:
        return {"macd": 0.0, "signal": 0.0, "histogram": 0.0}
    macd_series: list[float] = []
    for idx in range(26, len(closes)):
        slice_values = closes[: idx + 1]
        macd_series.append(_ema(slice_values, 12) - _ema(slice_values, 26))
    signal = _ema(macd_series, 9)
    macd = macd_series[-1]
    histogram = macd - signal
    return {"macd": _round(macd, 2), "signal": _round(signal, 2), "histogram": _round(histogram, 2)}


def compute_atr(highs: list[float], lows: list[float], closes: list[float], period: int = 14) -> float:
    if len(highs) < 2 or len(lows) < 2 or len(closes) < 2:
        return 0.0
    true_ranges: list[float] = []
    for idx in range(1, min(len(highs), len(lows), len(closes))):
        high = highs[idx]
        low = lows[idx]
        prev_close = closes[idx - 1]
        true_ranges.append(max(high - low, abs(high - prev_close), abs(low - prev_close)))
    if not true_ranges:
        return 0.0
    sample = true_ranges[-period:] if len(true_ranges) >= period else true_ranges
    return _round(mean(sample), 2)


def compute_support_resistance(closes: list[float], highs: list[float], lows: list[float]) -> tuple[float, float]:
    if not closes:
        return 0.0, 0.0
    support_window = lows[-20:] if len(lows) >= 20 else lows
    resistance_window = highs[-20:] if len(highs) >= 20 else highs
    return _round(min(support_window) if support_window else closes[-1], 2), _round(max(resistance_window) if resistance_window else closes[-1], 2)


def compute_momentum(closes: list[float], period: int) -> float:
    if len(closes) <= period:
        return 0.0
    base = closes[-(period + 1)]
    if not base:
        return 0.0
    return _round(((closes[-1] - base) / base) * 100, 2)


def compute_volume_spike(volume: float, avg_volume: float) -> float:
    if not avg_volume:
        return 0.0
    return _round(volume / avg_volume, 2)


def detect_setup(snapshot: dict[str, Any]) -> str:
    if snapshot["rsi"] >= 68 and snapshot["macd_histogram"] > 0 and snapshot["volume_spike"] >= 1.3:
        return "Momentum breakout"
    if snapshot["rsi"] <= 35 and snapshot["changePct"] > 0 and snapshot["macd_histogram"] > 0:
        return "Oversold rebound"
    if snapshot["price"] > snapshot["sma20"] > snapshot["sma50"]:
        return "Trend continuation"
    if snapshot["price"] < snapshot["sma20"] < snapshot["sma50"]:
        return "Breakdown pressure"
    if abs(snapshot["price"] - snapshot["support"]) <= max(snapshot["atr"], 1):
        return "Support retest"
    return "Mixed setup"


def detect_trend(price: float, sma20: float, sma50: float, macd_histogram: float) -> str:
    if price > sma20 > sma50 and macd_histogram >= 0:
        return "bullish"
    if price < sma20 < sma50 and macd_histogram <= 0:
        return "bearish"
    return "neutral"


def build_risk_flags(snapshot: dict[str, Any]) -> list[str]:
    flags: list[str] = []
    if snapshot["rsi"] >= 74:
        flags.append("Overbought RSI")
    if snapshot["rsi"] <= 28:
        flags.append("Oversold RSI")
    if snapshot["volume_spike"] >= 2.5:
        flags.append("Extreme volume surge")
    if snapshot["distanceTo52wHighPct"] <= 1.5:
        flags.append("Near 52-week high")
    if snapshot["distanceTo52wLowPct"] <= 2.0:
        flags.append("Near 52-week low")
    if snapshot["atr_pct"] >= 4:
        flags.append("High volatility")
    return flags


def score_snapshot(snapshot: dict[str, Any]) -> tuple[int, int]:
    bullish = 0
    bearish = 0

    if snapshot["price"] > snapshot["sma20"]:
        bullish += 12
    else:
        bearish += 12

    if snapshot["sma20"] > snapshot["sma50"]:
        bullish += 12
    else:
        bearish += 12

    if snapshot["macd_histogram"] > 0:
        bullish += 12
    elif snapshot["macd_histogram"] < 0:
        bearish += 12

    if 48 <= snapshot["rsi"] <= 68:
        bullish += 10
    elif snapshot["rsi"] >= 72:
        bearish += 8
    elif snapshot["rsi"] <= 32:
        bullish += 8

    if snapshot["volume_spike"] >= 1.4:
        if snapshot["changePct"] >= 0:
            bullish += 10
        else:
            bearish += 10

    if snapshot["momentum5d"] > 0:
        bullish += 10
    elif snapshot["momentum5d"] < 0:
        bearish += 10

    if snapshot["momentum20d"] > 0:
        bullish += 10
    elif snapshot["momentum20d"] < 0:
        bearish += 10

    if snapshot["distanceTo52wHighPct"] <= 5:
        bullish += 8
    if snapshot["distanceTo52wLowPct"] <= 5:
        bearish += 8

    bullish = min(bullish, 100)
    bearish = min(bearish, 100)
    return bullish, bearish


def build_conviction(snapshot: dict[str, Any], bullish: int, bearish: int) -> int:
    conviction = abs(bullish - bearish)
    if snapshot["volume_spike"] >= 1.5:
        conviction += 8
    if snapshot["setup"] in {"Momentum breakout", "Oversold rebound"}:
        conviction += 6
    return max(35, min(conviction, 96))


def fetch_price_history(symbol: str, range_code: str = "6mo", interval: str = "1d") -> dict[str, Any] | None:
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}?interval={interval}&range={range_code}"
    try:
        response = requests.get(url, headers=YAHOO_HEADERS, timeout=10)
        data = response.json()
        result = data["chart"]["result"][0]
        meta = result["meta"]
        quotes = result["indicators"]["quote"][0]

        closes = [_safe_float(value) for value in quotes.get("close", []) if value is not None]
        highs = [_safe_float(value) for value in quotes.get("high", []) if value is not None]
        lows = [_safe_float(value) for value in quotes.get("low", []) if value is not None]
        volumes = [_safe_float(value) for value in quotes.get("volume", []) if value is not None]

        if len(closes) < 30:
            return None

        price = _safe_float(meta.get("regularMarketPrice"), closes[-1])
        previous_close = _safe_float(meta.get("previousClose"), closes[-2] if len(closes) > 1 else price)
        change = price - previous_close
        change_pct = ((change / previous_close) * 100) if previous_close else 0
        volume = _safe_float(meta.get("regularMarketVolume"), volumes[-1] if volumes else 0)
        avg_volume = _safe_float(meta.get("averageDailyVolume3Month"), mean(volumes[-20:]) if len(volumes) >= 20 else mean(volumes))

        sma20 = _sma(closes, 20)
        sma50 = _sma(closes, 50)
        ema12 = _ema(closes, 12)
        ema26 = _ema(closes, 26)
        macd = compute_macd(closes)
        atr = compute_atr(highs, lows, closes)
        support, resistance = compute_support_resistance(closes, highs, lows)
        high_52w = max(highs[-252:] if len(highs) >= 252 else highs)
        low_52w = min(lows[-252:] if len(lows) >= 252 else lows)

        snapshot: dict[str, Any] = {
            "symbol": symbol,
            "ticker": symbol.replace(".NS", ""),
            "price": _round(price, 2),
            "previousClose": _round(previous_close, 2),
            "change": _round(change, 2),
            "changePct": _round(change_pct, 2),
            "open": _round(_safe_float(meta.get("regularMarketOpen"), price), 2),
            "high": _round(_safe_float(meta.get("regularMarketDayHigh"), price), 2),
            "low": _round(_safe_float(meta.get("regularMarketDayLow"), price), 2),
            "volume": int(volume),
            "avgVolume": int(avg_volume),
            "rsi": compute_rsi(closes),
            "sma20": _round(sma20, 2),
            "sma50": _round(sma50, 2),
            "ema12": _round(ema12, 2),
            "ema26": _round(ema26, 2),
            "macd": macd["macd"],
            "macdSignal": macd["signal"],
            "macdHistogram": macd["histogram"],
            "atr": atr,
            "atr_pct": _round((atr / price) * 100 if price else 0, 2),
            "support": support,
            "resistance": resistance,
            "volumeSpike": compute_volume_spike(volume, avg_volume),
            "momentum5d": compute_momentum(closes, 5),
            "momentum20d": compute_momentum(closes, 20),
            "high52w": _round(high_52w, 2),
            "low52w": _round(low_52w, 2),
            "distanceTo52wHighPct": _round(((high_52w - price) / high_52w) * 100 if high_52w else 0, 2),
            "distanceTo52wLowPct": _round(((price - low_52w) / low_52w) * 100 if low_52w else 0, 2),
            "closes": closes,
            "timestamp": int(time.time() * 1000),
        }

        snapshot["trend"] = detect_trend(snapshot["price"], snapshot["sma20"], snapshot["sma50"], snapshot["macdHistogram"])
        snapshot["setup"] = detect_setup(
            {
                "rsi": snapshot["rsi"],
                "macd_histogram": snapshot["macdHistogram"],
                "volume_spike": snapshot["volumeSpike"],
                "price": snapshot["price"],
                "sma20": snapshot["sma20"],
                "sma50": snapshot["sma50"],
                "support": snapshot["support"],
                "atr": snapshot["atr"],
                "changePct": snapshot["changePct"],
            }
        )
        bullish, bearish = score_snapshot(
            {
                "price": snapshot["price"],
                "sma20": snapshot["sma20"],
                "sma50": snapshot["sma50"],
                "macd_histogram": snapshot["macdHistogram"],
                "rsi": snapshot["rsi"],
                "volume_spike": snapshot["volumeSpike"],
                "changePct": snapshot["changePct"],
                "momentum5d": snapshot["momentum5d"],
                "momentum20d": snapshot["momentum20d"],
                "distanceTo52wHighPct": snapshot["distanceTo52wHighPct"],
                "distanceTo52wLowPct": snapshot["distanceTo52wLowPct"],
            }
        )
        snapshot["bullishScore"] = bullish
        snapshot["bearishScore"] = bearish
        snapshot["conviction"] = build_conviction({"volume_spike": snapshot["volumeSpike"], "setup": snapshot["setup"]}, bullish, bearish)
        snapshot["riskFlags"] = build_risk_flags(
            {
                "rsi": snapshot["rsi"],
                "volume_spike": snapshot["volumeSpike"],
                "distanceTo52wHighPct": snapshot["distanceTo52wHighPct"],
                "distanceTo52wLowPct": snapshot["distanceTo52wLowPct"],
                "atr_pct": snapshot["atr_pct"],
            }
        )
        return snapshot
    except Exception:
        return None


def _match_corporate_activity(rows: list[dict[str, Any]], ticker: str) -> list[dict[str, Any]]:
    return [row for row in rows if (row.get("ticker") or "").replace(".NS", "").upper() == ticker.upper()]


def _build_signal_detail(item: dict[str, Any], bulk_hits: list[dict[str, Any]], insider_hits: list[dict[str, Any]]) -> str:
    detail = (
        f"{item['company']} is at Rs {item['price']} ({item['changePct']}% today). "
        f"RSI is {item['rsi']}, MACD histogram is {item['macdHistogram']}, and volume is {item['volumeSpike']}x the 3M average. "
        f"Support sits near Rs {item['support']} and resistance near Rs {item['resistance']}."
    )
    if bulk_hits:
        top = bulk_hits[0]
        detail += f" Bulk deal activity detected: {top.get('client', 'participant')} {top.get('buySell', '')} around Rs {top.get('price', 0)}."
    if insider_hits:
        top = insider_hits[0]
        detail += f" Insider activity detected from {top.get('person', 'promoter')}."
    return detail


def _build_signal(item: dict[str, Any], bulk_hits: list[dict[str, Any]], insider_hits: list[dict[str, Any]]) -> dict[str, Any]:
    signal_type = "pattern"
    source = "Indicator Engine"
    if insider_hits:
        signal_type = "insider_trade"
        source = insider_hits[0].get("source", source)
    elif bulk_hits:
        signal_type = "bulk_deal"
        source = bulk_hits[0].get("source", source)
    elif item["setup"] == "Breakdown pressure":
        signal_type = "alert"

    sentiment = "neutral"
    if item["bullishScore"] > item["bearishScore"]:
        sentiment = "bullish"
    elif item["bearishScore"] > item["bullishScore"]:
        sentiment = "bearish"

    headline = (
        f"{item['ticker']} {item['setup']} at Rs {item['price']} "
        f"({item['changePct']}%), RSI {item['rsi']}, volume {item['volumeSpike']}x"
    )

    return {
        "id": f"sig-{item['ticker']}-{item['timestamp']}",
        "ticker": item["ticker"],
        "company": item["company"],
        "type": signal_type,
        "headline": headline,
        "detail": _build_signal_detail(item, bulk_hits, insider_hits),
        "sentiment": sentiment,
        "strength": item["conviction"],
        "actionable": item["conviction"] >= 55 and sentiment != "neutral",
        "source": source,
        "timestamp": item["timestamp"],
        "indicators": {
            "rsi": item["rsi"],
            "macd": item["macd"],
            "macdSignal": item["macdSignal"],
            "macdHistogram": item["macdHistogram"],
            "sma20": item["sma20"],
            "sma50": item["sma50"],
            "atr": item["atr"],
            "volumeSpike": item["volumeSpike"],
            "momentum5d": item["momentum5d"],
            "momentum20d": item["momentum20d"],
        },
        "setup": item["setup"],
        "trend": item["trend"],
        "support": item["support"],
        "resistance": item["resistance"],
        "bullishScore": item["bullishScore"],
        "bearishScore": item["bearishScore"],
        "riskFlags": item["riskFlags"],
        "verdict": "WATCH" if item["conviction"] < 60 else "BUY" if sentiment == "bullish" else "SELL" if sentiment == "bearish" else "HOLD",
        "confidence": min(max(item["conviction"], 35), 96),
    }


def _groq_chat(system: str, prompt: str, max_tokens: int = 900, temperature: float = 0.2) -> str:
    if not GROQ_API_KEY:
        return ""
    response = requests.post(
        "https://api.groq.com/openai/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {GROQ_API_KEY}",
            "Content-Type": "application/json",
        },
        json={
            "model": GROQ_MODEL,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": prompt},
            ],
        },
        timeout=25,
    )
    response.raise_for_status()
    data = response.json()
    return data["choices"][0]["message"]["content"].strip()


def enrich_signals_with_groq(signals: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if not GROQ_API_KEY or not signals:
        return signals

    system = (
        "You are a senior NSE market analyst working inside ET Alpha. "
        "Use only the numbers provided. Return only valid JSON."
    )
    prompt = (
        "Improve the following live signal payloads. Add sharper but compliant analysis. "
        "Do not invent new prices, news, or fundamentals. "
        "Return JSON array with fields: ticker, detail, verdict, confidence, riskFlags.\n\n"
        f"{json.dumps(signals[:6], ensure_ascii=True)}"
    )
    try:
        raw = _groq_chat(system, prompt, max_tokens=1200, temperature=0.15)
        match = re.search(r"\[[\s\S]*\]", raw)
        if not match:
            return signals
        upgrades = json.loads(match.group(0))
        by_ticker = {item.get("ticker"): item for item in upgrades if item.get("ticker")}
        enriched: list[dict[str, Any]] = []
        for signal in signals:
            upgrade = by_ticker.get(signal["ticker"])
            if not upgrade:
                enriched.append(signal)
                continue
            merged = dict(signal)
            if upgrade.get("detail"):
                merged["detail"] = upgrade["detail"]
            if upgrade.get("verdict"):
                merged["verdict"] = upgrade["verdict"]
            if upgrade.get("confidence"):
                merged["confidence"] = int(max(30, min(97, _safe_float(upgrade["confidence"]))))
            if isinstance(upgrade.get("riskFlags"), list):
                merged["riskFlags"] = list(dict.fromkeys(signal["riskFlags"] + upgrade["riskFlags"]))[:5]
            enriched.append(merged)
        return enriched
    except Exception:
        return signals


def get_market_dashboard(symbols: list[str] | None = None) -> dict[str, Any]:
    selected = WATCHLIST if not symbols else [item for item in WATCHLIST if item["ticker"] in symbols or item["symbol"] in symbols]
    cache_key = ",".join(sorted(item["ticker"] for item in selected)) or "default"
    cached = DASHBOARD_CACHE.get(cache_key)
    if cached and time.time() - cached[0] <= 15:
        return cached[1]

    indicators: list[dict[str, Any]] = []
    max_workers = min(8, max(1, len(selected)))
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_map = {executor.submit(fetch_price_history, item["symbol"]): item for item in selected}
        for future in as_completed(future_map):
            item = future_map[future]
            try:
                snapshot = future.result()
            except Exception:
                snapshot = None
            if not snapshot:
                continue
            snapshot["company"] = item["company"]
            snapshot["sector"] = item["sector"]
            indicators.append(snapshot)

    advancers = sum(1 for item in indicators if item["changePct"] > 0)
    decliners = sum(1 for item in indicators if item["changePct"] < 0)
    bullish_setups = sum(1 for item in indicators if item["trend"] == "bullish")
    bearish_setups = sum(1 for item in indicators if item["trend"] == "bearish")
    hottest = max(indicators, key=lambda row: row["conviction"], default=None)

    payload = {
        "overview": {
            "tracked": len(indicators),
            "advancers": advancers,
            "decliners": decliners,
            "bullishSetups": bullish_setups,
            "bearishSetups": bearish_setups,
            "avgRsi": _round(mean([row["rsi"] for row in indicators]), 1) if indicators else 0,
            "topSetup": hottest["ticker"] if hottest else None,
            "timestamp": int(time.time() * 1000),
        },
        "indicators": sorted(indicators, key=lambda row: row["conviction"], reverse=True),
    }
    DASHBOARD_CACHE[cache_key] = (time.time(), payload)
    return payload


def run_signal_pipeline() -> list[dict[str, Any]]:
    dashboard = get_market_dashboard()
    indicators = dashboard["indicators"]
    if not indicators:
        return []

    bulk_deals = get_bulk_deals()
    insider_trades = get_insider_trades()

    signals: list[dict[str, Any]] = []
    for item in indicators:
        if item["conviction"] < 48:
            continue
        bulk_hits = _match_corporate_activity(bulk_deals, item["ticker"])
        insider_hits = _match_corporate_activity(insider_trades, item["ticker"])
        signals.append(_build_signal(item, bulk_hits, insider_hits))

    signals = sorted(signals, key=lambda row: row["strength"], reverse=True)[:8]
    return enrich_signals_with_groq(signals)


def analyze_ticker_with_groq(ticker: str) -> dict[str, Any]:
    target = next((item for item in WATCHLIST if item["ticker"] == ticker.upper() or item["symbol"] == ticker.upper()), None)
    if not target:
        raise ValueError(f"Ticker not supported: {ticker}")

    snapshot = fetch_price_history(target["symbol"])
    if not snapshot:
        raise ValueError(f"Live data unavailable for {ticker}")

    snapshot["company"] = target["company"]
    snapshot["sector"] = target["sector"]

    fallback = (
        f"{target['company']} is trading at Rs {snapshot['price']} with {snapshot['changePct']}% move today. "
        f"RSI is {snapshot['rsi']}, MACD histogram is {snapshot['macdHistogram']}, and volume is {snapshot['volumeSpike']}x average. "
        f"Support is near Rs {snapshot['support']} and resistance near Rs {snapshot['resistance']}. "
        f"Setup: {snapshot['setup']}. Trend: {snapshot['trend']}."
    )

    if not GROQ_API_KEY:
        return {
            "ticker": target["ticker"],
            "company": target["company"],
            "analysis": fallback,
            "verdict": "WATCH" if snapshot["conviction"] < 60 else "BUY" if snapshot["bullishScore"] > snapshot["bearishScore"] else "SELL" if snapshot["bearishScore"] > snapshot["bullishScore"] else "HOLD",
            "confidence": snapshot["conviction"],
            "riskFlags": snapshot["riskFlags"],
            "timestamp": int(time.time() * 1000),
        }

    system = (
        "You are ET Alpha's finance analyst agent. "
        "Use only the supplied live data. "
        "If conviction is weak or signals conflict, explicitly say WATCH or HOLD instead of forcing a trade. "
        "Return only valid JSON."
    )
    prompt = (
        f"Create a concise but sharp market analysis for {target['ticker']} / {target['company']}.\n"
        f"Sector: {target['sector']}\n"
        f"Price: {snapshot['price']}\n"
        f"ChangePct: {snapshot['changePct']}\n"
        f"RSI: {snapshot['rsi']}\n"
        f"SMA20: {snapshot['sma20']}\n"
        f"SMA50: {snapshot['sma50']}\n"
        f"MACD: {snapshot['macd']}\n"
        f"MACD Signal: {snapshot['macdSignal']}\n"
        f"MACD Histogram: {snapshot['macdHistogram']}\n"
        f"ATR: {snapshot['atr']}\n"
        f"VolumeSpike: {snapshot['volumeSpike']}\n"
        f"Momentum5d: {snapshot['momentum5d']}\n"
        f"Momentum20d: {snapshot['momentum20d']}\n"
        f"Support: {snapshot['support']}\n"
        f"Resistance: {snapshot['resistance']}\n"
        f"Setup: {snapshot['setup']}\n"
        f"Trend: {snapshot['trend']}\n"
        f"RiskFlags: {snapshot['riskFlags']}\n"
        "Return JSON object with keys: analysis, verdict, confidence, bullCase, bearCase, nextTrigger, riskFlags."
    )

    try:
        raw = _groq_chat(system, prompt, max_tokens=700, temperature=0.2)
        match = re.search(r"\{[\s\S]*\}", raw)
        if not match:
            raise ValueError("No JSON in Groq response")
        parsed = json.loads(match.group(0))
        return {
            "ticker": target["ticker"],
            "company": target["company"],
            "analysis": parsed.get("analysis", fallback),
            "verdict": parsed.get("verdict", "WATCH"),
            "confidence": int(max(30, min(97, _safe_float(parsed.get("confidence"), snapshot["conviction"])))),
            "bullCase": parsed.get("bullCase", ""),
            "bearCase": parsed.get("bearCase", ""),
            "nextTrigger": parsed.get("nextTrigger", ""),
            "riskFlags": parsed.get("riskFlags", snapshot["riskFlags"]),
            "timestamp": int(time.time() * 1000),
        }
    except Exception:
        return {
            "ticker": target["ticker"],
            "company": target["company"],
            "analysis": fallback,
            "verdict": "WATCH" if snapshot["conviction"] < 60 else "BUY" if snapshot["bullishScore"] > snapshot["bearishScore"] else "SELL" if snapshot["bearishScore"] > snapshot["bullishScore"] else "HOLD",
            "confidence": snapshot["conviction"],
            "riskFlags": snapshot["riskFlags"],
            "timestamp": int(time.time() * 1000),
        }
