"""
browser_agent.py — Reads real holdings from open brokerage tabs
Uses Playwright (headless browser control — NOT an extension)

Supports:
  - Sharekhan
  - Zerodha Kite
  - Groww
  - Angel One
  - Upstox

Run: python browser_agent.py
It launches a visible browser, waits for you to log in,
then extracts your real holdings automatically.
"""
import asyncio
import json
import sys
from typing import Optional

try:
    from playwright.async_api import async_playwright, Page
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False
    print("Playwright not installed. Run: pip install playwright && playwright install chromium")


# ── Platform configs ──────────────────────────────────────────────────────────
PLATFORMS = {
    'zerodha': {
        'url':          'https://kite.zerodha.com/holdings',
        'login_url':    'https://kite.zerodha.com',
        'login_detect': 'input[type="text"][placeholder*="user"]',
        'holdings_selector': '.holdings',
        'row_selector': 'tr.holdings-row, tr[data-row]',
        'ticker_sel':   'td:nth-child(1)',
        'qty_sel':      'td:nth-child(2)',
        'ltp_sel':      'td:nth-child(3)',
        'avgcost_sel':  'td:nth-child(4)',
        'pnl_sel':      'td:nth-child(5)',
    },
    'sharekhan': {
        'url':          'https://www.sharekhan.com/trade/portfolio',
        'login_url':    'https://www.sharekhan.com',
        'login_detect': '#loginId',
        'holdings_selector': '.portfolio-holdings, .holdings-table',
        'row_selector': 'tr.holding-row, tbody tr',
        'ticker_sel':   'td:nth-child(1)',
        'qty_sel':      'td:nth-child(2)',
        'ltp_sel':      'td:nth-child(4)',
        'avgcost_sel':  'td:nth-child(3)',
        'pnl_sel':      'td:nth-child(6)',
    },
    'groww': {
        'url':          'https://groww.in/stocks/portfolio',
        'login_url':    'https://groww.in',
        'login_detect': 'input[placeholder*="email"], input[placeholder*="mobile"]',
        'holdings_selector': '[class*="portfolio"]',
        'row_selector': '[class*="holding"], [class*="stock-row"]',
        'ticker_sel':   '[class*="symbol"], [class*="ticker"]',
        'qty_sel':      '[class*="qty"], [class*="quantity"]',
        'ltp_sel':      '[class*="ltp"], [class*="current"]',
        'avgcost_sel':  '[class*="avg"], [class*="cost"]',
        'pnl_sel':      '[class*="pnl"], [class*="returns"]',
    },
    'angel': {
        'url':          'https://trade.angelbroking.com/stockPortfolio',
        'login_url':    'https://trade.angelbroking.com',
        'login_detect': '#userId',
        'holdings_selector': '.portfolio-table',
        'row_selector': 'tr.stock-row',
        'ticker_sel':   'td:nth-child(1)',
        'qty_sel':      'td:nth-child(2)',
        'ltp_sel':      'td:nth-child(3)',
        'avgcost_sel':  'td:nth-child(4)',
        'pnl_sel':      'td:nth-child(5)',
    },
}


async def read_holdings_from_page(page: Page, platform: str) -> list[dict]:
    """Generic holdings extractor that works across platforms."""
    cfg = PLATFORMS[platform]
    holdings = []

    # Wait for holdings table to appear
    try:
        await page.wait_for_selector(cfg['holdings_selector'], timeout=15000)
    except Exception:
        print(f'  Holdings table not found for {platform}')
        return []

    rows = await page.query_selector_all(cfg['row_selector'])
    print(f'  Found {len(rows)} rows')

    for row in rows:
        try:
            def safe_text(el):
                return el.inner_text().strip() if el else ''

            ticker_el  = await row.query_selector(cfg['ticker_sel'])
            qty_el     = await row.query_selector(cfg['qty_sel'])
            ltp_el     = await row.query_selector(cfg['ltp_sel'])
            avgcost_el = await row.query_selector(cfg['avgcost_sel'])
            pnl_el     = await row.query_selector(cfg['pnl_sel'])

            ticker  = (await ticker_el.inner_text()).strip()  if ticker_el  else ''
            qty_txt = (await qty_el.inner_text()).strip()     if qty_el     else '0'
            ltp_txt = (await ltp_el.inner_text()).strip()     if ltp_el     else '0'
            avg_txt = (await avgcost_el.inner_text()).strip() if avgcost_el else '0'
            pnl_txt = (await pnl_el.inner_text()).strip()     if pnl_el     else '0'

            def parse_num(s: str) -> float:
                return float(s.replace('₹','').replace(',','').replace('%','').replace('+','').strip() or 0)

            ticker = ticker.split('\n')[0].strip().upper()
            if not ticker or len(ticker) < 2:
                continue

            holdings.append({
                'ticker':       ticker,
                'qty':          int(parse_num(qty_txt)),
                'ltp':          parse_num(ltp_txt),
                'avgCost':      parse_num(avg_txt),
                'currentValue': int(parse_num(ltp_txt) * int(parse_num(qty_txt))),
                'pnl':          parse_num(pnl_txt),
                'platform':     platform,
            })
        except Exception as e:
            continue

    return [h for h in holdings if h['ticker'] and h['qty'] > 0]


async def launch_browser_agent(platform: str = 'zerodha', headless: bool = False):
    """
    Launch browser, navigate to brokerage, wait for user to log in,
    then extract real holdings.
    """
    if not PLAYWRIGHT_AVAILABLE:
        print('ERROR: Playwright not installed.')
        print('Run: pip install playwright && playwright install chromium')
        return []

    cfg = PLATFORMS.get(platform)
    if not cfg:
        print(f'Unknown platform: {platform}. Available: {list(PLATFORMS.keys())}')
        return []

    print(f'\n🌐 Launching browser for {platform}...')
    print('   Please log in when the browser opens.\n')

    async with async_playwright() as p:
        browser = await p.chromium.launch(
            headless=headless,
            args=['--no-sandbox', '--disable-blink-features=AutomationControlled']
        )
        context = await browser.new_context(
            viewport={'width': 1280, 'height': 800},
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        )
        page = await context.new_page()

        # Navigate to the brokerage
        print(f'  Navigating to {cfg["login_url"]}...')
        await page.goto(cfg['login_url'], wait_until='domcontentloaded')

        # Wait for login to complete (up to 2 minutes)
        print('  ⏳ Waiting for you to log in... (max 2 minutes)')
        try:
            await page.wait_for_url(
                lambda url: platform in url.lower() and 'login' not in url.lower(),
                timeout=120_000
            )
        except Exception:
            print('  Login timeout — trying to read current page anyway...')

        # Navigate to holdings page
        print(f'  Navigating to holdings: {cfg["url"]}')
        await page.goto(cfg['url'], wait_until='networkidle')
        await asyncio.sleep(2)

        # Extract holdings
        print('  📊 Extracting holdings...')
        holdings = await read_holdings_from_page(page, platform)

        await browser.close()

        if holdings:
            print(f'\n✅ Successfully extracted {len(holdings)} holdings from {platform}:')
            for h in holdings:
                print(f'   {h["ticker"]}: {h["qty"]} shares @ ₹{h["avgCost"]} (LTP: ₹{h["ltp"]})')

            # Save to file for the frontend to pick up
            with open('holdings_cache.json', 'w') as f:
                json.dump({'holdings': holdings, 'platform': platform, 'ts': __import__('time').time()}, f)
            print('\n💾 Saved to holdings_cache.json')
        else:
            print(f'\n⚠️  No holdings found. The page structure may have changed.')

        return holdings


# ── FastAPI endpoint wrapper ──────────────────────────────────────────────────
async def get_cached_holdings() -> Optional[dict]:
    """Read cached holdings from file (updated by browser agent)."""
    try:
        with open('holdings_cache.json', 'r') as f:
            data = json.load(f)
        age_minutes = (__import__('time').time() - data['ts']) / 60
        if age_minutes > 60:
            return None  # cache expired
        return data
    except FileNotFoundError:
        return None


if __name__ == '__main__':
    platform = sys.argv[1] if len(sys.argv) > 1 else 'zerodha'
    print(f'ET Alpha Browser Agent — reading from {platform}')
    print('=' * 50)
    asyncio.run(launch_browser_agent(platform, headless=False))
