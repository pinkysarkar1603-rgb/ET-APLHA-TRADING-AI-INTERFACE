# ET Alpha — AI Market Co-Pilot
### ET AI Hackathon 2026 | Track 6 + Track 9

## What's REAL in this build:
- **Live NSE prices** — Yahoo Finance, refreshes every 30s (RELIANCE, TCS, INFY, etc.)
- **Real Groq AI** — LLaMA-3.3-70B streaming, key included in .env.local
- **Real MF NAVs** — MFAPI.in (free Indian MF API)
- **Real holdings** — Enter your own in the Portfolio tab, live prices load instantly
- **Real browser import** — Playwright reads your Zerodha/Sharekhan tab (run browser_agent.py)
- **Real FIRE math** — Compound interest, inflation-adjusted corpus calculations
- **Real tax calculations** — Old vs New regime comparison

## Quick Start (frontend only — all you need for demo):
```
cd frontend
npm install
npm run dev
```
Open http://localhost:5173

## Full Setup (with backend + browser agent):
Double-click setup.bat (Windows)

## Import your real holdings:
Option 1 — Manual entry: Go to Portfolio tab → Enter your stocks
Option 2 — Browser agent:
  python backend/tools/browser_agent.py zerodha
  (Opens browser, you log in, it reads your holdings automatically)

## Architecture:
- Frontend: React + Vite + Tailwind + Zustand + Framer Motion + Recharts
- AI: Groq LLaMA-3.3-70B (fastest LLM available, key pre-configured)
- Market data: Yahoo Finance v8 API (free, no key needed)
- MF data: MFAPI.in (free Indian MF NAV API)
- Browser agent: Playwright (reads Zerodha/Sharekhan/Groww without extension)
- Backend: FastAPI + Python
- Signals: Groq analyses real NSE price movements + bulk deals + insider trades
